
  # Health Monitoring System

  This is a code bundle for Health Monitoring System. The original project is available at https://www.figma.com/design/gcTE39DmDaSqKMY0lLBQhv/Health-Monitoring-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  