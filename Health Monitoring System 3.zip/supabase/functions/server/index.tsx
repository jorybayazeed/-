import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-05688e50/health", (c) => {
  return c.json({ status: "ok" });
});

// ============== RAFEEQ SYSTEM API ENDPOINTS ==============

// Pilgrim Endpoints
app.post("/make-server-05688e50/pilgrims", async (c) => {
  try {
    const body = await c.req.json();
    const pilgrimId = crypto.randomUUID();
    const pilgrim = {
      id: pilgrimId,
      ...body,
      created_at: new Date().toISOString(),
    };

    await kv.set(`pilgrim:${pilgrimId}`, pilgrim);

    // Add to pilgrims list
    const allPilgrims = await kv.get('pilgrims:all') || [];
    allPilgrims.push(pilgrimId);
    await kv.set('pilgrims:all', allPilgrims);

    return c.json(pilgrim, 201);
  } catch (error) {
    console.error("Error creating pilgrim:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/pilgrims", async (c) => {
  try {
    const pilgrimIds = await kv.get('pilgrims:all') || [];
    const pilgrims = [];

    for (const id of pilgrimIds) {
      const pilgrim = await kv.get(`pilgrim:${id}`);
      if (pilgrim) pilgrims.push(pilgrim);
    }

    // Sort by current_risk descending
    pilgrims.sort((a, b) => (b.current_risk || 0) - (a.current_risk || 0));

    return c.json(pilgrims);
  } catch (error) {
    console.error("Error fetching pilgrims:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/pilgrims/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const pilgrim = await kv.get(`pilgrim:${id}`);

    if (!pilgrim) {
      return c.json({ error: "Pilgrim not found" }, 404);
    }

    // Get companions
    const companions = await kv.get(`companions:${id}`) || [];

    return c.json({ ...pilgrim, companions });
  } catch (error) {
    console.error("Error fetching pilgrim:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.put("/make-server-05688e50/pilgrims/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const updates = await c.req.json();

    const existing = await kv.get(`pilgrim:${id}`);
    if (!existing) {
      return c.json({ error: "Pilgrim not found" }, 404);
    }

    const updated = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString(),
    };

    await kv.set(`pilgrim:${id}`, updated);

    return c.json(updated);
  } catch (error) {
    console.error("Error updating pilgrim:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Companion Endpoints
app.post("/make-server-05688e50/companions", async (c) => {
  try {
    const body = await c.req.json();
    const companions = body.companions || [];
    const pilgrimId = body.pilgrim_id;

    if (!pilgrimId) {
      return c.json({ error: "pilgrim_id is required" }, 400);
    }

    const companionsWithIds = companions.map((comp: any) => ({
      id: crypto.randomUUID(),
      ...comp,
      pilgrim_id: pilgrimId,
      created_at: new Date().toISOString(),
    }));

    await kv.set(`companions:${pilgrimId}`, companionsWithIds);

    return c.json(companionsWithIds, 201);
  } catch (error) {
    console.error("Error creating companions:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Health Alert Endpoints
app.post("/make-server-05688e50/alerts", async (c) => {
  try {
    const body = await c.req.json();
    const alertId = crypto.randomUUID();
    const alert = {
      id: alertId,
      ...body,
      created_at: new Date().toISOString(),
      resolved: false,
    };

    await kv.set(`alert:${alertId}`, alert);

    // Add to alerts list
    const allAlerts = await kv.get('alerts:all') || [];
    allAlerts.push(alertId);
    await kv.set('alerts:all', allAlerts);

    return c.json(alert, 201);
  } catch (error) {
    console.error("Error creating alert:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/alerts", async (c) => {
  try {
    const resolvedParam = c.req.query('resolved');
    const alertIds = await kv.get('alerts:all') || [];
    const alerts = [];

    for (const id of alertIds) {
      const alert = await kv.get(`alert:${id}`);
      if (alert) {
        // Filter by resolved status if specified
        if (resolvedParam === 'false' && alert.resolved) continue;
        if (resolvedParam === 'true' && !alert.resolved) continue;

        // Get pilgrim info
        const pilgrim = await kv.get(`pilgrim:${alert.pilgrim_id}`);
        alerts.push({
          ...alert,
          pilgrims: pilgrim ? { name: pilgrim.name, phone: pilgrim.phone } : null
        });
      }
    }

    // Sort by created_at descending
    alerts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return c.json(alerts);
  } catch (error) {
    console.error("Error fetching alerts:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.put("/make-server-05688e50/alerts/:id/resolve", async (c) => {
  try {
    const id = c.req.param('id');
    const alert = await kv.get(`alert:${id}`);

    if (!alert) {
      return c.json({ error: "Alert not found" }, 404);
    }

    const updated = {
      ...alert,
      resolved: true,
      resolved_at: new Date().toISOString(),
    };

    await kv.set(`alert:${id}`, updated);

    return c.json(updated);
  } catch (error) {
    console.error("Error resolving alert:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Medical Team Endpoints
app.post("/make-server-05688e50/medical-team", async (c) => {
  try {
    const body = await c.req.json();
    const memberId = crypto.randomUUID();
    const member = {
      id: memberId,
      ...body,
      created_at: new Date().toISOString(),
    };

    await kv.set(`medical:${memberId}`, member);

    // Add to medical team list
    const allMembers = await kv.get('medical:all') || [];
    allMembers.push(memberId);
    await kv.set('medical:all', allMembers);

    return c.json(member, 201);
  } catch (error) {
    console.error("Error creating medical team member:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Medication Reminders
app.post("/make-server-05688e50/medications", async (c) => {
  try {
    const body = await c.req.json();
    const medicationId = crypto.randomUUID();
    const medication = {
      id: medicationId,
      ...body,
      created_at: new Date().toISOString(),
    };

    await kv.set(`medication:${medicationId}`, medication);

    // Add to medications list for this pilgrim
    const pilgrimId = body.pilgrim_id;
    const pilgrimMeds = await kv.get(`medications:${pilgrimId}`) || [];
    pilgrimMeds.push(medicationId);
    await kv.set(`medications:${pilgrimId}`, pilgrimMeds);

    return c.json(medication, 201);
  } catch (error) {
    console.error("Error creating medication:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/medications/:pilgrimId", async (c) => {
  try {
    const pilgrimId = c.req.param('pilgrimId');
    const medIds = await kv.get(`medications:${pilgrimId}`) || [];
    const medications = [];

    for (const id of medIds) {
      const med = await kv.get(`medication:${id}`);
      if (med) medications.push(med);
    }

    return c.json(medications);
  } catch (error) {
    console.error("Error fetching medications:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.delete("/make-server-05688e50/medications/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const medication = await kv.get(`medication:${id}`);

    if (!medication) {
      return c.json({ error: "Medication not found" }, 404);
    }

    // Remove from pilgrim's medication list
    const pilgrimId = medication.pilgrim_id;
    const pilgrimMeds = await kv.get(`medications:${pilgrimId}`) || [];
    const updatedMeds = pilgrimMeds.filter((medId: string) => medId !== id);
    await kv.set(`medications:${pilgrimId}`, updatedMeds);

    // Delete medication record
    await kv.del(`medication:${id}`);

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting medication:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Health Monitoring Data
app.post("/make-server-05688e50/health-data", async (c) => {
  try {
    const body = await c.req.json();
    const dataId = crypto.randomUUID();
    const healthData = {
      id: dataId,
      ...body,
      timestamp: new Date().toISOString(),
    };

    await kv.set(`health:${dataId}`, healthData);

    // Add to health data list for this pilgrim
    const pilgrimId = body.pilgrim_id;
    const pilgrimHealthData = await kv.get(`health_data:${pilgrimId}`) || [];
    pilgrimHealthData.push(dataId);

    // Keep only last 1000 records per pilgrim
    if (pilgrimHealthData.length > 1000) {
      pilgrimHealthData.shift();
    }

    await kv.set(`health_data:${pilgrimId}`, pilgrimHealthData);

    // Update pilgrim's current risk level
    const riskLevel = calculateRiskLevel(healthData);
    await kv.set(`pilgrim:${pilgrimId}:current_risk`, riskLevel);

    return c.json({ ...healthData, risk_level: riskLevel }, 201);
  } catch (error) {
    console.error("Error storing health data:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/health-data/:pilgrimId", async (c) => {
  try {
    const pilgrimId = c.req.param('pilgrimId');
    const limit = parseInt(c.req.query('limit') || '100');
    const dataIds = await kv.get(`health_data:${pilgrimId}`) || [];
    const healthData = [];

    // Get last N records
    const recentIds = dataIds.slice(-limit);

    for (const id of recentIds) {
      const data = await kv.get(`health:${id}`);
      if (data) healthData.push(data);
    }

    // Sort by timestamp descending
    healthData.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return c.json(healthData);
  } catch (error) {
    console.error("Error fetching health data:", error);
    return c.json({ error: error.message }, 500);
  }
});

// AI Risk Analysis
app.post("/make-server-05688e50/analyze-risk", async (c) => {
  try {
    const body = await c.req.json();
    const { pilgrim_id, activity_data, environmental_data } = body;

    // Get pilgrim information
    const pilgrim = await kv.get(`pilgrim:${pilgrim_id}`);
    if (!pilgrim) {
      return c.json({ error: "Pilgrim not found" }, 404);
    }

    // Get recent health data
    const dataIds = await kv.get(`health_data:${pilgrim_id}`) || [];
    const recentData = [];
    for (const id of dataIds.slice(-10)) {
      const data = await kv.get(`health:${id}`);
      if (data) recentData.push(data);
    }

    // Analyze risk factors
    const riskAnalysis = analyzeHealthRisk(pilgrim, activity_data, environmental_data, recentData);

    return c.json(riskAnalysis);
  } catch (error) {
    console.error("Error analyzing risk:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Voice Translation (Mock - in production would integrate with speech API)
app.post("/make-server-05688e50/translate-voice", async (c) => {
  try {
    const body = await c.req.json();
    const { text, source_language, target_language } = body;

    // Mock contextual translation
    const translation = await contextualTranslate(text, source_language, target_language);

    return c.json({
      original: text,
      translated: translation,
      source_language,
      target_language,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error translating:", error);
    return c.json({ error: error.message }, 500);
  }
});

// SMS Notification (Mock - in production would use Twilio or similar)
app.post("/make-server-05688e50/send-sms-notification", async (c) => {
  try {
    const body = await c.req.json();
    const {
      pilgrimName,
      riskLevel,
      riskType,
      message,
      location,
      companionPhone,
      companionName,
      language
    } = body;

    // Format message
    let smsMessage = '';
    if (language === 'ar') {
      smsMessage = `🚨 تنبيه طارئ!\n\nالحاج/ة ${pilgrimName} في خطر.\nنوع المخاطر: ${riskType}\n`;
      if (location) {
        smsMessage += `الموقع: https://www.google.com/maps?q=${location.lat},${location.lng}\n`;
      }
      smsMessage += `\nيرجى الاتصال فوراً. للطوارئ: 997`;
    } else {
      smsMessage = `🚨 EMERGENCY ALERT!\n\nPilgrim ${pilgrimName} is in danger.\nRisk: ${riskType}\n`;
      if (location) {
        smsMessage += `Location: https://www.google.com/maps?q=${location.lat},${location.lng}\n`;
      }
      smsMessage += `\nPlease call immediately. Emergency: 997`;
    }

    // Log notification (in production, would send via Twilio)
    console.log(`SMS to ${companionPhone}:`, smsMessage);

    // Store notification in database
    const notificationId = crypto.randomUUID();
    await kv.set(`notification:${notificationId}`, {
      id: notificationId,
      type: 'sms',
      recipient: companionPhone,
      recipient_name: companionName,
      message: smsMessage,
      risk_level: riskLevel,
      sent_at: new Date().toISOString(),
      status: 'simulated' // Would be 'sent' in production
    });

    return c.json({
      success: true,
      messageSid: `SM${notificationId}`,
      message: 'SMS notification simulated successfully (in production would use Twilio)'
    });
  } catch (error) {
    console.error("Error sending SMS:", error);
    return c.json({ error: error.message }, 500);
  }
});

// WhatsApp Notification (Mock - in production would use WhatsApp Business API)
app.post("/make-server-05688e50/send-whatsapp-notification", async (c) => {
  try {
    const body = await c.req.json();
    const {
      pilgrimName,
      riskLevel,
      riskType,
      message,
      location,
      companionPhone,
      companionName,
      language
    } = body;

    // Format WhatsApp message
    let whatsappMessage = '';
    if (language === 'ar') {
      whatsappMessage = `*🚨 رفيق - تنبيه طارئ!*\n\n`;
      whatsappMessage += `الحاج/ة: *${pilgrimName}*\n`;
      whatsappMessage += `مستوى الخطر: *${riskLevel === 'critical' ? 'حرج' : riskLevel === 'high' ? 'عالي' : 'متوسط'}*\n`;
      whatsappMessage += `نوع المخاطر: ${riskType}\n\n`;
      whatsappMessage += `${message}\n\n`;
      if (location) {
        whatsappMessage += `📍 الموقع:\nhttps://www.google.com/maps?q=${location.lat},${location.lng}\n\n`;
      }
      whatsappMessage += `⚠️ يرجى الاتصال بالحاج/ة فوراً\n`;
      whatsappMessage += `🚨 للطوارئ: 997`;
    } else {
      whatsappMessage = `*🚨 Rafeeq - Emergency Alert!*\n\n`;
      whatsappMessage += `Pilgrim: *${pilgrimName}*\n`;
      whatsappMessage += `Risk Level: *${riskLevel.toUpperCase()}*\n`;
      whatsappMessage += `Risk Type: ${riskType}\n\n`;
      whatsappMessage += `${message}\n\n`;
      if (location) {
        whatsappMessage += `📍 Location:\nhttps://www.google.com/maps?q=${location.lat},${location.lng}\n\n`;
      }
      whatsappMessage += `⚠️ Please contact the pilgrim immediately\n`;
      whatsappMessage += `🚨 Emergency: 997`;
    }

    // Log notification (in production, would send via WhatsApp Business API)
    console.log(`WhatsApp to ${companionPhone}:`, whatsappMessage);

    // Store notification in database
    const notificationId = crypto.randomUUID();
    await kv.set(`notification:${notificationId}`, {
      id: notificationId,
      type: 'whatsapp',
      recipient: companionPhone,
      recipient_name: companionName,
      message: whatsappMessage,
      risk_level: riskLevel,
      sent_at: new Date().toISOString(),
      status: 'simulated' // Would be 'sent' in production
    });

    return c.json({
      success: true,
      messageSid: `WA${notificationId}`,
      message: 'WhatsApp notification simulated successfully (in production would use WhatsApp Business API)'
    });
  } catch (error) {
    console.error("Error sending WhatsApp:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Statistics for medical dashboard
app.get("/make-server-05688e50/statistics", async (c) => {
  try {
    const pilgrimIds = await kv.get('pilgrims:all') || [];
    const alertIds = await kv.get('alerts:all') || [];

    let totalPilgrims = pilgrimIds.length;
    let highRiskCount = 0;
    let mediumRiskCount = 0;
    let activeAlerts = 0;

    const diseaseCount: Record<string, number> = {};

    for (const id of pilgrimIds) {
      const pilgrim = await kv.get(`pilgrim:${id}`);
      if (pilgrim) {
        const risk = await kv.get(`pilgrim:${id}:current_risk`) || 0;
        if (risk >= 70) highRiskCount++;
        else if (risk >= 40) mediumRiskCount++;

        // Count chronic diseases
        if (pilgrim.chronic_diseases) {
          const diseases = Array.isArray(pilgrim.chronic_diseases)
            ? pilgrim.chronic_diseases
            : pilgrim.chronic_diseases.split(',').map((d: string) => d.trim());

          for (const disease of diseases) {
            if (disease) {
              diseaseCount[disease] = (diseaseCount[disease] || 0) + 1;
            }
          }
        }
      }
    }

    for (const id of alertIds) {
      const alert = await kv.get(`alert:${id}`);
      if (alert && !alert.resolved) {
        activeAlerts++;
      }
    }

    return c.json({
      total_pilgrims: totalPilgrims,
      high_risk_cases: highRiskCount,
      medium_risk_cases: mediumRiskCount,
      active_alerts: activeAlerts,
      common_diseases: diseaseCount,
    });
  } catch (error) {
    console.error("Error fetching statistics:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Helper Functions
function calculateRiskLevel(healthData: any): number {
  let risk = 0;

  // Environmental factors
  if (healthData.temperature > 45) risk += 20;
  else if (healthData.temperature > 40) risk += 10;

  if (healthData.humidity > 70) risk += 10;

  // Activity factors
  if (healthData.activity_hours > 6) risk += 15;
  if (healthData.rest_hours < 2) risk += 10;

  // Movement patterns
  if (healthData.sudden_stops > 5) risk += 15;
  if (healthData.slow_walking) risk += 10;

  return Math.min(100, risk);
}

function analyzeHealthRisk(pilgrim: any, activityData: any, envData: any, historicalData: any[]): any {
  const risks = [];
  let overallRisk = 0;

  // Dehydration risk
  if (envData.temperature > 42 && activityData.activity_hours > 4) {
    risks.push({
      type: 'dehydration',
      level: 'high',
      message_ar: 'احتمال جفاف شديد - يرجى شرب الماء فوراً',
      message_en: 'Severe dehydration risk - Please drink water immediately'
    });
    overallRisk += 30;
  }

  // Heat exhaustion
  if (envData.temperature > 45 && activityData.continuous_activity > 2) {
    risks.push({
      type: 'heat_exhaustion',
      level: 'high',
      message_ar: 'احتمال إجهاد حراري - يرجى الراحة في مكان مظلل',
      message_en: 'Heat exhaustion risk - Please rest in shade'
    });
    overallRisk += 35;
  }

  // Physical fatigue
  if (activityData.slow_walking && activityData.frequent_stops) {
    risks.push({
      type: 'physical_fatigue',
      level: 'medium',
      message_ar: 'إرهاق جسدي - يُنصح بالراحة',
      message_en: 'Physical fatigue - Rest recommended'
    });
    overallRisk += 20;
  }

  // Mental confusion (irregular movement patterns)
  if (activityData.erratic_movement || activityData.repeated_paths) {
    risks.push({
      type: 'mental_confusion',
      level: 'medium',
      message_ar: 'احتمال فقدان تركيز - يرجى التواصل مع المرافق',
      message_en: 'Possible confusion - Contact companion'
    });
    overallRisk += 25;
  }

  // Medication interaction with heat
  if (pilgrim.medications && (envData.temperature > 40)) {
    const riskMeds = ['furosemide', 'amlodipine', 'diuretic'];
    const meds = Array.isArray(pilgrim.medications)
      ? pilgrim.medications
      : [pilgrim.medications];

    const hasRiskMed = meds.some((med: string) =>
      riskMeds.some(riskMed => med.toLowerCase().includes(riskMed))
    );

    if (hasRiskMed) {
      risks.push({
        type: 'medication_interaction',
        level: 'medium',
        message_ar: 'تنبيه: الأدوية قد تزيد من خطر الجفاف في الحرارة',
        message_en: 'Alert: Medications may increase dehydration risk in heat'
      });
      overallRisk += 15;
    }
  }

  return {
    overall_risk: Math.min(100, overallRisk),
    risk_level: overallRisk >= 70 ? 'high' : overallRisk >= 40 ? 'medium' : 'low',
    detected_risks: risks,
    recommendations_ar: generateRecommendations(risks, 'ar'),
    recommendations_en: generateRecommendations(risks, 'en'),
    timestamp: new Date().toISOString()
  };
}

function generateRecommendations(risks: any[], language: string): string[] {
  const recommendations = [];

  if (language === 'ar') {
    if (risks.some(r => r.type === 'dehydration')) {
      recommendations.push('شرب كوب ماء كل 15 دقيقة');
      recommendations.push('تجنب التعرض المباشر للشمس');
    }
    if (risks.some(r => r.type === 'heat_exhaustion')) {
      recommendations.push('الراحة فوراً في مكان مكيف');
      recommendations.push('وضع كمادات باردة على الجبهة');
    }
    if (risks.some(r => r.type === 'physical_fatigue')) {
      recommendations.push('أخذ راحة لمدة 30 دقيقة');
    }
    if (risks.some(r => r.type === 'mental_confusion')) {
      recommendations.push('البقاء مع المرافق');
      recommendations.push('تجنب الأماكن المزدحمة');
    }
  } else {
    if (risks.some(r => r.type === 'dehydration')) {
      recommendations.push('Drink water every 15 minutes');
      recommendations.push('Avoid direct sun exposure');
    }
    if (risks.some(r => r.type === 'heat_exhaustion')) {
      recommendations.push('Rest immediately in air-conditioned area');
      recommendations.push('Apply cold compress to forehead');
    }
    if (risks.some(r => r.type === 'physical_fatigue')) {
      recommendations.push('Take 30-minute rest');
    }
    if (risks.some(r => r.type === 'mental_confusion')) {
      recommendations.push('Stay with companion');
      recommendations.push('Avoid crowded areas');
    }
  }

  return recommendations;
}

async function contextualTranslate(text: string, sourceLang: string, targetLang: string): Promise<string> {
  // Medical context translations (mock - would use AI API in production)
  const medicalPhrases: Record<string, Record<string, string>> = {
    'ar_to_en': {
      'أشعر بدوخة': 'I feel dizzy',
      'أحتاج ماء': 'I need water',
      'عندي ألم في الصدر': 'I have chest pain',
      'أشعر بغثيان': 'I feel nauseous',
      'أحتاج مساعدة': 'I need help',
      'أين المستشفى': 'Where is the hospital',
      'عندي حساسية': 'I have allergies',
      'ضغط دم مرتفع': 'High blood pressure',
      'سكري': 'Diabetes',
    },
    'en_to_ar': {
      'i feel dizzy': 'أشعر بدوخة',
      'i need water': 'أحتاج ماء',
      'chest pain': 'ألم في الصدر',
      'i feel nauseous': 'أشعر بغثيان',
      'i need help': 'أحتاج مساعدة',
      'where is the hospital': 'أين المستشفى',
      'allergies': 'حساسية',
      'high blood pressure': 'ضغط دم مرتفع',
      'diabetes': 'سكري',
    }
  };

  const key = `${sourceLang}_to_${targetLang}`;
  const textLower = text.toLowerCase();

  // Check for exact matches
  if (medicalPhrases[key] && medicalPhrases[key][textLower]) {
    return medicalPhrases[key][textLower];
  }

  // Check for partial matches
  for (const phrase in medicalPhrases[key]) {
    if (textLower.includes(phrase)) {
      return medicalPhrases[key][phrase];
    }
  }

  // Default return original text if no translation found
  return `[Translation needed]: ${text}`;
}

// Emergency Escalation Endpoints
app.post("/make-server-05688e50/escalate-to-medical", async (c) => {
  try {
    const body = await c.req.json();
    const { alert_id, alert, language } = body;

    // Log escalation
    console.log(`🚨 ESCALATED TO MEDICAL TEAM - Alert ${alert_id}:`, alert);

    // In production, this would:
    // 1. Send notifications to on-duty medical teams
    // 2. Update alert escalation status in database
    // 3. Dispatch nearest medical personnel

    const escalationRecord = {
      alert_id,
      escalation_level: 2,
      escalated_to: 'medical_team',
      escalated_at: new Date().toISOString(),
      alert_details: alert,
    };

    await kv.set(`escalation:${alert_id}:medical`, escalationRecord);

    return c.json({
      success: true,
      escalation_level: 2,
      message: 'Alert escalated to medical team',
      estimated_arrival: '10-15 minutes',
    });
  } catch (error) {
    console.error("Error escalating to medical team:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.post("/make-server-05688e50/escalate-to-emergency", async (c) => {
  try {
    const body = await c.req.json();
    const { alert_id, alert, language } = body;

    // Log critical escalation
    console.log(`🚑 CRITICAL - ESCALATED TO EMERGENCY SERVICES (997) - Alert ${alert_id}:`, alert);

    // In production, this would:
    // 1. Call emergency services API (997 in Saudi Arabia)
    // 2. Provide GPS coordinates and patient info
    // 3. Request ambulance dispatch
    // 4. Update all relevant parties

    const escalationRecord = {
      alert_id,
      escalation_level: 3,
      escalated_to: 'emergency_services_997',
      escalated_at: new Date().toISOString(),
      alert_details: alert,
      priority: 'CRITICAL',
    };

    await kv.set(`escalation:${alert_id}:emergency`, escalationRecord);

    // Create emergency log
    const emergencyLogs = await kv.get('emergency:logs') || [];
    emergencyLogs.push({
      timestamp: new Date().toISOString(),
      alert_id,
      pilgrim: alert.pilgrim_name,
      type: alert.type,
      location: alert.location,
    });
    await kv.set('emergency:logs', emergencyLogs);

    return c.json({
      success: true,
      escalation_level: 3,
      message: 'Alert escalated to emergency services (997)',
      estimated_arrival: '5-8 minutes',
      ambulance_dispatched: true,
    });
  } catch (error) {
    console.error("Error escalating to emergency services:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get escalation history
app.get("/make-server-05688e50/escalations/:alertId", async (c) => {
  try {
    const alertId = c.req.param('alertId');

    const medicalEscalation = await kv.get(`escalation:${alertId}:medical`);
    const emergencyEscalation = await kv.get(`escalation:${alertId}:emergency`);

    return c.json({
      alert_id: alertId,
      escalations: {
        medical: medicalEscalation || null,
        emergency: emergencyEscalation || null,
      },
    });
  } catch (error) {
    console.error("Error fetching escalation history:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Emergency logs for admin dashboard
app.get("/make-server-05688e50/emergency-logs", async (c) => {
  try {
    const logs = await kv.get('emergency:logs') || [];
    return c.json(logs);
  } catch (error) {
    console.error("Error fetching emergency logs:", error);
    return c.json({ error: error.message }, 500);
  }
});

Deno.serve(app.fetch);