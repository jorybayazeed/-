// Supabase project configuration
// These values are provided by the Make environment
export const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID || 'your-project-id';
export const publicAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

// Server URL
export const serverUrl = `https://${projectId}.supabase.co/functions/v1/make-server-05688e50`;
