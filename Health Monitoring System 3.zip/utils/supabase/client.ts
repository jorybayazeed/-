import { projectId, publicAnonKey, serverUrl } from './info';

// API client for Rafeeq backend
export class RafeeqAPI {
  private baseUrl: string;
  private headers: HeadersInit;

  constructor() {
    this.baseUrl = serverUrl;
    this.headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    };
  }

  // Pilgrims
  async createPilgrim(data: any) {
    const response = await fetch(`${this.baseUrl}/pilgrims`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  async getPilgrims() {
    const response = await fetch(`${this.baseUrl}/pilgrims`, {
      headers: this.headers
    });
    return response.json();
  }

  async getPilgrim(id: string) {
    const response = await fetch(`${this.baseUrl}/pilgrims/${id}`, {
      headers: this.headers
    });
    return response.json();
  }

  async updatePilgrim(id: string, data: any) {
    const response = await fetch(`${this.baseUrl}/pilgrims/${id}`, {
      method: 'PUT',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  // Companions
  async createCompanions(pilgrimId: string, companions: any[]) {
    const response = await fetch(`${this.baseUrl}/companions`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify({ pilgrim_id: pilgrimId, companions })
    });
    return response.json();
  }

  // Alerts
  async createAlert(data: any) {
    const response = await fetch(`${this.baseUrl}/alerts`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  async getAlerts(resolved?: boolean) {
    const url = resolved !== undefined
      ? `${this.baseUrl}/alerts?resolved=${resolved}`
      : `${this.baseUrl}/alerts`;

    const response = await fetch(url, {
      headers: this.headers
    });
    return response.json();
  }

  async resolveAlert(id: string) {
    const response = await fetch(`${this.baseUrl}/alerts/${id}/resolve`, {
      method: 'PUT',
      headers: this.headers
    });
    return response.json();
  }

  // Medications
  async createMedication(data: any) {
    const response = await fetch(`${this.baseUrl}/medications`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  async getMedications(pilgrimId: string) {
    const response = await fetch(`${this.baseUrl}/medications/${pilgrimId}`, {
      headers: this.headers
    });
    return response.json();
  }

  // Health Data
  async saveHealthData(data: any) {
    const response = await fetch(`${this.baseUrl}/health-data`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  async getHealthData(pilgrimId: string, limit: number = 100) {
    const response = await fetch(`${this.baseUrl}/health-data/${pilgrimId}?limit=${limit}`, {
      headers: this.headers
    });
    return response.json();
  }

  // AI Risk Analysis
  async analyzeRisk(data: any) {
    const response = await fetch(`${this.baseUrl}/analyze-risk`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  // Voice Translation
  async translateVoice(text: string, sourceLang: string, targetLang: string) {
    const response = await fetch(`${this.baseUrl}/translate-voice`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify({
        text,
        source_language: sourceLang,
        target_language: targetLang
      })
    });
    return response.json();
  }

  // Medical Team
  async createMedicalTeamMember(data: any) {
    const response = await fetch(`${this.baseUrl}/medical-team`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(data)
    });
    return response.json();
  }

  // Statistics
  async getStatistics() {
    const response = await fetch(`${this.baseUrl}/statistics`, {
      headers: this.headers
    });
    return response.json();
  }
}

// Singleton instance
export const rafeeqAPI = new RafeeqAPI();
