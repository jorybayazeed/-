import { API_BASE, publicAnonKey, type Pilgrim, type Companion, type HealthAlert, type MedicalTeamMember } from './supabase';

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

// Pilgrim API
export async function createPilgrim(pilgrim: Omit<Pilgrim, 'id' | 'created_at'>): Promise<Pilgrim> {
  const response = await fetch(`${API_BASE}/pilgrims`, {
    method: 'POST',
    headers,
    body: JSON.stringify(pilgrim),
  });

  if (!response.ok) {
    throw new Error('Failed to create pilgrim');
  }

  return response.json();
}

export async function getAllPilgrims(): Promise<Pilgrim[]> {
  const response = await fetch(`${API_BASE}/pilgrims`, {
    headers,
  });

  if (!response.ok) {
    throw new Error('Failed to fetch pilgrims');
  }

  return response.json();
}

export async function getPilgrim(id: string): Promise<Pilgrim & { companions?: Companion[] }> {
  const response = await fetch(`${API_BASE}/pilgrims/${id}`, {
    headers,
  });

  if (!response.ok) {
    throw new Error('Failed to fetch pilgrim');
  }

  return response.json();
}

export async function updatePilgrim(id: string, updates: Partial<Pilgrim>): Promise<Pilgrim> {
  const response = await fetch(`${API_BASE}/pilgrims/${id}`, {
    method: 'PUT',
    headers,
    body: JSON.stringify(updates),
  });

  if (!response.ok) {
    throw new Error('Failed to update pilgrim');
  }

  return response.json();
}

// Companion API
export async function createCompanions(
  pilgrimId: string,
  companions: Omit<Companion, 'id' | 'created_at' | 'pilgrim_id'>[]
): Promise<Companion[]> {
  const response = await fetch(`${API_BASE}/companions`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      pilgrim_id: pilgrimId,
      companions,
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to create companions');
  }

  return response.json();
}

// Health Alert API
export async function createHealthAlert(
  alert: Omit<HealthAlert, 'id' | 'created_at' | 'resolved' | 'resolved_at'>
): Promise<HealthAlert> {
  const response = await fetch(`${API_BASE}/alerts`, {
    method: 'POST',
    headers,
    body: JSON.stringify(alert),
  });

  if (!response.ok) {
    throw new Error('Failed to create alert');
  }

  return response.json();
}

export async function getHealthAlerts(resolved?: boolean): Promise<HealthAlert[]> {
  const url = resolved !== undefined
    ? `${API_BASE}/alerts?resolved=${resolved}`
    : `${API_BASE}/alerts`;

  const response = await fetch(url, { headers });

  if (!response.ok) {
    throw new Error('Failed to fetch alerts');
  }

  return response.json();
}

export async function resolveAlert(id: string): Promise<HealthAlert> {
  const response = await fetch(`${API_BASE}/alerts/${id}/resolve`, {
    method: 'PUT',
    headers,
  });

  if (!response.ok) {
    throw new Error('Failed to resolve alert');
  }

  return response.json();
}

// Medical Team API
export async function createMedicalTeamMember(
  member: Omit<MedicalTeamMember, 'id' | 'created_at'>
): Promise<MedicalTeamMember> {
  const response = await fetch(`${API_BASE}/medical-team`, {
    method: 'POST',
    headers,
    body: JSON.stringify(member),
  });

  if (!response.ok) {
    throw new Error('Failed to create medical team member');
  }

  return response.json();
}
