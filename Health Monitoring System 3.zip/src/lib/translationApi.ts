// Voice Translation API

import { API_BASE, publicAnonKey } from './supabase';

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

export interface TranslationResult {
  original: string;
  translated: string;
  source_language: string;
  target_language: string;
  timestamp: string;
}

export async function translateVoice(
  text: string,
  sourceLang: string,
  targetLang: string
): Promise<TranslationResult> {
  const response = await fetch(`${API_BASE}/translate-voice`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      text,
      source_language: sourceLang,
      target_language: targetLang,
    }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to translate');
  }

  return response.json();
}
