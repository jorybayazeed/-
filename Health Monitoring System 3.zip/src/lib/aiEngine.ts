// AI Health Risk Analysis Engine for Rafeeq System

export interface HealthProfile {
  age: number;
  gender: 'male' | 'female';
  chronicDiseases: string[];
  medications: string[];
}

export interface BehaviorData {
  walkingSpeed?: number;
  stoppageCount?: number;
  activityDuration?: number;
  lastWaterIntake?: number;
  temperature?: number;
  location?: {
    lat: number;
    lng: number;
  };
}

export interface RiskAnalysis {
  overallRisk: number;
  riskLevel: 'safe' | 'warning' | 'medium_risk' | 'high_risk';
  riskFactors: {
    type: string;
    severity: number;
    description: string;
  }[];
  recommendations: string[];
  shouldAlert: boolean;
  shouldEscalate: boolean;
}

export function calculateBaselineRisk(profile: HealthProfile): number {
  let risk = 0;

  if (profile.age > 70) risk += 30;
  else if (profile.age > 60) risk += 20;
  else if (profile.age > 50) risk += 10;

  const highRiskDiseases = ['diabetes', 'heart disease', 'kidney disease', 'hypertension', 'respiratory disease'];

  profile.chronicDiseases.forEach(disease => {
    const isHighRisk = highRiskDiseases.some(hrd => disease.toLowerCase().includes(hrd));
    if (isHighRisk) risk += 10;
    else risk += 5;
  });

  risk = Math.min(risk, 70);

  const heatSensitiveMeds = ['diuretic', 'beta blocker', 'antihistamine', 'anticholinergic'];

  profile.medications.forEach(med => {
    const isHeatSensitive = heatSensitiveMeds.some(hsm => med.toLowerCase().includes(hsm));
    if (isHeatSensitive) risk += 5;
  });

  return Math.min(risk, 100);
}

export function analyzeBehavior(
  profile: HealthProfile,
  baselineRisk: number,
  behavior: BehaviorData
): RiskAnalysis {
  let currentRisk = baselineRisk;
  const riskFactors: RiskAnalysis['riskFactors'] = [];
  const recommendations: string[] = [];

  if (behavior.lastWaterIntake && behavior.lastWaterIntake > 120) {
    const dehydrationRisk = Math.min((behavior.lastWaterIntake - 120) / 60 * 15, 25);
    currentRisk += dehydrationRisk;
    riskFactors.push({
      type: 'dehydration',
      severity: dehydrationRisk,
      description: `No water intake for ${Math.floor(behavior.lastWaterIntake / 60)} hours`,
    });
    recommendations.push('Drink water immediately');
  }

  if (behavior.temperature && behavior.temperature > 38) {
    const heatRisk = (behavior.temperature - 38) * 10;
    currentRisk += heatRisk;
    riskFactors.push({
      type: 'heat_exhaustion',
      severity: heatRisk,
      description: `High ambient temperature: ${behavior.temperature}°C`,
    });
    recommendations.push('Move to shaded area');
  }

  if (behavior.activityDuration && behavior.activityDuration > 4) {
    const fatigueRisk = Math.min((behavior.activityDuration - 4) * 5, 20);
    currentRisk += fatigueRisk;
    riskFactors.push({
      type: 'physical_fatigue',
      severity: fatigueRisk,
      description: `Continuous activity for ${behavior.activityDuration} hours`,
    });
    recommendations.push('Take rest immediately');
  }

  if (behavior.walkingSpeed && behavior.walkingSpeed < 0.5) {
    currentRisk += 15;
    riskFactors.push({
      type: 'movement_anomaly',
      severity: 15,
      description: 'Unusually slow movement detected',
    });
    recommendations.push('Check physical condition');
  }

  if (behavior.stoppageCount && behavior.stoppageCount > 10) {
    currentRisk += 10;
    riskFactors.push({
      type: 'frequent_stops',
      severity: 10,
      description: `${behavior.stoppageCount} stops in short period`,
    });
  }

  currentRisk = Math.min(currentRisk, 100);

  let riskLevel: RiskAnalysis['riskLevel'];
  if (currentRisk < 30) riskLevel = 'safe';
  else if (currentRisk < 50) riskLevel = 'warning';
  else if (currentRisk < 75) riskLevel = 'medium_risk';
  else riskLevel = 'high_risk';

  const shouldAlert = currentRisk >= 50;
  const shouldEscalate = currentRisk >= 75;

  return {
    overallRisk: currentRisk,
    riskLevel,
    riskFactors,
    recommendations,
    shouldAlert,
    shouldEscalate,
  };
}

export function simulateBehaviorData(): BehaviorData {
  return {
    walkingSpeed: Math.random() * 1.5,
    stoppageCount: Math.floor(Math.random() * 15),
    activityDuration: Math.random() * 6,
    lastWaterIntake: Math.random() * 240,
    temperature: 35 + Math.random() * 8,
    location: {
      lat: 21.4225 + (Math.random() - 0.5) * 0.01,
      lng: 39.8262 + (Math.random() - 0.5) * 0.01,
    },
  };
}

export function analyzeCrowdHealth(pilgrims: any[]): {
  totalPilgrims: number;
  highRiskCount: number;
  averageRisk: number;
  commonDiseases: { disease: string; count: number }[];
  riskDistribution: { level: string; count: number }[];
} {
  const totalPilgrims = pilgrims.length;
  const highRiskCount = pilgrims.filter(p => p.current_risk >= 75).length;
  const averageRisk = pilgrims.reduce((sum, p) => sum + p.current_risk, 0) / (totalPilgrims || 1);

  const diseaseMap = new Map<string, number>();
  pilgrims.forEach(p => {
    p.chronic_diseases?.forEach((disease: string) => {
      diseaseMap.set(disease, (diseaseMap.get(disease) || 0) + 1);
    });
  });

  const commonDiseases = Array.from(diseaseMap.entries())
    .map(([disease, count]) => ({ disease, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const riskDistribution = [
    { level: 'safe', count: pilgrims.filter(p => p.current_risk < 30).length },
    { level: 'warning', count: pilgrims.filter(p => p.current_risk >= 30 && p.current_risk < 50).length },
    { level: 'medium', count: pilgrims.filter(p => p.current_risk >= 50 && p.current_risk < 75).length },
    { level: 'high', count: pilgrims.filter(p => p.current_risk >= 75).length },
  ];

  return {
    totalPilgrims,
    highRiskCount,
    averageRisk,
    commonDiseases,
    riskDistribution,
  };
}
