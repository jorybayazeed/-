// Real-time Health Monitoring with Simulated IoT Sensors

import { gpsTracker, type LocationData } from './gpsTracking';
import { API_BASE, publicAnonKey } from './supabase';

export interface SensorData {
  heartRate?: number;
  bloodPressure?: { systolic: number; diastolic: number };
  oxygenLevel?: number;
  bodyTemperature?: number;
  steps?: number;
  caloriesBurned?: number;
  timestamp: number;
}

export interface HealthMonitoringData {
  location: LocationData | null;
  sensors: SensorData;
  environmentalData: {
    ambientTemperature: number;
    humidity: number;
    airQuality: number;
  };
  activityData: {
    walkingSpeed: number;
    isMoving: boolean;
    stoppageCount: number;
    activityDuration: number;
    lastWaterIntake: number;
  };
}

class HealthMonitor {
  private monitoringInterval: NodeJS.Timeout | null = null;
  private locationData: LocationData | null = null;
  private previousLocation: LocationData | null = null;
  private stoppageCount: number = 0;
  private activityStartTime: number = Date.now();
  private lastWaterIntakeTime: number = Date.now();
  private stepCount: number = 0;

  // Simulate IoT wearable sensor data (in real app, this would come from actual devices)
  private simulateSensorData(): SensorData {
    // Simulate realistic health metrics
    const heartRate = 60 + Math.floor(Math.random() * 40); // 60-100 bpm normal
    const systolic = 110 + Math.floor(Math.random() * 30); // 110-140 mmHg
    const diastolic = 70 + Math.floor(Math.random() * 20); // 70-90 mmHg
    const oxygenLevel = 95 + Math.floor(Math.random() * 5); // 95-100%
    const bodyTemp = 36.5 + Math.random() * 1.5; // 36.5-38°C

    return {
      heartRate,
      bloodPressure: { systolic, diastolic },
      oxygenLevel,
      bodyTemperature: parseFloat(bodyTemp.toFixed(1)),
      steps: this.stepCount,
      caloriesBurned: Math.floor(this.stepCount * 0.04),
      timestamp: Date.now(),
    };
  }

  // Simulate environmental sensors
  private simulateEnvironmentalData() {
    // Mecca weather conditions (hot and dry)
    const baseTemp = 38;
    const tempVariation = Math.random() * 10; // 38-48°C
    const humidity = 20 + Math.random() * 30; // 20-50%
    const airQuality = 50 + Math.random() * 100; // AQI

    return {
      ambientTemperature: parseFloat((baseTemp + tempVariation).toFixed(1)),
      humidity: parseFloat(humidity.toFixed(1)),
      airQuality: Math.floor(airQuality),
    };
  }

  // Calculate walking speed and activity
  private calculateActivityData(): {
    walkingSpeed: number;
    isMoving: boolean;
    stoppageCount: number;
    activityDuration: number;
    lastWaterIntake: number;
  } {
    let walkingSpeed = 0;
    let isMoving = false;

    if (this.locationData && this.previousLocation) {
      const distance = gpsTracker.calculateDistance(
        this.previousLocation.latitude,
        this.previousLocation.longitude,
        this.locationData.latitude,
        this.locationData.longitude
      );

      const timeDiff = (this.locationData.timestamp - this.previousLocation.timestamp) / 1000; // seconds
      walkingSpeed = timeDiff > 0 ? distance / timeDiff : 0; // meters per second

      isMoving = walkingSpeed > 0.1; // Moving if speed > 0.1 m/s

      if (!isMoving && this.previousLocation) {
        this.stoppageCount++;
      }

      // Estimate steps based on movement
      if (isMoving) {
        this.stepCount += Math.floor(distance / 0.8); // Assume 0.8m per step
      }
    }

    const activityDuration = (Date.now() - this.activityStartTime) / (1000 * 60 * 60); // hours
    const lastWaterIntake = (Date.now() - this.lastWaterIntakeTime) / (1000 * 60); // minutes

    return {
      walkingSpeed: parseFloat(walkingSpeed.toFixed(2)),
      isMoving,
      stoppageCount: this.stoppageCount,
      activityDuration: parseFloat(activityDuration.toFixed(2)),
      lastWaterIntake: parseFloat(lastWaterIntake.toFixed(0)),
    };
  }

  // Start real-time monitoring
  startMonitoring(
    pilgrimId: string,
    onUpdate: (data: HealthMonitoringData) => void,
    onError: (error: any) => void,
    intervalMs: number = 10000 // Update every 10 seconds
  ): void {
    // Start GPS tracking with graceful error handling
    gpsTracker.startTracking(
      (location) => {
        this.previousLocation = this.locationData;
        this.locationData = location;
      },
      (error) => {
        console.warn('GPS tracking issue (using mock data):', error.message);
        // Don't call onError - GPS will use mock data automatically
      }
    );

    // Start periodic health data collection
    this.monitoringInterval = setInterval(() => {
      const monitoringData: HealthMonitoringData = {
        location: this.locationData,
        sensors: this.simulateSensorData(),
        environmentalData: this.simulateEnvironmentalData(),
        activityData: this.calculateActivityData(),
      };

      // Send to backend with error handling
      this.sendHealthDataToBackend(pilgrimId, monitoringData).catch((error) => {
        console.warn('Could not send data to backend (demo mode):', error);
        // Continue monitoring locally even if backend fails
      });

      // Update UI
      onUpdate(monitoringData);
    }, intervalMs);
  }

  // Stop monitoring
  stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    gpsTracker.stopTracking();
  }

  // Send health data to backend
  private async sendHealthDataToBackend(
    pilgrimId: string,
    data: HealthMonitoringData
  ): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/health-data`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          pilgrim_id: pilgrimId,
          location: data.location,
          heart_rate: data.sensors.heartRate,
          blood_pressure: data.sensors.bloodPressure,
          oxygen_level: data.sensors.oxygenLevel,
          body_temperature: data.sensors.bodyTemperature,
          steps: data.sensors.steps,
          calories_burned: data.sensors.caloriesBurned,
          ambient_temperature: data.environmentalData.ambientTemperature,
          humidity: data.environmentalData.humidity,
          air_quality: data.environmentalData.airQuality,
          walking_speed: data.activityData.walkingSpeed,
          is_moving: data.activityData.isMoving,
          stoppage_count: data.activityData.stoppageCount,
          activity_hours: data.activityData.activityDuration,
          last_water_intake_minutes: data.activityData.lastWaterIntake,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send health data');
      }
    } catch (error) {
      console.error('Error sending health data:', error);
      throw error;
    }
  }

  // Record water intake
  recordWaterIntake(): void {
    this.lastWaterIntakeTime = Date.now();
  }

  // Reset activity tracking
  resetActivity(): void {
    this.activityStartTime = Date.now();
    this.stoppageCount = 0;
    this.stepCount = 0;
  }
}

export const healthMonitor = new HealthMonitor();