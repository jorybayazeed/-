// Real GPS Location Tracking System

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude?: number;
  speed?: number;
  heading?: number;
  timestamp: number;
}

export interface LocationError {
  code: number;
  message: string;
}

class GPSTracker {
  private watchId: number | null = null;
  private onLocationUpdate: ((location: LocationData) => void) | null = null;
  private onError: ((error: LocationError) => void) | null = null;
  private isMockMode: boolean = false;
  private mockInterval: NodeJS.Timeout | null = null;

  // Start tracking location
  startTracking(
    onUpdate: (location: LocationData) => void,
    onError: (error: LocationError) => void,
    options?: PositionOptions
  ): void {
    if (!navigator.geolocation) {
      console.warn('Geolocation not supported, using mock data');
      this.startMockTracking(onUpdate);
      return;
    }

    this.onLocationUpdate = onUpdate;
    this.onError = onError;

    const defaultOptions: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 60000,
      ...options,
    };

    this.watchId = navigator.geolocation.watchPosition(
      (position) => {
        this.isMockMode = false;
        const locationData: LocationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude ?? undefined,
          speed: position.coords.speed ?? undefined,
          heading: position.coords.heading ?? undefined,
          timestamp: position.timestamp,
        };
        this.onLocationUpdate?.(locationData);
      },
      (error) => {
        console.warn('Geolocation error, switching to mock mode:', error.message);
        // Instead of calling onError, switch to mock mode
        this.startMockTracking(onUpdate);
      },
      defaultOptions
    );
  }

  // Start mock GPS tracking for demo purposes
  private startMockTracking(onUpdate: (location: LocationData) => void): void {
    this.isMockMode = true;
    
    // Use Mecca/Arafat coordinates with slight variations
    const baseLat = 21.4225;
    const baseLng = 39.8262;
    
    // Send initial location
    onUpdate({
      latitude: baseLat,
      longitude: baseLng,
      accuracy: 10,
      timestamp: Date.now(),
    });

    // Update location periodically with small variations (simulating movement)
    this.mockInterval = setInterval(() => {
      const variation = 0.001; // ~100 meters
      onUpdate({
        latitude: baseLat + (Math.random() - 0.5) * variation,
        longitude: baseLng + (Math.random() - 0.5) * variation,
        accuracy: 10,
        speed: Math.random() * 2, // 0-2 m/s walking speed
        timestamp: Date.now(),
      });
    }, 5000); // Update every 5 seconds
  }

  // Stop tracking
  stopTracking(): void {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    if (this.mockInterval !== null) {
      clearInterval(this.mockInterval);
      this.mockInterval = null;
    }
    this.isMockMode = false;
  }

  // Get current location once
  getCurrentLocation(): Promise<LocationData> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        console.warn('Geolocation not supported, returning mock location');
        resolve({
          latitude: 21.4225,
          longitude: 39.8262,
          accuracy: 10,
          timestamp: Date.now(),
        });
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            altitude: position.coords.altitude ?? undefined,
            speed: position.coords.speed ?? undefined,
            heading: position.coords.heading ?? undefined,
            timestamp: position.timestamp,
          });
        },
        (error) => {
          console.warn('Geolocation error, returning mock location:', error.message);
          // Return mock location instead of rejecting
          resolve({
            latitude: 21.4225,
            longitude: 39.8262,
            accuracy: 10,
            timestamp: Date.now(),
          });
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000,
        }
      );
    });
  }

  // Calculate distance between two points (Haversine formula)
  calculateDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in meters
  }
}

export const gpsTracker = new GPSTracker();

// Holy sites coordinates for proximity detection
export const HOLY_SITES = {
  MASJID_AL_HARAM: { lat: 21.4225, lng: 39.8262, name: 'Masjid al-Haram' },
  KAABA: { lat: 21.4225, lng: 39.8262, name: 'Kaaba' },
  SAFA_MARWA: { lat: 21.4236, lng: 39.8267, name: 'Safa and Marwa' },
  JABAL_RAHMAH: { lat: 21.3547, lng: 39.9833, name: 'Mount Arafat' },
  MUZDALIFAH: { lat: 21.3961, lng: 39.9267, name: 'Muzdalifah' },
  MINA: { lat: 21.4197, lng: 39.8931, name: 'Mina' },
  JAMARAT: { lat: 21.4186, lng: 39.8886, name: 'Jamarat Bridge' },
};

// Check if pilgrim is near a holy site
export function getNearestHolySite(lat: number, lng: number): {
  site: string;
  distance: number;
} | null {
  const tracker = new GPSTracker();
  let nearest = null;
  let minDistance = Infinity;

  for (const [key, site] of Object.entries(HOLY_SITES)) {
    const distance = tracker.calculateDistance(lat, lng, site.lat, site.lng);
    if (distance < minDistance) {
      minDistance = distance;
      nearest = { site: site.name, distance };
    }
  }

  return nearest;
}