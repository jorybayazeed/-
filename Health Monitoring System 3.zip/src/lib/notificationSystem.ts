// SMS/WhatsApp Notification System for Companions

import { API_BASE, publicAnonKey } from './supabase';

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

export interface NotificationPayload {
  pilgrimId: string;
  pilgrimName: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  riskType: string;
  message: string;
  location?: {
    lat: number;
    lng: number;
  };
  companionPhone: string;
  companionName: string;
  language: 'ar' | 'en';
}

export interface NotificationResult {
  success: boolean;
  messageSid?: string;
  error?: string;
}

// Send SMS notification to companion
export async function sendSMSToCompanion(payload: NotificationPayload): Promise<NotificationResult> {
  try {
    const response = await fetch(`${API_BASE}/send-sms-notification`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to send SMS');
    }

    return response.json();
  } catch (error) {
    console.error('SMS notification error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Send WhatsApp message to companion
export async function sendWhatsAppToCompanion(payload: NotificationPayload): Promise<NotificationResult> {
  try {
    const response = await fetch(`${API_BASE}/send-whatsapp-notification`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to send WhatsApp');
    }

    return response.json();
  } catch (error) {
    console.error('WhatsApp notification error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Send notification to all companions (SMS + WhatsApp)
export async function notifyAllCompanions(
  pilgrimId: string,
  companions: Array<{ name: string; phone: string; type: string }>,
  alertData: {
    riskLevel: 'low' | 'medium' | 'high' | 'critical';
    riskType: string;
    message: string;
    location?: { lat: number; lng: number };
  },
  language: 'ar' | 'en' = 'ar'
): Promise<NotificationResult[]> {
  const results: NotificationResult[] = [];

  for (const companion of companions) {
    const payload: NotificationPayload = {
      pilgrimId,
      pilgrimName: alertData.message,
      riskLevel: alertData.riskLevel,
      riskType: alertData.riskType,
      message: alertData.message,
      location: alertData.location,
      companionPhone: companion.phone,
      companionName: companion.name,
      language,
    };

    // Try WhatsApp first, fallback to SMS
    let result = await sendWhatsAppToCompanion(payload);
    if (!result.success) {
      result = await sendSMSToCompanion(payload);
    }

    results.push(result);
  }

  return results;
}

// Format emergency message
export function formatEmergencyMessage(
  pilgrimName: string,
  riskType: string,
  location: { lat: number; lng: number } | undefined,
  language: 'ar' | 'en'
): string {
  if (language === 'ar') {
    let message = `🚨 تنبيه طارئ!\n\nالحاج/ة ${pilgrimName} في خطر.\nنوع المخاطر: ${riskType}\n\n`;

    if (location) {
      message += `الموقع: https://www.google.com/maps?q=${location.lat},${location.lng}\n\n`;
    }

    message += `يرجى الاتصال بالحاج/ة فوراً أو التوجه إلى موقعه/ها.\nفي حالة الطوارئ اتصل بـ 997`;

    return message;
  } else {
    let message = `🚨 EMERGENCY ALERT!\n\nPilgrim ${pilgrimName} is in danger.\nRisk Type: ${riskType}\n\n`;

    if (location) {
      message += `Location: https://www.google.com/maps?q=${location.lat},${location.lng}\n\n`;
    }

    message += `Please contact the pilgrim immediately or go to their location.\nFor emergency, call 997`;

    return message;
  }
}

// Browser notification (for when companion is using the app)
export function showBrowserNotification(
  title: string,
  body: string,
  onClick?: () => void
): void {
  if (!('Notification' in window)) {
    console.log('Browser does not support notifications');
    return;
  }

  if (Notification.permission === 'granted') {
    const notification = new Notification(title, {
      body,
      icon: '/rafeeq-icon.png',
      badge: '/rafeeq-badge.png',
      tag: 'rafeeq-emergency',
      requireInteraction: true,
      vibrate: [200, 100, 200],
    });

    notification.onclick = () => {
      window.focus();
      onClick?.();
      notification.close();
    };
  } else if (Notification.permission !== 'denied') {
    Notification.requestPermission().then((permission) => {
      if (permission === 'granted') {
        showBrowserNotification(title, body, onClick);
      }
    });
  }
}

// Play alert sound
export function playAlertSound(type: 'warning' | 'critical' = 'warning'): void {
  const audio = new Audio(
    type === 'critical'
      ? 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFAxJn+DyvmwhBTGH0fPTgjMGHm7A7+OZQA=='
      : 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFAxJn+DyvmwhBTGH0fPTgjMGHm7A7+OZQA=='
  );

  audio.play().catch((e) => console.log('Audio play failed:', e));
}
