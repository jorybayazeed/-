// Medication Reminder API

import { API_BASE, publicAnonKey } from './supabase';

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

export interface Medication {
  id?: string;
  name: string;
  dosage: string;
  frequency: number;
  times: string[];
  pilgrim_id: string;
  created_at?: string;
}

export async function createMedication(medication: Omit<Medication, 'id' | 'created_at'>): Promise<Medication> {
  const response = await fetch(`${API_BASE}/medications`, {
    method: 'POST',
    headers,
    body: JSON.stringify(medication),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to create medication');
  }

  return response.json();
}

export async function getMedications(pilgrimId: string): Promise<Medication[]> {
  const response = await fetch(`${API_BASE}/medications/${pilgrimId}`, {
    headers,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to fetch medications');
  }

  return response.json();
}

export async function deleteMedication(id: string): Promise<void> {
  const response = await fetch(`${API_BASE}/medications/${id}`, {
    method: 'DELETE',
    headers,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to delete medication');
  }
}
