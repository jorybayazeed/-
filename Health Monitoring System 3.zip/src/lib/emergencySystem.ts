// Emergency Alert and Escalation System

import { API_BASE, publicAnonKey } from './supabase';
import { notifyAllCompanions, showBrowserNotification, playAlertSound } from './notificationSystem';
import { createHealthAlert } from './api';

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

export interface EmergencyAlert {
  id?: string;
  pilgrim_id: string;
  pilgrim_name: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: 'fall' | 'heart_attack' | 'heat_stroke' | 'dehydration' | 'lost' | 'panic' | 'other';
  description: string;
  location: {
    lat: number;
    lng: number;
  };
  vital_signs?: {
    heartRate?: number;
    oxygenLevel?: number;
    bodyTemperature?: number;
  };
  auto_escalated: boolean;
  escalation_level: number;
  created_at?: string;
  resolved?: boolean;
}

export interface EscalationResponse {
  success: boolean;
  alert_id: string;
  escalation_level: number;
  notified_parties: string[];
  estimated_response_time?: number;
}

class EmergencyAlertSystem {
  private activeAlerts: Map<string, EmergencyAlert> = new Map();
  private escalationTimers: Map<string, NodeJS.Timeout> = new Map();

  // Create emergency alert with automatic escalation
  async createEmergencyAlert(
    alert: Omit<EmergencyAlert, 'id' | 'created_at' | 'resolved' | 'auto_escalated' | 'escalation_level'>,
    companions: Array<{ name: string; phone: string; type: string }>,
    language: 'ar' | 'en' = 'ar'
  ): Promise<EscalationResponse> {
    try {
      // Determine auto-escalation based on severity
      const shouldAutoEscalate = alert.severity === 'critical' || alert.severity === 'high';

      const fullAlert: EmergencyAlert = {
        ...alert,
        auto_escalated: shouldAutoEscalate,
        escalation_level: 1,
      };

      // Create alert in database
      const createdAlert = await createHealthAlert({
        pilgrim_id: alert.pilgrim_id,
        risk_level: alert.severity,
        risk_type: alert.type,
        description: alert.description,
        location: alert.location,
      });

      fullAlert.id = createdAlert.id;
      this.activeAlerts.set(createdAlert.id, fullAlert);

      // Show browser notification
      showBrowserNotification(
        language === 'ar' ? '🚨 تنبيه طوارئ!' : '🚨 Emergency Alert!',
        this.formatAlertMessage(fullAlert, language)
      );

      // Play critical alert sound
      playAlertSound(alert.severity === 'critical' ? 'critical' : 'warning');

      const notifiedParties: string[] = [];

      // Level 1: Notify companions immediately
      if (companions.length > 0) {
        await notifyAllCompanions(
          alert.pilgrim_id,
          companions,
          {
            riskLevel: alert.severity,
            riskType: alert.type,
            message: this.formatAlertMessage(fullAlert, language),
            location: alert.location,
          },
          language
        );
        notifiedParties.push(...companions.map(c => c.name));
      }

      // Auto-escalate if critical
      if (shouldAutoEscalate) {
        // Level 2: Notify medical team after 2 minutes if not resolved
        this.scheduleEscalation(createdAlert.id, 2, async () => {
          await this.escalateToMedicalTeam(createdAlert.id, language);
        });

        // Level 3: Notify emergency services after 5 minutes if not resolved
        this.scheduleEscalation(createdAlert.id, 5, async () => {
          await this.escalateToEmergencyServices(createdAlert.id, language);
        });
      }

      return {
        success: true,
        alert_id: createdAlert.id,
        escalation_level: 1,
        notified_parties: notifiedParties,
        estimated_response_time: this.estimateResponseTime(alert.severity, alert.location),
      };
    } catch (error) {
      console.error('Error creating emergency alert:', error);
      throw error;
    }
  }

  // Schedule escalation after a delay
  private scheduleEscalation(alertId: string, delayMinutes: number, action: () => Promise<void>): void {
    const timerId = setTimeout(async () => {
      const alert = this.activeAlerts.get(alertId);
      if (alert && !alert.resolved) {
        await action();
      }
      this.escalationTimers.delete(alertId);
    }, delayMinutes * 60 * 1000);

    this.escalationTimers.set(`${alertId}-level-${delayMinutes}`, timerId);
  }

  // Escalate to medical team
  private async escalateToMedicalTeam(alertId: string, language: 'ar' | 'en'): Promise<void> {
    try {
      const alert = this.activeAlerts.get(alertId);
      if (!alert || alert.resolved) return;

      alert.escalation_level = 2;

      const response = await fetch(`${API_BASE}/escalate-to-medical`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          alert_id: alertId,
          alert,
          language,
        }),
      });

      if (response.ok) {
        showBrowserNotification(
          language === 'ar' ? '⚕️ تم التصعيد للفريق الطبي' : '⚕️ Escalated to Medical Team',
          language === 'ar'
            ? `تم إخطار الفريق الطبي بحالة ${alert.pilgrim_name}`
            : `Medical team notified about ${alert.pilgrim_name}`
        );
      }
    } catch (error) {
      console.error('Error escalating to medical team:', error);
    }
  }

  // Escalate to emergency services (997)
  private async escalateToEmergencyServices(alertId: string, language: 'ar' | 'en'): Promise<void> {
    try {
      const alert = this.activeAlerts.get(alertId);
      if (!alert || alert.resolved) return;

      alert.escalation_level = 3;

      const response = await fetch(`${API_BASE}/escalate-to-emergency`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          alert_id: alertId,
          alert,
          language,
        }),
      });

      if (response.ok) {
        showBrowserNotification(
          language === 'ar' ? '🚑 تم التصعيد لخدمات الطوارئ' : '🚑 Escalated to Emergency Services',
          language === 'ar'
            ? `تم إخطار خدمات الطوارئ (997) بحالة ${alert.pilgrim_name}`
            : `Emergency services (997) notified about ${alert.pilgrim_name}`
        );
      }
    } catch (error) {
      console.error('Error escalating to emergency services:', error);
    }
  }

  // Resolve alert and cancel escalations
  async resolveAlert(alertId: string): Promise<void> {
    const alert = this.activeAlerts.get(alertId);
    if (alert) {
      alert.resolved = true;

      // Cancel all pending escalations
      this.escalationTimers.forEach((timer, key) => {
        if (key.startsWith(alertId)) {
          clearTimeout(timer);
          this.escalationTimers.delete(key);
        }
      });

      // Update in database
      try {
        await fetch(`${API_BASE}/alerts/${alertId}/resolve`, {
          method: 'PUT',
          headers,
        });
      } catch (error) {
        console.error('Error resolving alert:', error);
      }

      this.activeAlerts.delete(alertId);
    }
  }

  // Format alert message
  private formatAlertMessage(alert: EmergencyAlert, language: 'ar' | 'en'): string {
    const typeLabels = {
      ar: {
        fall: 'سقوط',
        heart_attack: 'نوبة قلبية',
        heat_stroke: 'ضربة شمس',
        dehydration: 'جفاف',
        lost: 'فقدان',
        panic: 'حالة ذعر',
        other: 'أخرى',
      },
      en: {
        fall: 'Fall Detected',
        heart_attack: 'Heart Attack',
        heat_stroke: 'Heat Stroke',
        dehydration: 'Dehydration',
        lost: 'Lost',
        panic: 'Panic',
        other: 'Other',
      },
    };

    const severityLabels = {
      ar: { low: 'منخفض', medium: 'متوسط', high: 'عالي', critical: 'حرج' },
      en: { low: 'Low', medium: 'Medium', high: 'High', critical: 'Critical' },
    };

    if (language === 'ar') {
      return `🚨 طوارئ: ${typeLabels.ar[alert.type]}\nالخطورة: ${severityLabels.ar[alert.severity]}\n${alert.description}\n📍 الموقع: https://www.google.com/maps?q=${alert.location.lat},${alert.location.lng}`;
    } else {
      return `🚨 Emergency: ${typeLabels.en[alert.type]}\nSeverity: ${severityLabels.en[alert.severity]}\n${alert.description}\n📍 Location: https://www.google.com/maps?q=${alert.location.lat},${alert.location.lng}`;
    }
  }

  // Estimate response time based on severity and location
  private estimateResponseTime(severity: string, location: { lat: number; lng: number }): number {
    // Base response time in minutes
    let baseTime = 15;

    if (severity === 'critical') baseTime = 5;
    else if (severity === 'high') baseTime = 10;
    else if (severity === 'medium') baseTime = 15;

    // Add location factor (closer to holy sites = faster response)
    const kaaba = { lat: 21.4225, lng: 39.8262 };
    const distance = this.calculateDistance(location.lat, location.lng, kaaba.lat, kaaba.lng);

    // Add 1 minute per km
    const locationFactor = Math.min(distance / 1000, 10);

    return Math.round(baseTime + locationFactor);
  }

  // Calculate distance between two points
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in meters
  }

  // Get active alerts
  getActiveAlerts(): EmergencyAlert[] {
    return Array.from(this.activeAlerts.values());
  }

  // Get alert by ID
  getAlert(alertId: string): EmergencyAlert | undefined {
    return this.activeAlerts.get(alertId);
  }
}

export const emergencySystem = new EmergencyAlertSystem();
