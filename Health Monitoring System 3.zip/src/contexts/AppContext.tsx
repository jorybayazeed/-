import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'ar' | 'en';
type UserRole = 'pilgrim' | 'companion' | 'medical_team' | null;

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  currentPilgrimId: string | null;
  setCurrentPilgrimId: (id: string | null) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    appName: 'رفيق',
    appDescription: 'نظام ذكاء صحي وقائي لاكتشاف المخاطر الصحية الصامتة',
    forPilgrims: 'للحجاج وكبار السن',
    registerPilgrim: 'تسجيل حاج',
    registerMedicalTeam: 'تسجيل فريق طبي',
    selectLanguage: 'اختر اللغة',
    pilgrimRegistration: 'تسجيل بيانات الحاج',
    name: 'الاسم',
    age: 'العمر',
    gender: 'الجنس',
    male: 'ذكر',
    female: 'أنثى',
    nationality: 'الجنسية',
    phone: 'رقم التواصل',
    chronicDiseases: 'الأمراض المزمنة',
    medications: 'الأدوية المستخدمة',
    companionsCount: 'عدد المرافقين',
    submit: 'تسجيل',
    next: 'التالي',
    addCompanions: 'إضافة المرافقين',
    companionName: 'اسم المرافق',
    companionPhone: 'رقم المرافق',
    primaryCompanion: 'مرافق رئيسي',
    backupCompanion1: 'مرافق احتياطي 1',
    backupCompanion2: 'مرافق احتياطي 2',
    currentStatus: 'الحالة الحالية',
    activityHours: 'ساعات النشاط',
    waterReminder: 'تذكير شرب الماء',
    medicationReminder: 'تذكير الأدوية',
    riskLevel: 'مستوى الخطورة',
    safe: 'آمن',
    needsRest: 'يحتاج راحة',
    mediumRisk: 'خطر متوسط',
    highRisk: 'خطر مرتفع',
    heatExhaustion: 'احتمال إجهاد حراري',
    dehydration: 'احتمال جفاف شديد',
    physicalFatigue: 'إرهاق جسدي',
    mentalConfusion: 'احتمال فقدان تركيز',
    alertSent: 'تم إرسال تنبيه للمرافقين',
    medicalDashboard: 'لوحة الفريق الطبي',
    activeCases: 'الحالات النشطة',
    highRiskCases: 'حالات عالية الخطورة',
    totalPilgrims: 'إجمالي الحجاج',
    commonDiseases: 'الأمراض الأكثر انتشاراً',
    voiceTranslation: 'الترجمة الصوتية السياقية',
    speakNow: 'تحدث الآن',
    translating: 'جاري الترجمة...',
    // Medical terminology
    medicalHistory: 'التاريخ المرضي',
    allergies: 'الحساسية',
    bloodPressure: 'ضغط الدم',
    diabetes: 'السكري',
    heartDisease: 'أمراض القلب',
    asthma: 'الربو',
    // Medication reminders
    addMedication: 'إضافة دواء',
    medicationName: 'اسم الدواء',
    dosage: 'الجرعة',
    frequency: 'عدد المرات يومياً',
    timeToTake: 'وقت تناول الدواء',
    medicationAdded: 'تم إضافة الدواء بنجاح',
    takeMedication: 'حان موعد تناول الدواء',
    // Health monitoring
    healthMonitoring: 'المتابعة الصحية',
    activityTracking: 'متابعة النشاط',
    environmentMonitoring: 'مراقبة البيئة',
    temperature: 'درجة الحرارة',
    humidity: 'الرطوبة',
    location: 'الموقع',
    lastUpdate: 'آخر تحديث',
    // Accessibility
    readAloud: 'قراءة النص',
    increaseFontSize: 'تكبير الخط',
    decreaseFontSize: 'تصغير الخط',
    highContrast: 'تباين عالي',
    // Voice translation
    translateToEnglish: 'ترجمة للإنجليزية',
    translateToArabic: 'ترجمة للعربية',
    listening: 'جاري الاستماع...',
    // Dashboard
    statistics: 'الإحصائيات',
    recentAlerts: 'التنبيهات الأخيرة',
    riskAnalysis: 'تحليل المخاطر',
    viewDetails: 'عرض التفاصيل',
    resolveAlert: 'حل التنبيه',
    // Common phrases
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تعديل',
    loading: 'جاري التحميل...',
    error: 'خطأ',
    success: 'نجاح',
    warning: 'تحذير',
    // Medical team
    medicalTeamName: 'اسم الفريق الطبي',
    role: 'الدور',
    doctor: 'طبيب',
    nurse: 'ممرض',
    paramedic: 'مسعف',
    specialization: 'التخصص',
    emergencyContact: 'جهة الاتصال للطوارئ',
  },
  en: {
    appName: 'Rafeeq',
    appDescription: 'Smart Health System for Silent Health Risk Detection',
    forPilgrims: 'For Pilgrims and Elderly People',
    registerPilgrim: 'Register Pilgrim',
    registerMedicalTeam: 'Register Medical Team',
    selectLanguage: 'Select Language',
    pilgrimRegistration: 'Pilgrim Registration',
    name: 'Name',
    age: 'Age',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    nationality: 'Nationality',
    phone: 'Phone Number',
    chronicDiseases: 'Chronic Diseases',
    medications: 'Current Medications',
    companionsCount: 'Number of Companions',
    submit: 'Submit',
    next: 'Next',
    addCompanions: 'Add Companions',
    companionName: 'Companion Name',
    companionPhone: 'Companion Phone',
    primaryCompanion: 'Primary Companion',
    backupCompanion1: 'Backup Companion 1',
    backupCompanion2: 'Backup Companion 2',
    currentStatus: 'Current Status',
    activityHours: 'Activity Hours',
    waterReminder: 'Water Reminder',
    medicationReminder: 'Medication Reminder',
    riskLevel: 'Risk Level',
    safe: 'Safe',
    needsRest: 'Needs Rest',
    mediumRisk: 'Medium Risk',
    highRisk: 'High Risk',
    heatExhaustion: 'Possible Heat Exhaustion',
    dehydration: 'Severe Dehydration Risk',
    physicalFatigue: 'Physical Fatigue',
    mentalConfusion: 'Mental Confusion Risk',
    alertSent: 'Alert sent to companions',
    medicalDashboard: 'Medical Team Dashboard',
    activeCases: 'Active Cases',
    highRiskCases: 'High Risk Cases',
    totalPilgrims: 'Total Pilgrims',
    commonDiseases: 'Common Diseases',
    voiceTranslation: 'Contextual Voice Translation',
    speakNow: 'Speak Now',
    translating: 'Translating...',
    // Medical terminology
    medicalHistory: 'Medical History',
    allergies: 'Allergies',
    bloodPressure: 'Blood Pressure',
    diabetes: 'Diabetes',
    heartDisease: 'Heart Disease',
    asthma: 'Asthma',
    // Medication reminders
    addMedication: 'Add Medication',
    medicationName: 'Medication Name',
    dosage: 'Dosage',
    frequency: 'Times per day',
    timeToTake: 'Time to Take',
    medicationAdded: 'Medication added successfully',
    takeMedication: 'Time to take medication',
    // Health monitoring
    healthMonitoring: 'Health Monitoring',
    activityTracking: 'Activity Tracking',
    environmentMonitoring: 'Environment Monitoring',
    temperature: 'Temperature',
    humidity: 'Humidity',
    location: 'Location',
    lastUpdate: 'Last Update',
    // Accessibility
    readAloud: 'Read Aloud',
    increaseFontSize: 'Increase Font Size',
    decreaseFontSize: 'Decrease Font Size',
    highContrast: 'High Contrast',
    // Voice translation
    translateToEnglish: 'Translate to English',
    translateToArabic: 'Translate to Arabic',
    listening: 'Listening...',
    // Dashboard
    statistics: 'Statistics',
    recentAlerts: 'Recent Alerts',
    riskAnalysis: 'Risk Analysis',
    viewDetails: 'View Details',
    resolveAlert: 'Resolve Alert',
    // Common phrases
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    warning: 'Warning',
    // Medical team
    medicalTeamName: 'Medical Team Name',
    role: 'Role',
    doctor: 'Doctor',
    nurse: 'Nurse',
    paramedic: 'Paramedic',
    specialization: 'Specialization',
    emergencyContact: 'Emergency Contact',
  },
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('ar');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [currentPilgrimId, setCurrentPilgrimId] = useState<string | null>(null);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['ar']] || key;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        userRole,
        setUserRole,
        currentPilgrimId,
        setCurrentPilgrimId,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
