import rafeeqLogoDataUri from './rafeeqLogoData';

interface RafeeqLogoProps {
  className?: string;
}

export function RafeeqLogo({ className = 'w-10 h-10' }: RafeeqLogoProps) {
  return (
    <img
      src={rafeeqLogoDataUri}
      alt="Rafeeq logo"
      className={`${className} object-contain`}
    />
  );
}
