import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProvider } from "../contexts/AppContext";
import { Toaster } from "sonner";
import { LandingPage } from "../components/LandingPage";
import { PilgrimLogin } from "../components/PilgrimLogin";
import { PilgrimFlow } from "../components/PilgrimFlow";
import { EnhancedPilgrimMonitoring } from "../components/EnhancedPilgrimMonitoring";
import { MedicalTeamLogin } from "../components/MedicalTeamLogin";
import { MedicalFlow } from "../components/MedicalFlow";
import { EnhancedMedicalDashboard } from "../components/EnhancedMedicalDashboard";
import { AdminLogin } from "../components/AdminLogin";
import { AdminDashboard } from "../components/AdminDashboard";
import { AccessibilityToolbar } from "../components/AccessibilityToolbar";

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-white">
          <Routes>
            <Route path="/" element={<LandingPage />} />

            {/* Pilgrim Routes */}
            <Route
              path="/login-pilgrim"
              element={<PilgrimLogin />}
            />
            <Route
              path="/register-pilgrim"
              element={<PilgrimFlow />}
            />
            <Route
              path="/monitoring"
              element={<EnhancedPilgrimMonitoring />}
            />

            {/* Medical Team Routes */}
            <Route
              path="/login-medical-team"
              element={<MedicalTeamLogin />}
            />
            <Route
              path="/register-medical-team"
              element={<MedicalFlow />}
            />
            <Route
              path="/medical-dashboard"
              element={<EnhancedMedicalDashboard />}
            />

            {/* Admin Routes */}
            <Route
              path="/login-admin"
              element={<AdminLogin />}
            />
            <Route
              path="/admin-dashboard"
              element={<AdminDashboard />}
            />
          </Routes>
          <AccessibilityToolbar />
          <Toaster position="top-center" richColors />
        </div>
      </BrowserRouter>
    </AppProvider>
  );
}