import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { createMedicalTeamMember } from '../lib/api';
import { ArrowLeft, ArrowRight, Loader2, Stethoscope, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { RafeeqLogo } from '../app/components/RafeeqLogo';

export function MedicalFlow() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, language, setUserRole } = useApp();
  const [loading, setLoading] = useState(false);
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  // Get phone number from location state if coming from login
  const phoneFromLogin = location.state?.phone || '';

  const [formData, setFormData] = useState({
    name: '',
    role: '',
    phone: phoneFromLogin,
    team_id: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await createMedicalTeamMember({
        name: formData.name,
        role: formData.role,
        phone: formData.phone,
        team_id: formData.team_id || undefined,
      });

      toast.success(
        isRTL
          ? 'تم إرسال طلبك بنجاح - في انتظار موافقة الإدارة'
          : 'Request submitted successfully - Awaiting admin approval',
        { duration: 4000 }
      );
      
      setTimeout(() => navigate('/'), 2000);
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ في إرسال الطلب' : 'Error submitting request');
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    'w-full px-4 py-3 rounded-xl border border-border bg-input-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all shadow-sm';
  const labelClass = 'block text-sm font-semibold text-foreground/80 mb-1.5';

  return (
    <div
      className={`min-h-screen bg-background py-10 px-4 ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      {/* Top accent */}
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-primary to-accent z-50" />

      <div className="max-w-2xl mx-auto">
        {/* Back + Logo */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors font-medium"
          >
            {isRTL ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
            {isRTL ? 'رجوع' : 'Back'}
          </button>
          <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
        </div>

        {/* Card */}
        <div className="bg-white border border-border rounded-2xl shadow-lg p-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 bg-accent/10 rounded-xl flex items-center justify-center shadow-inner">
              <Stethoscope className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'تسجيل الفريق الطبي' : 'Medical Team Registration'}
              </h2>
              <p className="text-sm text-muted-foreground">
                {isRTL ? 'للوصول إلى لوحة متابعة الحجاج' : 'Access pilgrim monitoring dashboard'}
              </p>
            </div>
          </div>

          <div className="h-px bg-border my-6" />

          {/* Info banner - Updated */}
          <div className="bg-amber-500/8 border border-amber-500/20 rounded-xl p-4 mb-6 flex items-start gap-3">
            <div className="w-8 h-8 bg-amber-500/15 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground mb-1">
                {isRTL ? 'نموذج طلب التسجيل' : 'Registration Request Form'}
              </p>
              <p className="text-xs text-foreground/75 leading-relaxed">
                {isRTL
                  ? 'سيتم مراجعة طلبك من قبل الإدارة. بعد الموافقة، يمكنك تسجيل الدخول باستخدام رقم الهاتف للوصول إلى لوحة المراقبة.'
                  : 'Your request will be reviewed by admin. After approval, you can login using your phone number to access the monitoring dashboard.'}
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className={labelClass}>
                {isRTL ? 'الاسم الكامل' : 'Full Name'}
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className={inputClass}
                placeholder={isRTL ? 'اسمك الكامل' : 'Your full name'}
              />
            </div>

            <div>
              <label className={labelClass}>
                {isRTL ? 'الوظيفة' : 'Role'}
              </label>
              <select
                required
                value={formData.role}
                onChange={e => setFormData({ ...formData, role: e.target.value })}
                className={inputClass}
              >
                <option value="">{isRTL ? 'اختر الوظيفة' : 'Select Role'}</option>
                <option value="doctor">{isRTL ? 'طبيب' : 'Doctor'}</option>
                <option value="nurse">{isRTL ? 'ممرض/ة' : 'Nurse'}</option>
                <option value="paramedic">{isRTL ? 'مسعف' : 'Paramedic'}</option>
                <option value="coordinator">{isRTL ? 'منسق صحي' : 'Health Coordinator'}</option>
              </select>
            </div>

            <div>
              <label className={labelClass}>
                {isRTL ? 'رقم التواصل' : 'Phone Number'}
              </label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className={inputClass}
                placeholder="+966 xxx xxx xxx"
              />
            </div>

            <div>
              <label className={labelClass}>
                {isRTL ? 'رقم الفريق (اختياري)' : 'Team ID (Optional)'}
              </label>
              <input
                type="text"
                value={formData.team_id}
                onChange={e => setFormData({ ...formData, team_id: e.target.value })}
                className={inputClass}
                placeholder={isRTL ? 'مثال: TEAM-001' : 'Example: TEAM-001'}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-white py-4 rounded-xl font-bold hover:bg-primary/90 active:scale-[0.99] transition-all shadow-lg shadow-primary/20 disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {isRTL ? 'جاري التسجيل...' : 'Registering...'}
                </>
              ) : (
                isRTL ? 'التسجيل والدخول' : 'Register & Enter'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}