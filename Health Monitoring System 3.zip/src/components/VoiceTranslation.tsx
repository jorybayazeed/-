import { useState, useEffect } from 'react';
import { Mic, Volume2, X } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { translateVoice } from '../lib/translationApi';
import { toast } from 'sonner';

export function VoiceTranslation({ onClose }: { onClose?: () => void }) {
  const { t, language } = useApp();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [translation, setTranslation] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [isSpeechSupported, setIsSpeechSupported] = useState(true);

  useEffect(() => {
    // Check if speech recognition is available
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      try {
        const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
        const recognitionInstance = new SpeechRecognition();
        recognitionInstance.continuous = false;
        recognitionInstance.lang = language === 'ar' ? 'ar-SA' : 'en-US';
        recognitionInstance.interimResults = false;

        recognitionInstance.onresult = async (event: any) => {
          const text = event.results[0][0].transcript;
          setTranscript(text);
          setIsListening(false);

          // Translate
          setIsTranslating(true);
          try {
            const result = await translateVoice(
              text,
              language,
              language === 'ar' ? 'en' : 'ar'
            );
            setTranslation(result.translated);

            // Speak translation
            speakText(result.translated, language === 'ar' ? 'en-US' : 'ar-SA');
          } catch (error) {
            console.error('Translation error:', error);
          }
          setIsTranslating(false);
        };

        recognitionInstance.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          setIsListening(false);
          
          // Handle permission denied gracefully
          if (event.error === 'not-allowed') {
            toast.error(
              language === 'ar' 
                ? 'الرجاء السماح باستخدام الميكروفون في إعدادات المتصفح' 
                : 'Please allow microphone access in browser settings'
            );
            setIsSpeechSupported(false);
          }
        };

        setRecognition(recognitionInstance);
        setIsSpeechSupported(true);
      } catch (error) {
        console.warn('Speech recognition not supported:', error);
        setIsSpeechSupported(false);
      }
    } else {
      console.warn('Speech recognition not supported in this browser');
      setIsSpeechSupported(false);
    }
  }, [language]);

  const startListening = () => {
    if (!isSpeechSupported) {
      toast.error(
        language === 'ar' 
          ? 'التعرف على الصوت غير مدعوم في هذا المتصفح' 
          : 'Speech recognition is not supported in this browser'
      );
      return;
    }

    if (recognition) {
      setTranscript('');
      setTranslation('');
      try {
        recognition.start();
        setIsListening(true);
      } catch (error) {
        console.warn('Could not start recognition:', error);
        toast.error(
          language === 'ar' 
            ? 'لا يمكن بدء التعرف على الصوت. استخدم العبارات السريعة بدلاً من ذلك.' 
            : 'Cannot start speech recognition. Use quick phrases instead.'
        );
      }
    }
  };

  const speakText = (text: string, lang: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  const speakTranscript = () => {
    if (transcript) {
      speakText(transcript, language === 'ar' ? 'ar-SA' : 'en-US');
    }
  };

  const speakTranslation = () => {
    if (translation) {
      speakText(translation, language === 'ar' ? 'en-US' : 'ar-SA');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6" style={{ direction: language === 'ar' ? 'rtl' : 'ltr' }}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: '#0C8547' }}>{t('voiceTranslation')}</h2>
          {onClose && (
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X size={24} />
            </button>
          )}
        </div>

        <div className="space-y-6">
          {/* Microphone Button */}
          <div className="flex justify-center">
            <button
              onClick={startListening}
              disabled={isListening || isTranslating}
              className="relative"
            >
              <div
                className={`w-32 h-32 rounded-full flex items-center justify-center transition-all ${
                  isListening
                    ? 'bg-red-500 animate-pulse'
                    : 'bg-gradient-to-br from-[#0C8547] to-[#0a6d3a] hover:scale-105'
                }`}
              >
                <Mic size={64} className="text-white" />
              </div>
              {isListening && (
                <div className="absolute inset-0 rounded-full border-4 border-red-500 animate-ping" />
              )}
            </button>
          </div>

          {/* Status */}
          <div className="text-center">
            {isListening && (
              <p className="text-lg font-medium text-red-600">{t('listening')}</p>
            )}
            {isTranslating && (
              <p className="text-lg font-medium" style={{ color: '#0C8547' }}>{t('translating')}</p>
            )}
            {!isListening && !isTranslating && !transcript && (
              <p className="text-gray-600">{t('speakNow')}</p>
            )}
          </div>

          {/* Transcript */}
          {transcript && (
            <div className="border-2 rounded-xl p-4" style={{ borderColor: '#0C8547' }}>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold" style={{ color: '#0C8547' }}>
                  {language === 'ar' ? 'النص الأصلي' : 'Original Text'}
                </h3>
                <button
                  onClick={speakTranscript}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <Volume2 size={20} style={{ color: '#0C8547' }} />
                </button>
              </div>
              <p className="text-lg" dir={language === 'ar' ? 'rtl' : 'ltr'}>{transcript}</p>
            </div>
          )}

          {/* Translation */}
          {translation && (
            <div className="border-2 rounded-xl p-4" style={{ borderColor: '#D4AF37' }}>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold" style={{ color: '#D4AF37' }}>
                  {language === 'ar' ? 'الترجمة' : 'Translation'}
                </h3>
                <button
                  onClick={speakTranslation}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <Volume2 size={20} style={{ color: '#D4AF37' }} />
                </button>
              </div>
              <p className="text-lg" dir={language === 'ar' ? 'ltr' : 'rtl'}>{translation}</p>
            </div>
          )}

          {/* Medical Quick Phrases */}
          <div className="border-t-2 border-gray-200 pt-4">
            <h3 className="font-semibold mb-3 text-gray-700">
              {language === 'ar' ? 'عبارات طبية سريعة' : 'Quick Medical Phrases'}
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { ar: 'أشعر بدوخة', en: 'I feel dizzy' },
                { ar: 'أحتاج ماء', en: 'I need water' },
                { ar: 'عندي ألم في الصدر', en: 'I have chest pain' },
                { ar: 'أحتاج مساعدة', en: 'I need help' },
              ].map((phrase, index) => (
                <button
                  key={index}
                  onClick={() => {
                    const text = language === 'ar' ? phrase.ar : phrase.en;
                    setTranscript(text);
                    translateVoice(
                      text,
                      language,
                      language === 'ar' ? 'en' : 'ar'
                    ).then(result => {
                      setTranslation(result.translated);
                      speakText(result.translated, language === 'ar' ? 'en-US' : 'ar-SA');
                    });
                  }}
                  className="px-3 py-2 border-2 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                  style={{ borderColor: '#0C8547', color: '#0C8547' }}
                >
                  {language === 'ar' ? phrase.ar : phrase.en}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}