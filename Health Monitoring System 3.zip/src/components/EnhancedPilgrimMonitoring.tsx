import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { RafeeqLogo } from '../app/components/RafeeqLogo';
import { HealthMonitor } from './HealthMonitor';
import { MedicationReminders } from './MedicationReminders';
import { VoiceTranslation } from './VoiceTranslation';
import { RealTimeMonitoringDashboard } from './RealTimeMonitoringDashboard';
import { Activity, Pill, Languages, Heart, ArrowLeft, Menu, X, Radio } from 'lucide-react';

export function EnhancedPilgrimMonitoring() {
  const { t, language, currentPilgrimId } = useApp();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'health' | 'medications' | 'translation' | 'realtime'>('health');
  const [showTranslation, setShowTranslation] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const isRTL = language === 'ar';

  if (!currentPilgrimId) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <div className="text-center">
          <RafeeqLogo size={80} className="mx-auto mb-6" />
          <h2 className="text-2xl font-bold mb-4" style={{ color: '#0C8547' }}>
            {isRTL ? 'لم يتم العثور على حاج' : 'No Pilgrim Found'}
          </h2>
          <p className="text-gray-600 mb-6">
            {isRTL ? 'يرجى التسجيل أولاً' : 'Please register first'}
          </p>
          <button
            onClick={() => navigate('/register-pilgrim')}
            className="px-6 py-3 rounded-lg text-white font-bold hover:opacity-90 transition-opacity"
            style={{ backgroundColor: '#0C8547' }}
          >
            {isRTL ? 'التسجيل' : 'Register'}
          </button>
        </div>
      </div>
    );
  }

  const tabs = [
    {
      id: 'realtime',
      icon: <Radio size={20} />,
      label: language === 'ar' ? 'المراقبة المباشرة' : 'Real-Time Monitor',
      color: '#DC2626'
    },
    {
      id: 'health',
      icon: <Activity size={20} />,
      label: t('healthMonitoring'),
      color: '#0C8547'
    },
    {
      id: 'medications',
      icon: <Pill size={20} />,
      label: t('medicationReminder'),
      color: '#D4AF37'
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
      {/* Top Stripe */}
      <div className="h-2 bg-gradient-to-r from-[#0C8547] via-[#0a6d3a] to-[#D4AF37]" />

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white border-b-2 shadow-md" style={{ borderColor: '#0C8547' }}>
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/')}
                className="p-2 rounded-xl hover:bg-gray-100 transition-colors md:hidden"
              >
                {isRTL ? <ArrowLeft size={24} className="rotate-180" style={{ color: '#0C8547' }} /> : <ArrowLeft size={24} style={{ color: '#0C8547' }} />}
              </button>
              <RafeeqLogo size={48} />
            </div>

            <div className="flex items-center gap-3">
              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                      activeTab === tab.id
                        ? 'text-white shadow-lg'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                    style={activeTab === tab.id ? { backgroundColor: tab.color } : {}}
                  >
                    {tab.icon}
                    <span className="hidden lg:inline">{tab.label}</span>
                  </button>
                ))}

                <button
                  onClick={() => setShowTranslation(true)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-white transition-all hover:opacity-90"
                  style={{ backgroundColor: '#D4AF37' }}
                >
                  <Languages size={20} />
                  <span className="hidden lg:inline">{t('voiceTranslation')}</span>
                </button>
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="md:hidden p-2 rounded-lg"
                style={{ backgroundColor: '#0C854715' }}
              >
                {showMenu ? <X size={24} style={{ color: '#0C8547' }} /> : <Menu size={24} style={{ color: '#0C8547' }} />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {showMenu && (
            <div className="md:hidden mt-4 pb-4 border-t-2 pt-4" style={{ borderColor: '#0C8547' }}>
              <div className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id as any);
                      setShowMenu(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all ${
                      activeTab === tab.id
                        ? 'text-white shadow-lg'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                    style={activeTab === tab.id ? { backgroundColor: tab.color } : {}}
                  >
                    {tab.icon}
                    {tab.label}
                  </button>
                ))}

                <button
                  onClick={() => {
                    setShowTranslation(true);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg font-medium text-white transition-all"
                  style={{ backgroundColor: '#D4AF37' }}
                >
                  <Languages size={20} />
                  {t('voiceTranslation')}
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Card */}
        <div className="bg-gradient-to-r from-[#0C8547] to-[#0a6d3a] rounded-xl p-6 text-white shadow-lg mb-8">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-white/20 rounded-full">
              <Heart size={32} />
            </div>
            <div>
              <h1 className="text-2xl font-bold mb-1">
                {isRTL ? 'مرحباً بك في رفيق' : 'Welcome to Rafeeq'}
              </h1>
              <p className="text-white/90">
                {isRTL ? 'نظام المتابعة الصحية الذكي لرحلة حج آمنة' : 'Smart health monitoring for a safe Hajj journey'}
              </p>
            </div>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'realtime' ? (
          <RealTimeMonitoringDashboard
            pilgrimId={currentPilgrimId}
            pilgrimName={language === 'ar' ? 'الحاج' : 'Pilgrim'}
            companions={[]}
          />
        ) : (
          <div className="bg-white rounded-xl shadow-lg p-6">
            {activeTab === 'health' && (
              <HealthMonitor pilgrimId={currentPilgrimId} />
            )}

            {activeTab === 'medications' && (
              <MedicationReminders pilgrimId={currentPilgrimId} />
            )}
          </div>
        )}

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white border-2 rounded-xl p-6 text-center" style={{ borderColor: '#0C8547' }}>
            <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center" style={{ backgroundColor: '#0C854715' }}>
              <Heart size={32} style={{ color: '#0C8547' }} />
            </div>
            <h3 className="font-bold mb-2" style={{ color: '#0C8547' }}>
              {isRTL ? 'صحتك أولوية' : 'Your Health is Priority'}
            </h3>
            <p className="text-sm text-gray-600">
              {isRTL ? 'نتابع صحتك على مدار الساعة' : 'We monitor your health 24/7'}
            </p>
          </div>

          <div className="bg-white border-2 rounded-xl p-6 text-center" style={{ borderColor: '#D4AF37' }}>
            <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center" style={{ backgroundColor: '#D4AF3715' }}>
              <Languages size={32} style={{ color: '#D4AF37' }} />
            </div>
            <h3 className="font-bold mb-2" style={{ color: '#D4AF37' }}>
              {isRTL ? 'ترجمة فورية' : 'Instant Translation'}
            </h3>
            <p className="text-sm text-gray-600">
              {isRTL ? 'تواصل بدون حواجز لغوية' : 'Communicate without language barriers'}
            </p>
          </div>

          <div className="bg-white border-2 rounded-xl p-6 text-center" style={{ borderColor: '#0C8547' }}>
            <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center" style={{ backgroundColor: '#0C854715' }}>
              <Pill size={32} style={{ color: '#0C8547' }} />
            </div>
            <h3 className="font-bold mb-2" style={{ color: '#0C8547' }}>
              {isRTL ? 'تذكير بالأدوية' : 'Medication Reminders'}
            </h3>
            <p className="text-sm text-gray-600">
              {isRTL ? 'لن تنسى موعد دوائك' : 'Never miss your medication'}
            </p>
          </div>
        </div>
      </main>

      {/* Voice Translation Modal */}
      {showTranslation && (
        <VoiceTranslation onClose={() => setShowTranslation(false)} />
      )}
    </div>
  );
}
