import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { ArrowLeft, ArrowRight, Loader2, Shield, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { RafeeqLogo } from '../app/components/RafeeqLogo';

export function AdminLogin() {
  const navigate = useNavigate();
  const { t, language } = useApp();
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Demo credentials: admin / admin123
      if (username === 'admin' && password === 'admin123') {
        toast.success(isRTL ? 'تم تسجيل الدخول بنجاح' : 'Login successful');
        navigate('/admin-dashboard');
      } else {
        toast.error(isRTL ? 'اسم المستخدم أو كلمة المرور غير صحيحة' : 'Invalid username or password');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ' : 'Error occurred');
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    'w-full px-4 py-3 rounded-xl border border-border bg-input-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all shadow-sm';

  return (
    <div
      className={`min-h-screen bg-background py-10 px-4 ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary z-50 shadow-sm" />

      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors font-medium"
          >
            {isRTL ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
            {isRTL ? 'رجوع' : 'Back'}
          </button>
          <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
        </div>

        <div className="bg-white border border-border rounded-2xl shadow-lg p-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center shadow-inner">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'تسجيل دخول الإدارة' : 'Admin Login'}
              </h2>
              <p className="text-sm text-muted-foreground">
                {isRTL ? 'لوحة تحكم الموافقات والإحصائيات' : 'Approvals & Analytics Dashboard'}
              </p>
            </div>
          </div>

          <div className="h-px bg-border my-6" />

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-foreground/80 mb-1.5">
                {isRTL ? 'اسم المستخدم' : 'Username'}
              </label>
              <input
                type="text"
                required
                value={username}
                onChange={e => setUsername(e.target.value)}
                className={inputClass}
                placeholder={isRTL ? 'أدخل اسم المستخدم' : 'Enter username'}
                autoComplete="username"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground/80 mb-1.5">
                {isRTL ? 'كلمة المرور' : 'Password'}
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className={inputClass}
                  placeholder={isRTL ? 'أدخل كلمة المرور' : 'Enter password'}
                  autoComplete="current-password"
                />
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" style={{ left: isRTL ? 'auto' : '12px', right: isRTL ? '12px' : 'auto' }} />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-primary to-accent text-white py-4 rounded-xl font-bold hover:opacity-90 active:scale-[0.99] transition-all shadow-lg shadow-primary/20 disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {isRTL ? 'جاري التحقق...' : 'Verifying...'}
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5" />
                  {isRTL ? 'تسجيل الدخول' : 'Login'}
                </>
              )}
            </button>
          </form>

          <div className="mt-6 p-4 bg-primary/5 border border-primary/20 rounded-xl">
            <p className="text-xs text-muted-foreground text-center leading-relaxed">
              {isRTL ? (
                <>
                  🔐 <strong>للتجربة:</strong> اسم المستخدم: <code className="bg-white px-1.5 py-0.5 rounded font-mono">admin</code> | كلمة المرور: <code className="bg-white px-1.5 py-0.5 rounded font-mono">admin123</code>
                </>
              ) : (
                <>
                  🔐 <strong>Demo:</strong> Username: <code className="bg-white px-1.5 py-0.5 rounded font-mono">admin</code> | Password: <code className="bg-white px-1.5 py-0.5 rounded font-mono">admin123</code>
                </>
              )}
            </p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-border rounded-xl text-sm">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-muted-foreground font-medium">
              {isRTL ? 'نظام إدارة آمن ومشفر' : 'Secure & Encrypted Admin System'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
