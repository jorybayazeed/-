import { useState, useEffect } from 'react';
import { Activity, Heart, Droplet, MapPin, AlertTriangle, TrendingUp, Wind, Thermometer } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { healthMonitor, type HealthMonitoringData } from '../lib/healthMonitoring';
import { gpsTracker, getNearestHolySite } from '../lib/gpsTracking';
import { notifyAllCompanions, formatEmergencyMessage, showBrowserNotification, playAlertSound } from '../lib/notificationSystem';
import { createHealthAlert } from '../lib/api';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface Props {
  pilgrimId: string;
  pilgrimName: string;
  companions?: Array<{ name: string; phone: string; type: string }>;
}

export function RealTimeMonitoringDashboard({ pilgrimId, pilgrimName, companions = [] }: Props) {
  const { t, language } = useApp();
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [monitoringData, setMonitoringData] = useState<HealthMonitoringData | null>(null);
  const [healthHistory, setHealthHistory] = useState<Array<{ time: string; heartRate: number; temp: number }>>([]);
  const [currentLocation, setCurrentLocation] = useState<string>('Unknown');
  const [riskLevel, setRiskLevel] = useState<'safe' | 'warning' | 'medium_risk' | 'high_risk'>('safe');

  useEffect(() => {
    if (isMonitoring) {
      healthMonitor.startMonitoring(
        pilgrimId,
        handleMonitoringUpdate,
        handleMonitoringError,
        10000 // Update every 10 seconds
      );
    } else {
      healthMonitor.stopMonitoring();
    }

    return () => {
      healthMonitor.stopMonitoring();
    };
  }, [isMonitoring, pilgrimId]);

  const handleMonitoringUpdate = (data: HealthMonitoringData) => {
    setMonitoringData(data);

    // Update location
    if (data.location) {
      const nearest = getNearestHolySite(data.location.latitude, data.location.longitude);
      if (nearest) {
        setCurrentLocation(`${nearest.site} (${Math.round(nearest.distance)}m)`);
      }
    }

    // Add to health history
    if (data.sensors.heartRate && data.sensors.bodyTemperature) {
      const now = new Date();
      setHealthHistory(prev => [
        ...prev.slice(-20), // Keep last 20 readings
        {
          time: `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`,
          heartRate: data.sensors.heartRate,
          temp: data.sensors.bodyTemperature,
        }
      ]);
    }

    // Analyze risk
    const risk = analyzeRisk(data);
    setRiskLevel(risk);

    // Alert if high risk
    if (risk === 'high_risk' || risk === 'medium_risk') {
      handleHighRiskAlert(data, risk);
    }
  };

  const handleMonitoringError = (error: any) => {
    console.error('Monitoring error:', error);
    toast.error(language === 'ar' ? 'خطأ في المراقبة' : 'Monitoring error');
  };

  const analyzeRisk = (data: HealthMonitoringData): 'safe' | 'warning' | 'medium_risk' | 'high_risk' => {
    let riskScore = 0;

    // Heart rate analysis
    if (data.sensors.heartRate) {
      if (data.sensors.heartRate > 120 || data.sensors.heartRate < 50) riskScore += 30;
      else if (data.sensors.heartRate > 100 || data.sensors.heartRate < 60) riskScore += 15;
    }

    // Body temperature
    if (data.sensors.bodyTemperature) {
      if (data.sensors.bodyTemperature > 38.5) riskScore += 25;
      else if (data.sensors.bodyTemperature > 37.5) riskScore += 10;
    }

    // Oxygen level
    if (data.sensors.oxygenLevel && data.sensors.oxygenLevel < 95) {
      riskScore += 20;
    }

    // Environmental factors
    if (data.environmentalData.ambientTemperature > 45) riskScore += 20;
    else if (data.environmentalData.ambientTemperature > 42) riskScore += 10;

    // Activity factors
    if (data.activityData.activityDuration > 6) riskScore += 15;
    if (data.activityData.lastWaterIntake > 120) riskScore += 20;
    if (data.activityData.walkingSpeed < 0.3 && data.activityData.isMoving) riskScore += 15;

    if (riskScore >= 70) return 'high_risk';
    if (riskScore >= 40) return 'medium_risk';
    if (riskScore >= 20) return 'warning';
    return 'safe';
  };

  const handleHighRiskAlert = async (data: HealthMonitoringData, risk: 'medium_risk' | 'high_risk') => {
    try {
      // Create alert in database
      const alert = await createHealthAlert({
        pilgrim_id: pilgrimId,
        risk_level: risk === 'high_risk' ? 'critical' : 'high',
        risk_type: 'health_monitoring',
        description: `Health monitoring detected ${risk} for ${pilgrimName}`,
        location: data.location ? { lat: data.location.latitude, lng: data.location.longitude } : { lat: 0, lng: 0 },
      });

      // Show browser notification
      showBrowserNotification(
        language === 'ar' ? '🚨 تحذير صحي' : '🚨 Health Alert',
        formatEmergencyMessage(
          pilgrimName,
          'health_monitoring',
          data.location ? { lat: data.location.latitude, lng: data.location.longitude } : undefined,
          language
        )
      );

      // Play alert sound
      playAlertSound(risk === 'high_risk' ? 'critical' : 'warning');

      // Notify companions
      if (companions.length > 0) {
        await notifyAllCompanions(
          pilgrimId,
          companions,
          {
            riskLevel: risk === 'high_risk' ? 'critical' : 'high',
            riskType: 'Health Monitoring Alert',
            message: formatEmergencyMessage(
              pilgrimName,
              'Health monitoring detected abnormal vitals',
              data.location ? { lat: data.location.latitude, lng: data.location.longitude } : undefined,
              language
            ),
            location: data.location ? { lat: data.location.latitude, lng: data.location.longitude } : undefined,
          },
          language
        );

        toast.success(language === 'ar' ? 'تم إرسال تنبيه للمرافقين' : 'Companions notified');
      }
    } catch (error) {
      console.error('Error handling alert:', error);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'high_risk': return '#DC2626';
      case 'medium_risk': return '#F59E0B';
      case 'warning': return '#EAB308';
      default: return '#10B981';
    }
  };

  const getRiskLabel = (level: string) => {
    if (language === 'ar') {
      switch (level) {
        case 'high_risk': return 'خطر عالي';
        case 'medium_risk': return 'خطر متوسط';
        case 'warning': return 'تحذير';
        default: return 'آمن';
      }
    } else {
      switch (level) {
        case 'high_risk': return 'High Risk';
        case 'medium_risk': return 'Medium Risk';
        case 'warning': return 'Warning';
        default: return 'Safe';
      }
    }
  };

  return (
    <div className="space-y-6" style={{ direction: language === 'ar' ? 'rtl' : 'ltr' }}>
      {/* Control Panel */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold" style={{ color: '#0C8547' }}>
            {language === 'ar' ? 'المراقبة الصحية المباشرة' : 'Real-Time Health Monitoring'}
          </h2>
          <button
            onClick={() => setIsMonitoring(!isMonitoring)}
            className="px-6 py-3 rounded-lg text-white font-bold text-lg transition-all hover:scale-105"
            style={{ backgroundColor: isMonitoring ? '#DC2626' : '#0C8547' }}
          >
            {isMonitoring
              ? (language === 'ar' ? 'إيقاف المراقبة' : 'Stop Monitoring')
              : (language === 'ar' ? 'بدء المراقبة' : 'Start Monitoring')}
          </button>
        </div>

        {isMonitoring && (
          <div className="mt-4 flex items-center gap-3 text-sm">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
            <span className="text-gray-600">
              {language === 'ar' ? 'المراقبة نشطة - تحديث كل 10 ثواني' : 'Monitoring active - Updates every 10 seconds'}
            </span>
          </div>
        )}
      </div>

      {/* Risk Status */}
      {monitoringData && (
        <div className="bg-white rounded-xl shadow-lg p-6 border-4" style={{ borderColor: getRiskColor(riskLevel) }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-full" style={{ backgroundColor: getRiskColor(riskLevel) + '20' }}>
                <AlertTriangle size={32} style={{ color: getRiskColor(riskLevel) }} />
              </div>
              <div>
                <h3 className="text-sm text-gray-600">
                  {language === 'ar' ? 'مستوى الخطر' : 'Risk Level'}
                </h3>
                <p className="text-3xl font-bold" style={{ color: getRiskColor(riskLevel) }}>
                  {getRiskLabel(riskLevel)}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Vital Signs */}
      {monitoringData && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-3">
              <Heart size={24} style={{ color: '#DC2626' }} />
              <h3 className="font-semibold text-gray-700">
                {language === 'ar' ? 'نبضات القلب' : 'Heart Rate'}
              </h3>
            </div>
            <p className="text-4xl font-bold" style={{ color: '#DC2626' }}>
              {monitoringData.sensors.heartRate || '--'}
            </p>
            <p className="text-sm text-gray-500 mt-1">bpm</p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-3">
              <Thermometer size={24} style={{ color: '#F59E0B' }} />
              <h3 className="font-semibold text-gray-700">
                {language === 'ar' ? 'درجة الحرارة' : 'Body Temp'}
              </h3>
            </div>
            <p className="text-4xl font-bold" style={{ color: '#F59E0B' }}>
              {monitoringData.sensors.bodyTemperature || '--'}
            </p>
            <p className="text-sm text-gray-500 mt-1">°C</p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-3">
              <Wind size={24} style={{ color: '#3B82F6' }} />
              <h3 className="font-semibold text-gray-700">
                {language === 'ar' ? 'مستوى الأكسجين' : 'Oxygen'}
              </h3>
            </div>
            <p className="text-4xl font-bold" style={{ color: '#3B82F6' }}>
              {monitoringData.sensors.oxygenLevel || '--'}
            </p>
            <p className="text-sm text-gray-500 mt-1">%</p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-3">
              <Activity size={24} style={{ color: '#10B981' }} />
              <h3 className="font-semibold text-gray-700">
                {language === 'ar' ? 'الخطوات' : 'Steps'}
              </h3>
            </div>
            <p className="text-4xl font-bold" style={{ color: '#10B981' }}>
              {monitoringData.sensors.steps || 0}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              {monitoringData.sensors.caloriesBurned || 0} {language === 'ar' ? 'سعرة' : 'cal'}
            </p>
          </div>
        </div>
      )}

      {/* Health Trend Chart */}
      {healthHistory.length > 0 && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold mb-4" style={{ color: '#0C8547' }}>
            {language === 'ar' ? 'الاتجاه الصحي' : 'Health Trend'}
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={healthHistory}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Line yAxisId="left" type="monotone" dataKey="heartRate" stroke="#DC2626" strokeWidth={2} name={language === 'ar' ? 'النبض' : 'Heart Rate'} />
              <Line yAxisId="right" type="monotone" dataKey="temp" stroke="#F59E0B" strokeWidth={2} name={language === 'ar' ? 'الحرارة' : 'Temperature'} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Location & Environment */}
      {monitoringData && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <MapPin size={24} style={{ color: '#0C8547' }} />
              <h3 className="font-semibold text-gray-700">
                {language === 'ar' ? 'الموقع' : 'Location'}
              </h3>
            </div>
            <p className="text-lg font-medium">{currentLocation}</p>
            {monitoringData.location && (
              <a
                href={`https://www.google.com/maps?q=${monitoringData.location.latitude},${monitoringData.location.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-blue-600 hover:underline mt-2 inline-block"
              >
                {language === 'ar' ? 'عرض على الخريطة' : 'View on Map'}
              </a>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Thermometer size={24} style={{ color: '#F59E0B' }} />
              <h3 className="font-semibold text-gray-700">
                {language === 'ar' ? 'البيئة' : 'Environment'}
              </h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">{language === 'ar' ? 'الحرارة المحيطة' : 'Ambient Temp'}:</span>
                <span className="font-semibold">{monitoringData.environmentalData.ambientTemperature}°C</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{language === 'ar' ? 'الرطوبة' : 'Humidity'}:</span>
                <span className="font-semibold">{monitoringData.environmentalData.humidity}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{language === 'ar' ? 'جودة الهواء' : 'Air Quality'}:</span>
                <span className="font-semibold">{monitoringData.environmentalData.airQuality}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Activity Status */}
      {monitoringData && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold mb-4" style={{ color: '#0C8547' }}>
            {language === 'ar' ? 'حالة النشاط' : 'Activity Status'}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-gray-600">{language === 'ar' ? 'سرعة المشي' : 'Walking Speed'}</p>
              <p className="text-2xl font-bold" style={{ color: '#0C8547' }}>
                {monitoringData.activityData.walkingSpeed} m/s
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{language === 'ar' ? 'مدة النشاط' : 'Activity Time'}</p>
              <p className="text-2xl font-bold" style={{ color: '#0C8547' }}>
                {monitoringData.activityData.activityDuration.toFixed(1)}h
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{language === 'ar' ? 'عدد التوقفات' : 'Stops'}</p>
              <p className="text-2xl font-bold" style={{ color: '#0C8547' }}>
                {monitoringData.activityData.stoppageCount}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{language === 'ar' ? 'آخر شرب ماء' : 'Last Water'}</p>
              <p className="text-2xl font-bold" style={{ color: '#3B82F6' }}>
                {monitoringData.activityData.lastWaterIntake}m
              </p>
              <button
                onClick={() => {
                  healthMonitor.recordWaterIntake();
                  toast.success(language === 'ar' ? 'تم تسجيل شرب الماء' : 'Water intake recorded');
                }}
                className="mt-2 px-3 py-1 text-sm rounded-lg text-white"
                style={{ backgroundColor: '#3B82F6' }}
              >
                <Droplet size={14} className="inline mr-1" />
                {language === 'ar' ? 'سجل شرب الماء' : 'Record Water'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}