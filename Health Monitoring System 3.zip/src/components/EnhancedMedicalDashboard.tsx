import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { rafeeqAPI } from '../../utils/supabase/client';
import { Users, AlertTriangle, Activity, TrendingUp, CheckCircle2, ArrowLeft, BarChart3, PieChart as PieChartIcon } from 'lucide-react';
import { toast } from 'sonner';
import { RafeeqLogo } from '../app/components/RafeeqLogo';
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export function EnhancedMedicalDashboard() {
  const { t, language } = useApp();
  const navigate = useNavigate();
  const [pilgrims, setPilgrims] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [statistics, setStatistics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const isRTL = language === 'ar';

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [pilgrimsData, alertsData, stats] = await Promise.all([
        rafeeqAPI.getPilgrims(),
        rafeeqAPI.getAlerts(false),
        rafeeqAPI.getStatistics(),
      ]);

      setPilgrims(Array.isArray(pilgrimsData) ? pilgrimsData : []);
      setAlerts(Array.isArray(alertsData) ? alertsData : []);
      setStatistics(stats);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleResolveAlert = async (alertId: string) => {
    try {
      await rafeeqAPI.resolveAlert(alertId);
      toast.success(isRTL ? 'تم حل التنبيه' : 'Alert resolved');
      loadData();
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ' : 'Error occurred');
    }
  };

  const getRiskColor = (risk: number) => {
    if (risk >= 70) return '#DC2626';
    if (risk >= 40) return '#F59E0B';
    return '#0C8547';
  };

  const getRiskLabel = (risk: number) => {
    if (risk >= 70) return isRTL ? 'خطر عالٍ' : 'High Risk';
    if (risk >= 40) return isRTL ? 'خطر متوسط' : 'Medium Risk';
    return isRTL ? 'آمن' : 'Safe';
  };

  // Prepare chart data
  const riskDistributionData = [
    {
      name: isRTL ? 'آمن' : 'Safe',
      value: pilgrims.filter(p => (p.current_risk || 0) < 40).length,
      color: '#0C8547'
    },
    {
      name: isRTL ? 'خطر متوسط' : 'Medium',
      value: statistics?.medium_risk_cases || 0,
      color: '#F59E0B'
    },
    {
      name: isRTL ? 'خطر عالٍ' : 'High',
      value: statistics?.high_risk_cases || 0,
      color: '#DC2626'
    },
  ];

  const diseaseData = Object.entries(statistics?.common_diseases || {}).map(([name, count]) => ({
    name,
    count,
  })).slice(0, 5);

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-5">
          <RafeeqLogo size={80} />
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 border-[3px] border-[#0C8547]/25 border-t-[#0C8547] rounded-full animate-spin" />
            <p className="text-gray-600 font-medium">{isRTL ? 'جاري التحميل...' : 'Loading...'}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
      {/* Top Stripe */}
      <div className="h-2 bg-gradient-to-r from-[#0C8547] via-[#0a6d3a] to-[#D4AF37]" />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b-2 shadow-md" style={{ borderColor: '#0C8547' }}>
        <div className="max-w-7xl mx-auto px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-xl hover:bg-gray-100 transition-colors"
            >
              {isRTL ? <ArrowLeft size={24} className="rotate-180" style={{ color: '#0C8547' }} /> : <ArrowLeft size={24} style={{ color: '#0C8547' }} />}
            </button>
            <RafeeqLogo size={48} />
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold" style={{ backgroundColor: '#0C854715', color: '#0C8547' }}>
              <span className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: '#0C8547' }} />
              {isRTL ? 'نشط' : 'Live'}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-5 py-8">
        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold" style={{ color: '#0C8547' }}>
            {isRTL ? 'لوحة الفريق الطبي' : 'Medical Team Dashboard'}
          </h1>
          <p className="text-gray-600 mt-2">
            {isRTL ? 'متابعة صحة الحجاج في الوقت الفعلي' : 'Real-time health monitoring and analytics'}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-[#0C8547] to-[#0a6d3a] rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <Users size={32} />
              <div className="text-4xl font-bold">{statistics?.total_pilgrims || 0}</div>
            </div>
            <p className="text-sm opacity-90">{t('totalPilgrims')}</p>
          </div>

          <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <AlertTriangle size={32} />
              <div className="text-4xl font-bold">{statistics?.high_risk_cases || 0}</div>
            </div>
            <p className="text-sm opacity-90">{t('highRiskCases')}</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp size={32} />
              <div className="text-4xl font-bold">{statistics?.medium_risk_cases || 0}</div>
            </div>
            <p className="text-sm opacity-90">{isRTL ? 'حالات خطر متوسط' : 'Medium Risk Cases'}</p>
          </div>

          <div className="bg-gradient-to-br from-[#D4AF37] to-[#b8952d] rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <Activity size={32} />
              <div className="text-4xl font-bold">{statistics?.active_alerts || 0}</div>
            </div>
            <p className="text-sm opacity-90">{t('activeCases')}</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Risk Distribution Pie Chart */}
          <div className="bg-white border-2 rounded-xl p-6 shadow-lg" style={{ borderColor: '#0C8547' }}>
            <div className="flex items-center gap-2 mb-6">
              <PieChartIcon size={24} style={{ color: '#0C8547' }} />
              <h2 className="text-xl font-bold" style={{ color: '#0C8547' }}>
                {isRTL ? 'توزيع مستويات الخطر' : 'Risk Distribution'}
              </h2>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={riskDistributionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {riskDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Common Diseases Bar Chart */}
          <div className="bg-white border-2 rounded-xl p-6 shadow-lg" style={{ borderColor: '#D4AF37' }}>
            <div className="flex items-center gap-2 mb-6">
              <BarChart3 size={24} style={{ color: '#D4AF37' }} />
              <h2 className="text-xl font-bold" style={{ color: '#D4AF37' }}>
                {t('commonDiseases')}
              </h2>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={diseaseData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#D4AF37" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Active Alerts */}
          <div className="bg-white border-2 rounded-xl p-6 shadow-lg" style={{ borderColor: '#DC2626' }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold" style={{ color: '#DC2626' }}>
                {isRTL ? 'التنبيهات النشطة' : 'Active Alerts'}
              </h2>
              {alerts.length > 0 && (
                <span className="px-3 py-1 rounded-full text-sm font-bold bg-red-100 text-red-700">
                  {alerts.length}
                </span>
              )}
            </div>

            {alerts.length === 0 ? (
              <div className="flex flex-col items-center py-10 text-center">
                <CheckCircle2 size={48} style={{ color: '#0C8547' }} className="mb-4" />
                <p className="font-semibold text-gray-800">
                  {isRTL ? 'لا توجد تنبيهات' : 'No Active Alerts'}
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  {isRTL ? 'جميع الحجاج بحالة جيدة' : 'All pilgrims are in good condition'}
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {alerts.slice(0, 10).map((alert: any) => (
                  <div
                    key={alert.id}
                    className="border-2 rounded-lg p-4"
                    style={{ borderColor: '#DC2626', backgroundColor: '#FEE2E2' }}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertTriangle size={18} className="text-red-600" />
                          <span className="font-bold text-gray-800">
                            {alert.pilgrims?.name || 'Unknown'}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 mb-2">{alert.message}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(alert.created_at).toLocaleString(isRTL ? 'ar-SA' : 'en-US')}
                        </p>
                      </div>
                      <button
                        onClick={() => handleResolveAlert(alert.id)}
                        className="px-4 py-2 rounded-lg text-white text-sm font-bold hover:opacity-90 transition-opacity"
                        style={{ backgroundColor: '#0C8547' }}
                      >
                        {t('resolveAlert')}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* High Risk Pilgrims */}
          <div className="bg-white border-2 rounded-xl p-6 shadow-lg" style={{ borderColor: '#F59E0B' }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold" style={{ color: '#F59E0B' }}>
                {isRTL ? 'الحالات عالية الخطورة' : 'High Risk Pilgrims'}
              </h2>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {pilgrims.filter(p => (p.current_risk || 0) >= 70).length === 0 ? (
                <div className="flex flex-col items-center py-10 text-center">
                  <CheckCircle2 size={48} style={{ color: '#0C8547' }} className="mb-4" />
                  <p className="font-semibold text-gray-800">
                    {isRTL ? 'لا توجد حالات خطرة' : 'No High Risk Cases'}
                  </p>
                </div>
              ) : (
                pilgrims.filter(p => (p.current_risk || 0) >= 70).map((pilgrim) => (
                  <div
                    key={pilgrim.id}
                    className="border-2 rounded-lg p-4"
                    style={{ borderColor: getRiskColor(pilgrim.current_risk || 0), backgroundColor: `${getRiskColor(pilgrim.current_risk || 0)}15` }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-gray-800">{pilgrim.name}</h3>
                        <p className="text-sm text-gray-600">
                          {isRTL ? 'العمر' : 'Age'}: {pilgrim.age}
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold" style={{ color: getRiskColor(pilgrim.current_risk || 0) }}>
                          {Math.round(pilgrim.current_risk || 0)}%
                        </div>
                        <p className="text-xs text-gray-600">{getRiskLabel(pilgrim.current_risk || 0)}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* All Pilgrims Table */}
        <div className="bg-white border-2 rounded-xl p-6 shadow-lg" style={{ borderColor: '#0C8547' }}>
          <h2 className="text-xl font-bold mb-6" style={{ color: '#0C8547' }}>
            {isRTL ? 'جميع الحجاج' : 'All Pilgrims'}
          </h2>

          {pilgrims.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-gray-600">
                {isRTL ? 'لا يوجد حجاج مسجلون بعد' : 'No pilgrims registered yet'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2" style={{ borderColor: '#0C8547' }}>
                    <th className={`py-3 px-4 font-bold ${isRTL ? 'text-right' : 'text-left'}`} style={{ color: '#0C8547' }}>
                      {t('name')}
                    </th>
                    <th className={`py-3 px-4 font-bold ${isRTL ? 'text-right' : 'text-left'}`} style={{ color: '#0C8547' }}>
                      {t('age')}
                    </th>
                    <th className={`py-3 px-4 font-bold ${isRTL ? 'text-right' : 'text-left'}`} style={{ color: '#0C8547' }}>
                      {t('nationality')}
                    </th>
                    <th className={`py-3 px-4 font-bold ${isRTL ? 'text-right' : 'text-left'}`} style={{ color: '#0C8547' }}>
                      {t('riskLevel')}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {pilgrims.map((pilgrim) => (
                    <tr key={pilgrim.id} className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                      <td className="py-3 px-4 font-medium">{pilgrim.name}</td>
                      <td className="py-3 px-4 text-gray-600">{pilgrim.age}</td>
                      <td className="py-3 px-4 text-gray-600">{pilgrim.nationality || '—'}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div
                              className="h-2 rounded-full transition-all"
                              style={{
                                width: `${pilgrim.current_risk || 0}%`,
                                backgroundColor: getRiskColor(pilgrim.current_risk || 0)
                              }}
                            />
                          </div>
                          <span className="text-sm font-bold" style={{ color: getRiskColor(pilgrim.current_risk || 0) }}>
                            {Math.round(pilgrim.current_risk || 0)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
