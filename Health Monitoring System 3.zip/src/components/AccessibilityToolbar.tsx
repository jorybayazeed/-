import { useState, useEffect } from 'react';
import { Volume2, ZoomIn, ZoomOut, Contrast, Eye } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

export function AccessibilityToolbar() {
  const { t, language } = useApp();
  const [fontSize, setFontSize] = useState(100);
  const [highContrast, setHighContrast] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
  }, [fontSize]);

  useEffect(() => {
    if (highContrast) {
      document.body.classList.add('high-contrast');
    } else {
      document.body.classList.remove('high-contrast');
    }
  }, [highContrast]);

  const increaseFontSize = () => {
    setFontSize(prev => Math.min(prev + 10, 150));
  };

  const decreaseFontSize = () => {
    setFontSize(prev => Math.max(prev - 10, 80));
  };

  const toggleHighContrast = () => {
    setHighContrast(prev => !prev);
  };

  const readPageContent = () => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }

      // Get all text content
      const elements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, button, a, label, span');
      const textContent: string[] = [];

      elements.forEach(el => {
        const text = el.textContent?.trim();
        if (text && text.length > 0 && !text.includes('http')) {
          textContent.push(text);
        }
      });

      const fullText = textContent.join('. ');
      const utterance = new SpeechSynthesisUtterance(fullText);
      utterance.lang = language === 'ar' ? 'ar-SA' : 'en-US';
      utterance.rate = 0.9;
      utterance.onend = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    } else {
      alert(language === 'ar' ? 'المتصفح لا يدعم القراءة الصوتية' : 'Browser does not support text-to-speech');
    }
  };

  return (
    <div
      className="fixed bottom-6 rounded-full shadow-2xl p-2 z-50"
      style={{
        backgroundColor: '#0C8547',
        [language === 'ar' ? 'left' : 'right']: '20px',
        direction: language === 'ar' ? 'rtl' : 'ltr',
      }}
    >
      <div className="flex items-center gap-1">
        {/* Read Aloud */}
        <button
          onClick={readPageContent}
          className={`p-3 rounded-full hover:bg-white/20 transition-all ${isSpeaking ? 'bg-white/30 animate-pulse' : ''}`}
          title={t('readAloud')}
          aria-label={t('readAloud')}
        >
          <Volume2 size={20} className="text-white" />
        </button>

        {/* Increase Font Size */}
        <button
          onClick={increaseFontSize}
          className="p-3 rounded-full hover:bg-white/20 transition-all"
          title={t('increaseFontSize')}
          aria-label={t('increaseFontSize')}
        >
          <ZoomIn size={20} className="text-white" />
        </button>

        {/* Decrease Font Size */}
        <button
          onClick={decreaseFontSize}
          className="p-3 rounded-full hover:bg-white/20 transition-all"
          title={t('decreaseFontSize')}
          aria-label={t('decreaseFontSize')}
        >
          <ZoomOut size={20} className="text-white" />
        </button>

        {/* High Contrast */}
        <button
          onClick={toggleHighContrast}
          className={`p-3 rounded-full transition-all ${highContrast ? 'bg-white/30' : 'hover:bg-white/20'}`}
          title={t('highContrast')}
          aria-label={t('highContrast')}
        >
          <Contrast size={20} className="text-white" />
        </button>

        {/* Accessibility Info */}
        <div className="px-3 py-2 border-l-2 border-white/30">
          <Eye size={20} className="text-white" />
        </div>
      </div>

      {/* Font Size Indicator */}
      {fontSize !== 100 && (
        <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-white rounded-lg shadow-lg px-3 py-1 text-sm font-medium whitespace-nowrap" style={{ color: '#0C8547' }}>
          {fontSize}%
        </div>
      )}
    </div>
  );
}
