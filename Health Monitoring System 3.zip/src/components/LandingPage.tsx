import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { Heart, Users, Brain, MapPin, Bell, Shield, Activity, Stethoscope, ChevronRight, LogIn, UserPlus } from 'lucide-react';
import { RafeeqLogo } from '../app/components/RafeeqLogo';
import { useState } from 'react';

export function LandingPage() {
  const navigate = useNavigate();
  const { t, language, setLanguage } = useApp();
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";
  const [showSignInModal, setShowSignInModal] = useState(false);
  const [showLogInModal, setShowLogInModal] = useState(false);

  const features = [
    {
      icon: <Brain className="w-6 h-6 text-primary" />,
      bg: 'bg-primary/10',
      border: 'border-primary/15',
      title: isRTL ? 'ذكاء اصطناعي متقدم' : 'Advanced AI',
      desc: isRTL ? 'اكتشاف المخاطر الصحية قبل حدوثها بتحليل ذكي' : 'Detect health risks before they occur with intelligent analysis',
    },
    {
      icon: <MapPin className="w-6 h-6 text-accent" />,
      bg: 'bg-accent/10',
      border: 'border-accent/15',
      title: isRTL ? 'تتبع الموقع' : 'Location Tracking',
      desc: isRTL ? 'متابعة لحظية لموقع الحاج طوال الرحلة' : 'Real-time pilgrim location monitoring throughout the journey',
    },
    {
      icon: <Bell className="w-6 h-6 text-primary" />,
      bg: 'bg-primary/10',
      border: 'border-primary/15',
      title: isRTL ? 'تنبيهات فورية' : 'Instant Alerts',
      desc: isRTL ? 'إشعارات فورية للمرافقين والفرق الطبية عند الخطر' : 'Instant notifications to companions and medical teams on risk',
    },
    {
      icon: <Activity className="w-6 h-6 text-accent" />,
      bg: 'bg-accent/10',
      border: 'border-accent/15',
      title: isRTL ? 'مراقبة صحية' : 'Health Monitoring',
      desc: isRTL ? 'قياس المؤشرات الحيوية بشكل مستمر ودقيق' : 'Continuous and precise vital signs measurement',
    },
    {
      icon: <Shield className="w-6 h-6 text-primary" />,
      bg: 'bg-primary/10',
      border: 'border-primary/15',
      title: isRTL ? 'استجابة طارئة' : 'Emergency Response',
      desc: isRTL ? 'طلب الاستغاثة الفوري بضغطة واحدة' : 'One-tap immediate emergency distress request',
    },
    {
      icon: <Users className="w-6 h-6 text-accent" />,
      bg: 'bg-accent/10',
      border: 'border-accent/15',
      title: isRTL ? 'تحليل جماعي' : 'Crowd Analytics',
      desc: isRTL ? 'تحليل صحة الحشود وتوزيع المخاطر بدقة' : 'Crowd health and risk distribution analytics with precision',
    },
  ];

  return (
    <div
      className={`min-h-screen bg-background ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      {/* Top accent stripe */}
      <div className="h-1 bg-gradient-to-r from-primary via-primary to-accent" />

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-6xl mx-auto px-5 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <RafeeqLogo className="h-14 w-auto drop-shadow-md" />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setLanguage('ar')}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all duration-200 ${
                language === 'ar'
                  ? 'bg-primary text-white shadow-md shadow-primary/25'
                  : 'bg-muted text-muted-foreground hover:bg-secondary hover:text-primary'
              }`}
              style={{ fontFamily: "'Cairo', sans-serif" }}
            >
              عربي
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all duration-200 ${
                language === 'en'
                  ? 'bg-primary text-white shadow-md shadow-primary/25'
                  : 'bg-muted text-muted-foreground hover:bg-secondary hover:text-primary'
              }`}
            >
              English
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-white">
        {/* Subtle geometric background pattern */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80' viewBox='0 0 80 80'%3E%3Cpath d='M40 0 L80 40 L40 80 L0 40 Z' fill='none' stroke='%230c7c48' stroke-opacity='0.04' stroke-width='1'/%3E%3C/svg%3E")`,
          }}
        />
        {/* Green radial glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[450px] bg-primary/4 rounded-full blur-3xl pointer-events-none" />
        {/* Gold accent glow */}
        <div className="absolute bottom-0 right-0 w-[400px] h-[300px] bg-accent/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-5xl mx-auto px-5 py-24 flex flex-col items-center text-center relative z-10">
          {/* Logo with concentric rings */}
          <div className="relative mb-10 flex items-center justify-center">
            <div className="absolute w-72 h-72 rounded-full border border-primary/8" />
            <div className="absolute w-56 h-56 rounded-full border border-primary/12" />
            <div className="absolute w-40 h-40 rounded-full border border-primary/16" />
            <div className="absolute w-48 h-48 bg-primary/5 rounded-full blur-2xl" />
            <div className="absolute -top-2 right-10 w-4 h-4 rounded-full bg-accent/80 shadow-lg shadow-accent/40" />
            <div className="absolute bottom-4 left-6 w-2.5 h-2.5 rounded-full bg-accent/50" />
            <div className="absolute top-8 left-4 w-2 h-2 rounded-full bg-primary/40" />
            <RafeeqLogo className="h-56 w-auto relative z-10 drop-shadow-2xl" />
          </div>

          {/* Titles */}
          <h1
            className="text-6xl md:text-7xl font-black text-foreground mb-3 leading-tight"
            style={{ fontFamily: "'Cairo', sans-serif" }}
          >
            {t('appName')}
          </h1>

          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-accent" />
            <p className="text-xl font-bold text-accent" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {isRTL ? 'رفيقك الصحي في رحلة الحج' : 'Your Health Companion on Hajj'}
            </p>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-accent" />
          </div>

          <p className="text-muted-foreground text-lg max-w-xl mb-14 leading-relaxed">
            {t('appDescription')}
          </p>

          {/* Main Action Buttons - Sign In & Log In */}
          <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md mb-8">
            <button
              onClick={() => setShowSignInModal(true)}
              className="flex-1 group relative overflow-hidden bg-primary text-white rounded-2xl py-6 px-8 hover:bg-primary/90 transition-all duration-300 hover:shadow-xl hover:shadow-primary/25 hover:-translate-y-1"
            >
              <div className="flex flex-col items-center gap-2">
                <UserPlus className="w-8 h-8" />
                <span className="text-lg font-bold">
                  {isRTL ? 'تسجيل جديد' : 'Sign In'}
                </span>
                <span className="text-sm text-white/80">
                  {isRTL ? 'إنشاء حساب جديد' : 'Create new account'}
                </span>
              </div>
            </button>

            <button
              onClick={() => setShowLogInModal(true)}
              className="flex-1 group relative overflow-hidden bg-white border-2 border-primary text-primary rounded-2xl py-6 px-8 hover:bg-primary/5 transition-all duration-300 hover:shadow-xl hover:shadow-primary/15 hover:-translate-y-1"
            >
              <div className="flex flex-col items-center gap-2">
                <LogIn className="w-8 h-8" />
                <span className="text-lg font-bold">
                  {isRTL ? 'تسجيل دخول' : 'Log In'}
                </span>
                <span className="text-sm text-primary/70">
                  {isRTL ? 'لديك حساب بالفعل' : 'Already have account'}
                </span>
              </div>
            </button>
          </div>

          {/* Quick access */}
          <button
            onClick={() => navigate('/monitoring')}
            className="text-sm text-muted-foreground hover:text-primary transition-colors underline underline-offset-4"
          >
            {isRTL ? 'الدخول المباشر للمراقبة' : 'Quick access to monitoring'}
          </button>
        </div>
      </section>

      {/* Stats banner */}
      <div className="bg-primary py-12">
        <div className="max-w-5xl mx-auto px-5">
          <div className="grid grid-cols-3 gap-6 text-center text-white">
            {[
              {
                number: isRTL ? '+٣ أنواع' : '3+',
                label: isRTL ? 'أنواع المستخدمين' : 'User Types',
              },
              {
                number: isRTL ? '+٩' : '9+',
                label: isRTL ? 'واجهات ذكية' : 'Smart Screens',
              },
              {
                number: isRTL ? 'مباشر' : 'Live',
                label: isRTL ? 'تحليل بالذكاء الاصطناعي' : 'AI-Powered Analysis',
              },
            ].map((stat, i) => (
              <div key={i} className="relative">
                {i < 2 && (
                  <div className="absolute top-1/2 -translate-y-1/2 end-0 h-10 w-px bg-white/20" />
                )}
                <div
                  className="text-3xl font-black mb-2"
                  style={{ fontFamily: "'Cairo', sans-serif" }}
                >
                  {stat.number}
                </div>
                <div className="text-primary-foreground/70 text-sm font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features */}
      <section className="py-20 bg-muted/40">
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-1.5 text-sm font-semibold mb-4 border border-primary/20">
              <Activity className="w-4 h-4" />
              {isRTL ? 'المميزات' : 'Features'}
            </div>
            <h2 className="text-3xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {isRTL ? 'كل ما تحتاجه في رحلة آمنة' : 'Everything you need for a safe journey'}
            </h2>
            <p className="text-muted-foreground mt-3 max-w-md mx-auto">
              {isRTL
                ? 'تقنيات متقدمة لحماية كبار السن وذوي الإعاقة أثناء أداء فريضة الحج'
                : 'Advanced technology to protect the elderly and disabled during Hajj'}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {features.map((feature, i) => (
              <div
                key={i}
                className={`bg-white border ${feature.border} rounded-2xl p-6 hover:border-opacity-40 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 group`}
              >
                <div className={`w-12 h-12 ${feature.bg} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-inner border ${feature.border}`}>
                  {feature.icon}
                </div>
                <h4
                  className="font-bold text-foreground mb-2"
                  style={{ fontFamily: isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif" }}
                >
                  {feature.title}
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gold CTA Banner */}
      <section className="py-16 bg-white border-y border-border">
        <div className="max-w-3xl mx-auto px-5 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/10 text-accent rounded-full px-4 py-1.5 text-sm font-semibold mb-4 border border-accent/25">
            <Shield className="w-4 h-4" />
            {isRTL ? 'ابدأ الآن' : 'Get Started'}
          </div>
          <h2
            className="text-3xl font-black text-foreground mb-4"
            style={{ fontFamily: "'Cairo', sans-serif" }}
          >
            {isRTL ? 'ابدأ رحلتك بأمان' : 'Start Your Journey Safely'}
          </h2>
          <p className="text-muted-foreground mb-8 leading-relaxed">
            {isRTL
              ? 'سجل الآن وسيقوم الذكاء الاصطناعي بمراقبة صحتك وتنبيه ذويك عند أي خطر'
              : 'Register now and our AI will monitor your health and alert your companions at any sign of risk'}
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => navigate('/register-pilgrim')}
              className="px-8 py-4 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2"
            >
              <Heart className="w-5 h-5" />
              {isRTL ? 'تسجيل كحاج' : 'Register as Pilgrim'}
            </button>
            <button
              onClick={() => navigate('/register-medical-team')}
              className="px-8 py-4 bg-white text-foreground border-2 border-border rounded-xl font-bold hover:border-accent hover:text-accent transition-all flex items-center justify-center gap-2"
            >
              <Stethoscope className="w-5 h-5" />
              {isRTL ? 'تسجيل كفريق طبي' : 'Register as Medical Team'}
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border bg-white">
        <div className="max-w-5xl mx-auto px-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center">
            <RafeeqLogo className="h-12 w-auto" />
          </div>
          <p className="text-muted-foreground text-sm text-center">
            {isRTL
              ? 'نظام صحي ذكي مدعوم بالذكاء الاصطناعي لحماية الحجاج'
              : 'AI-powered smart health system for pilgrim protection'}
          </p>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse inline-block" />
            {isRTL ? 'النظام نشط' : 'System Active'}
          </div>
        </div>
      </footer>

      {/* Sign In Modal */}
      {showSignInModal && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowSignInModal(false)}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowSignInModal(false)}
              className="absolute top-4 end-4 w-8 h-8 rounded-full hover:bg-muted transition-colors flex items-center justify-center text-muted-foreground hover:text-foreground"
            >
              ✕
            </button>

            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <UserPlus className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl font-black text-foreground mb-2" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'إنشاء حساب جديد' : 'Create New Account'}
              </h2>
              <p className="text-muted-foreground text-sm">
                {isRTL ? 'اختر نوع الحساب الذي تريد إنشاءه' : 'Choose the type of account you want to create'}
              </p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setShowSignInModal(false);
                  navigate('/register-pilgrim');
                }}
                className="w-full group bg-white border-2 border-border hover:border-primary rounded-2xl p-5 text-start transition-all hover:shadow-lg hover:shadow-primary/10"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary/15 transition-colors flex-shrink-0">
                    <Heart className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground mb-0.5">
                      {isRTL ? 'حساب حاج' : 'Pilgrim Account'}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {isRTL ? 'للحجاج وكبار السن وذوي الإعاقة' : 'For pilgrims, elderly & disabled'}
                    </p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-muted-foreground ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </button>

              <button
                onClick={() => {
                  setShowSignInModal(false);
                  navigate('/register-medical-team');
                }}
                className="w-full group bg-white border-2 border-border hover:border-accent rounded-2xl p-5 text-start transition-all hover:shadow-lg hover:shadow-accent/10"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center group-hover:bg-accent/15 transition-colors flex-shrink-0">
                    <Stethoscope className="w-6 h-6 text-accent" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground mb-0.5">
                      {isRTL ? 'حساب كادر طبي' : 'Medical Staff Account'}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {isRTL ? 'للأطباء والفرق الطبية والمسعفين' : 'For doctors, medical teams & paramedics'}
                    </p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-muted-foreground ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Log In Modal */}
      {showLogInModal && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowLogInModal(false)}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowLogInModal(false)}
              className="absolute top-4 end-4 w-8 h-8 rounded-full hover:bg-muted transition-colors flex items-center justify-center text-muted-foreground hover:text-foreground"
            >
              ✕
            </button>

            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <LogIn className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl font-black text-foreground mb-2" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'تسجيل الدخول' : 'Log In'}
              </h2>
              <p className="text-muted-foreground text-sm">
                {isRTL ? 'اختر نوع حسابك لتسجيل الدخول' : 'Choose your account type to log in'}
              </p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setShowLogInModal(false);
                  navigate('/login-pilgrim');
                }}
                className="w-full group bg-white border-2 border-border hover:border-primary rounded-2xl p-5 text-start transition-all hover:shadow-lg hover:shadow-primary/10"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary/15 transition-colors flex-shrink-0">
                    <Heart className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground mb-0.5">
                      {isRTL ? 'دخول الحجاج' : 'Pilgrim Login'}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {isRTL ? 'رقم الهاتف + OTP' : 'Phone + OTP'}
                    </p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-muted-foreground ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </button>

              <button
                onClick={() => {
                  setShowLogInModal(false);
                  navigate('/login-medical-team');
                }}
                className="w-full group bg-white border-2 border-border hover:border-accent rounded-2xl p-5 text-start transition-all hover:shadow-lg hover:shadow-accent/10"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center group-hover:bg-accent/15 transition-colors flex-shrink-0">
                    <Stethoscope className="w-6 h-6 text-accent" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground mb-0.5">
                      {isRTL ? 'دخول الكوادر الطبية' : 'Medical Staff Login'}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {isRTL ? 'رقم الهاتف + OTP' : 'Phone + OTP'}
                    </p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-muted-foreground ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </button>

              <button
                onClick={() => {
                  setShowLogInModal(false);
                  navigate('/login-admin');
                }}
                className="w-full group bg-white border-2 border-border hover:border-primary rounded-2xl p-5 text-start transition-all hover:shadow-lg hover:shadow-primary/10"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center opacity-90 group-hover:opacity-100 transition-opacity flex-shrink-0">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground mb-0.5">
                      {isRTL ? 'دخول الإدارة' : 'Admin Login'}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {isRTL ? 'اسم مستخدم وكلمة مرور' : 'Username & Password'}
                    </p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-muted-foreground ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}