import { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { getPilgrim, updatePilgrim, createHealthAlert } from '../lib/api';
import { analyzeBehavior, simulateBehaviorData } from '../lib/aiEngine';
import { Activity, Droplet, Clock, AlertTriangle, Heart, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { RafeeqLogo } from '../app/components/RafeeqLogo';

export function PilgrimMonitoring() {
  const { t, language, currentPilgrimId } = useApp();
  const navigate = useNavigate();
  const [pilgrim, setPilgrim] = useState<any>(null);
  const [riskAnalysis, setRiskAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  useEffect(() => {
    loadPilgrimData();
    const interval = setInterval(updateHealthAnalysis, 30000);
    return () => clearInterval(interval);
  }, [currentPilgrimId]);

  const loadPilgrimData = async () => {
    if (!currentPilgrimId) return;
    try {
      const data = await getPilgrim(currentPilgrimId);
      setPilgrim(data);
      updateHealthAnalysis(data);
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'خطأ في تحميل البيانات' : 'Error loading data');
    } finally {
      setLoading(false);
    }
  };

  const updateHealthAnalysis = async (pilgrimData?: any) => {
    const current = pilgrimData || pilgrim;
    if (!current) return;

    const behaviorData = simulateBehaviorData();
    const analysis = analyzeBehavior(
      {
        age: current.age,
        gender: current.gender,
        chronicDiseases: current.chronic_diseases || [],
        medications: current.medications || [],
      },
      current.baseline_risk,
      behaviorData
    );

    setRiskAnalysis(analysis);

    let newStatus: any;
    if (analysis.overallRisk < 30) newStatus = 'safe';
    else if (analysis.overallRisk < 50) newStatus = 'warning';
    else if (analysis.overallRisk < 75) newStatus = 'medium_risk';
    else newStatus = 'high_risk';

    await updatePilgrim(currentPilgrimId!, {
      current_risk: analysis.overallRisk,
      status: newStatus,
    });

    if (analysis.shouldEscalate) {
      await createHealthAlert({
        pilgrim_id: currentPilgrimId!,
        risk_level: 'critical',
        risk_type: analysis.riskFactors[0]?.type || 'unknown',
        description: analysis.riskFactors.map((f: any) => f.description).join(', '),
        location: behaviorData.location!,
      });
      toast.error(isRTL ? 'تنبيه: خطر مرتفع!' : 'Alert: High Risk!');
    }
  };

  const getRiskColor = (risk: number) => {
    if (risk < 30) return {
      ring: '#0c7c48',
      text: 'text-primary',
      badge: 'bg-primary/10 text-primary border-primary/25',
      bg: 'bg-primary/5',
    };
    if (risk < 50) return {
      ring: '#d97706',
      text: 'text-amber-600',
      badge: 'bg-amber-50 text-amber-700 border-amber-200',
      bg: 'bg-amber-50',
    };
    if (risk < 75) return {
      ring: '#ea580c',
      text: 'text-orange-600',
      badge: 'bg-orange-50 text-orange-700 border-orange-200',
      bg: 'bg-orange-50',
    };
    return {
      ring: '#dc2626',
      text: 'text-red-600',
      badge: 'bg-red-50 text-red-700 border-red-200',
      bg: 'bg-red-50',
    };
  };

  const getRiskText = (risk: number) => {
    if (risk < 30) return t('safe');
    if (risk < 50) return t('needsRest');
    if (risk < 75) return t('mediumRisk');
    return t('highRisk');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center" style={{ fontFamily: font }}>
        <div className="flex flex-col items-center gap-5">
          <RafeeqLogo className="h-20 w-auto animate-pulse" />
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 border-3 border-primary/25 border-t-primary rounded-full animate-spin" style={{ borderWidth: 3 }} />
            <p className="text-muted-foreground font-medium">{isRTL ? 'جاري التحميل...' : 'Loading...'}</p>
          </div>
        </div>
      </div>
    );
  }

  const risk = riskAnalysis?.overallRisk || 0;
  const colors = getRiskColor(risk);
  const circumference = 2 * Math.PI * 54;
  const dashOffset = circumference - (risk / 100) * circumference;

  return (
    <div
      className={`min-h-screen bg-background pb-8 ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      {/* Top accent */}
      <div className="h-1 bg-gradient-to-r from-primary via-primary to-accent" />

      <div className="max-w-4xl mx-auto px-4 pt-6">
        {/* Header */}
        <div className="bg-white border border-border rounded-2xl p-5 mb-6 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="w-9 h-9 flex items-center justify-center rounded-xl bg-muted hover:bg-secondary hover:text-primary text-muted-foreground transition-all"
            >
              {isRTL ? <ArrowLeft className="w-5 h-5 rotate-180" /> : <ArrowLeft className="w-5 h-5" />}
            </button>
            <div>
              <h1 className="text-xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {pilgrim?.name || '—'}
              </h1>
              <p className="text-sm text-muted-foreground">{isRTL ? 'مراقبة صحية ذكية' : 'Smart Health Monitoring'}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-1.5 text-xs text-primary bg-primary/8 px-3 py-1.5 rounded-full font-medium border border-primary/20">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              {isRTL ? 'تحليل مباشر' : 'Live Analysis'}
            </div>
            <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
          </div>
        </div>

        {/* Risk Gauge */}
        <div className="bg-white border border-border rounded-2xl p-8 mb-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-foreground">{t('currentStatus')}</h2>
            <div className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${colors.badge}`}>
              {getRiskText(risk)}
            </div>
          </div>

          <div className="flex flex-col items-center mb-8">
            <div className="relative w-40 h-40">
              {/* Background ring */}
              <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
                <circle cx="60" cy="60" r="54" fill="none" stroke="#f0f7f3" strokeWidth="10" />
                <circle
                  cx="60"
                  cy="60"
                  r="54"
                  fill="none"
                  stroke={colors.ring}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={dashOffset}
                  style={{ transition: 'stroke-dashoffset 0.8s ease, stroke 0.5s ease' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-black text-foreground leading-none">{Math.round(risk)}</span>
                <span className="text-xs text-muted-foreground mt-1">{isRTL ? 'مستوى الخطر' : 'Risk Level'}</span>
              </div>
            </div>
          </div>

          {/* Risk Factors */}
          {riskAnalysis?.riskFactors && riskAnalysis.riskFactors.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-bold text-foreground text-sm uppercase tracking-wide text-muted-foreground">
                {isRTL ? 'عوامل الخطر' : 'Risk Factors'}
              </h3>
              {riskAnalysis.riskFactors.map((factor: any, index: number) => (
                <div key={index} className="flex items-start gap-3 bg-destructive/5 border border-destructive/15 p-4 rounded-xl">
                  <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-foreground text-sm">{factor.description}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {isRTL ? 'الشدة:' : 'Severity:'} {Math.round(factor.severity)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Recommendations */}
          {riskAnalysis?.recommendations && riskAnalysis.recommendations.length > 0 && (
            <div className="mt-5 bg-primary/5 border border-primary/15 p-5 rounded-xl">
              <h3 className="font-bold text-primary text-sm mb-3 uppercase tracking-wide">
                {isRTL ? 'التوصيات' : 'Recommendations'}
              </h3>
              <ul className="space-y-2">
                {riskAnalysis.recommendations.map((rec: string, index: number) => (
                  <li key={index} className="text-sm text-foreground/80 flex items-start gap-2">
                    <span className="text-primary mt-1 flex-shrink-0 font-bold">•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Vitals Grid */}
        <div className="grid md:grid-cols-3 gap-5">
          {[
            {
              icon: <Activity className="w-6 h-6 text-primary" />,
              bg: 'bg-primary/10',
              label: t('activityHours'),
              value: '4.5h',
            },
            {
              icon: <Droplet className="w-6 h-6 text-accent" />,
              bg: 'bg-accent/10',
              label: t('waterReminder'),
              value: '2.1L',
            },
            {
              icon: <Clock className="w-6 h-6 text-primary" />,
              bg: 'bg-primary/10',
              label: t('medicationReminder'),
              value: isRTL ? 'في الوقت' : 'On Time',
            },
          ].map((vital, i) => (
            <div key={i} className="bg-white border border-border rounded-xl p-5 shadow-sm hover:border-primary/30 hover:shadow-md transition-all">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 ${vital.bg} rounded-xl flex items-center justify-center shadow-inner`}>
                  {vital.icon}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground font-medium">{vital.label}</p>
                  <p className="text-2xl font-black text-foreground leading-tight">{vital.value}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Emergency Button */}
        <div className="mt-6">
          <button className="w-full bg-destructive text-white py-5 rounded-2xl font-bold text-lg shadow-lg shadow-destructive/20 hover:bg-destructive/90 active:scale-[0.99] transition-all flex items-center justify-center gap-3">
            <Heart className="w-6 h-6 fill-white" />
            {isRTL ? 'طلب استغاثة طارئ' : 'Emergency SOS Request'}
          </button>
        </div>
      </div>
    </div>
  );
}
