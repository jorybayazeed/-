import { useState, useEffect } from 'react';
import { Clock, Pill, Plus, Trash2, Bell } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { createMedication, getMedications, deleteMedication } from '../lib/medicationApi';
import { toast } from 'sonner';

interface Medication {
  id?: string;
  name: string;
  dosage: string;
  frequency: number;
  times: string[];
  pilgrim_id: string;
}

export function MedicationReminders({ pilgrimId }: { pilgrimId: string }) {
  const { t, language } = useApp();
  const [medications, setMedications] = useState<Medication[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMed, setNewMed] = useState({
    name: '',
    dosage: '',
    frequency: 1,
    times: ['08:00']
  });

  useEffect(() => {
    loadMedications();
    // Check for medication reminders every minute
    const interval = setInterval(checkReminders, 60000);
    return () => clearInterval(interval);
  }, [pilgrimId]);

  const loadMedications = async () => {
    try {
      const result = await getMedications(pilgrimId);
      setMedications(result);
    } catch (error) {
      console.error('Error loading medications:', error);
    }
  };

  const checkReminders = () => {
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    medications.forEach(med => {
      if (med.times.includes(currentTime)) {
        // Show notification
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(t('takeMedication'), {
            body: `${med.name} - ${med.dosage}`,
            icon: '/rafeeq-icon.png'
          });
        }

        // Show toast
        toast.warning(t('takeMedication'), {
          description: `${med.name} - ${med.dosage}`,
          duration: 10000,
        });

        // Play sound
        playReminderSound();
      }
    });
  };

  const playReminderSound = () => {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFAxJn+DyvmwhBTGH0fPTgjMGHm7A7+OZQA==');
    audio.play().catch(e => console.log('Audio play failed:', e));
  };

  const addMedication = async () => {
    try {
      const medication = {
        ...newMed,
        pilgrim_id: pilgrimId,
      };

      const result = await createMedication(medication);
      setMedications([...medications, result]);
      setShowAddForm(false);
      setNewMed({ name: '', dosage: '', frequency: 1, times: ['08:00'] });

      toast.success(t('medicationAdded'));

      // Request notification permission
      if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
      }
    } catch (error) {
      console.error('Error adding medication:', error);
      toast.error(t('error'));
    }
  };

  const updateFrequency = (freq: number) => {
    const times: string[] = [];
    const interval = Math.floor(24 / freq);

    for (let i = 0; i < freq; i++) {
      const hour = (8 + i * interval) % 24;
      times.push(`${String(hour).padStart(2, '0')}:00`);
    }

    setNewMed({ ...newMed, frequency: freq, times });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6" style={{ direction: language === 'ar' ? 'rtl' : 'ltr' }}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full" style={{ backgroundColor: '#0C8547' }}>
            <Pill size={24} className="text-white" />
          </div>
          <h2 className="text-2xl font-bold" style={{ color: '#0C8547' }}>{t('medicationReminder')}</h2>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2 rounded-lg text-white font-medium flex items-center gap-2 hover:opacity-90 transition-opacity"
          style={{ backgroundColor: '#0C8547' }}
        >
          <Plus size={20} />
          {t('addMedication')}
        </button>
      </div>

      {/* Add Medication Form */}
      {showAddForm && (
        <div className="mb-6 p-4 border-2 rounded-xl" style={{ borderColor: '#0C8547' }}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">{t('medicationName')}</label>
              <input
                type="text"
                value={newMed.name}
                onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                className="w-full px-4 py-2 border-2 rounded-lg focus:outline-none focus:ring-2"
                style={{ borderColor: '#0C8547' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">{t('dosage')}</label>
              <input
                type="text"
                value={newMed.dosage}
                onChange={(e) => setNewMed({ ...newMed, dosage: e.target.value })}
                placeholder={language === 'ar' ? 'مثال: 500mg' : 'e.g., 500mg'}
                className="w-full px-4 py-2 border-2 rounded-lg focus:outline-none focus:ring-2"
                style={{ borderColor: '#0C8547' }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">{t('frequency')}</label>
              <select
                value={newMed.frequency}
                onChange={(e) => updateFrequency(parseInt(e.target.value))}
                className="w-full px-4 py-2 border-2 rounded-lg focus:outline-none focus:ring-2"
                style={{ borderColor: '#0C8547' }}
              >
                <option value={1}>1 {language === 'ar' ? 'مرة يومياً' : 'time daily'}</option>
                <option value={2}>2 {language === 'ar' ? 'مرات يومياً' : 'times daily'}</option>
                <option value={3}>3 {language === 'ar' ? 'مرات يومياً' : 'times daily'}</option>
                <option value={4}>4 {language === 'ar' ? 'مرات يومياً' : 'times daily'}</option>
              </select>
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium mb-2">{t('timeToTake')}</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {newMed.times.map((time, index) => (
                <input
                  key={index}
                  type="time"
                  value={time}
                  onChange={(e) => {
                    const newTimes = [...newMed.times];
                    newTimes[index] = e.target.value;
                    setNewMed({ ...newMed, times: newTimes });
                  }}
                  className="px-4 py-2 border-2 rounded-lg focus:outline-none focus:ring-2"
                  style={{ borderColor: '#0C8547' }}
                />
              ))}
            </div>
          </div>

          <div className="mt-4 flex gap-2 justify-end">
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border-2 rounded-lg hover:bg-gray-50 transition-colors"
              style={{ borderColor: '#0C8547', color: '#0C8547' }}
            >
              {t('cancel')}
            </button>
            <button
              onClick={addMedication}
              disabled={!newMed.name || !newMed.dosage}
              className="px-4 py-2 rounded-lg text-white font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
              style={{ backgroundColor: '#0C8547' }}
            >
              {t('save')}
            </button>
          </div>
        </div>
      )}

      {/* Medications List */}
      <div className="space-y-4">
        {medications.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            {language === 'ar' ? 'لا توجد أدوية مضافة' : 'No medications added'}
          </div>
        ) : (
          medications.map((med) => (
            <div
              key={med.id}
              className="border-2 rounded-xl p-4 hover:shadow-md transition-shadow"
              style={{ borderColor: '#D4AF37' }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-bold" style={{ color: '#0C8547' }}>{med.name}</h3>
                  <p className="text-gray-600 mt-1">{med.dosage}</p>
                  <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                    <Clock size={16} />
                    <span>
                      {med.frequency} {language === 'ar' ? 'مرات يومياً' : 'times daily'}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {med.times?.map((time, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-1 px-3 py-1 rounded-full text-sm text-white"
                        style={{ backgroundColor: '#0C8547' }}
                      >
                        <Bell size={14} />
                        {time}
                      </div>
                    ))}
                  </div>
                </div>
                <button
                  onClick={async () => {
                    if (med.id) {
                      try {
                        await deleteMedication(med.id);
                        setMedications(medications.filter(m => m.id !== med.id));
                        toast.success(language === 'ar' ? 'تم الحذف' : 'Deleted');
                      } catch (error) {
                        console.error('Error deleting medication:', error);
                        toast.error(language === 'ar' ? 'فشل الحذف' : 'Failed to delete');
                      }
                    }
                  }}
                  className="p-2 hover:bg-red-50 rounded-lg transition-colors text-red-500"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
