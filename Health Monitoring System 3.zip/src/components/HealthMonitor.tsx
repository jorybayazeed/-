import { useState, useEffect, useCallback } from 'react';
import { Activity, AlertTriangle, ThermometerSun, Droplets, MapPin, TrendingUp } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { rafeeqAPI } from '../../utils/supabase/client';
import { toast } from 'sonner';

interface HealthData {
  temperature: number;
  humidity: number;
  activity_hours: number;
  rest_hours: number;
  slow_walking: boolean;
  sudden_stops: number;
  continuous_activity: number;
  erratic_movement: boolean;
  repeated_paths: boolean;
}

interface RiskAnalysis {
  overall_risk: number;
  risk_level: string;
  detected_risks: Array<{
    type: string;
    level: string;
    message_ar: string;
    message_en: string;
  }>;
  recommendations_ar: string[];
  recommendations_en: string[];
}

export function HealthMonitor({ pilgrimId }: { pilgrimId: string }) {
  const { t, language } = useApp();
  const [healthData, setHealthData] = useState<HealthData>({
    temperature: 35,
    humidity: 40,
    activity_hours: 0,
    rest_hours: 0,
    slow_walking: false,
    sudden_stops: 0,
    continuous_activity: 0,
    erratic_movement: false,
    repeated_paths: false,
  });
  const [riskAnalysis, setRiskAnalysis] = useState<RiskAnalysis | null>(null);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lon: number } | null>(null);

  useEffect(() => {
    startMonitoring();
    return () => setIsMonitoring(false);
  }, []);

  const startMonitoring = () => {
    setIsMonitoring(true);

    // Try to get geolocation, but don't fail if not available
    if ('geolocation' in navigator) {
      navigator.geolocation.watchPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
          });
        },
        (error) => {
          console.warn('Geolocation not available:', error.message);
          // Use mock location for demo purposes
          setLocation({
            lat: 21.4225,  // Mecca coordinates
            lon: 39.8262,
          });
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    } else {
      // Fallback to mock location
      setLocation({
        lat: 21.4225,
        lon: 39.8262,
      });
    }

    // Simulate sensor data collection (in production, would use device sensors)
    const monitorInterval = setInterval(() => {
      collectSensorData();
    }, 30000); // Every 30 seconds

    return () => clearInterval(monitorInterval);
  };

  const collectSensorData = useCallback(async () => {
    try {
      // Simulate collecting data from device sensors
      // In production, would use DeviceMotionEvent, DeviceOrientationEvent, etc.

      // Mock environmental data (would come from weather API based on location)
      const mockTemp = 38 + Math.random() * 12;
      const mockHumidity = 30 + Math.random() * 40;

      // Mock activity data (would come from accelerometer/gyroscope)
      const mockActivityHours = Math.random() * 8;
      const mockRestHours = 8 - mockActivityHours;

      const updatedData: HealthData = {
        temperature: mockTemp,
        humidity: mockHumidity,
        activity_hours: mockActivityHours,
        rest_hours: mockRestHours,
        slow_walking: Math.random() > 0.7,
        sudden_stops: Math.floor(Math.random() * 10),
        continuous_activity: Math.random() * 3,
        erratic_movement: Math.random() > 0.9,
        repeated_paths: Math.random() > 0.85,
      };

      setHealthData(updatedData);

      // Save to backend with error handling
      try {
        await rafeeqAPI.saveHealthData({
          pilgrim_id: pilgrimId,
          ...updatedData,
          location: location,
        });
      } catch (apiError) {
        console.warn('Could not save to backend (demo mode):', apiError);
        // Continue with local monitoring even if backend fails
      }

      // Analyze risk
      analyzeRisk(updatedData);
    } catch (error) {
      console.warn('Sensor data collection error (using mock data):', error);
      // Continue monitoring with mock data
    }
  }, [pilgrimId, location]);

  const analyzeRisk = async (data: HealthData) => {
    try {
      const analysis = await rafeeqAPI.analyzeRisk({
        pilgrim_id: pilgrimId,
        activity_data: {
          activity_hours: data.activity_hours,
          rest_hours: data.rest_hours,
          slow_walking: data.slow_walking,
          frequent_stops: data.sudden_stops > 5,
          continuous_activity: data.continuous_activity,
          erratic_movement: data.erratic_movement,
          repeated_paths: data.repeated_paths,
        },
        environmental_data: {
          temperature: data.temperature,
          humidity: data.humidity,
        },
      });

      setRiskAnalysis(analysis);

      // Show alerts for high risk
      if (analysis.risk_level === 'high') {
        analysis.detected_risks.forEach(risk => {
          const message = language === 'ar' ? risk.message_ar : risk.message_en;
          toast.error(message, {
            duration: 10000,
          });

          // Create alert in backend (with error handling)
          rafeeqAPI.createAlert({
            pilgrim_id: pilgrimId,
            risk_type: risk.type,
            risk_level: risk.level,
            message,
            location: location,
          }).catch(err => console.warn('Could not create alert:', err));
        });

        // Vibrate device
        if ('vibrate' in navigator) {
          navigator.vibrate([200, 100, 200]);
        }
      }
    } catch (error) {
      console.warn('Risk analysis failed (using local analysis):', error);
      // Use local risk analysis when API fails
      const localAnalysis = performLocalRiskAnalysis(data);
      setRiskAnalysis(localAnalysis);
    }
  };

  // Local risk analysis when backend is unavailable
  const performLocalRiskAnalysis = (data: HealthData): RiskAnalysis => {
    let riskScore = 0;
    const detectedRisks: Array<{
      type: string;
      level: string;
      message_ar: string;
      message_en: string;
    }> = [];
    const recommendationsAr: string[] = [];
    const recommendationsEn: string[] = [];

    // Temperature risk
    if (data.temperature > 45) {
      riskScore += 30;
      detectedRisks.push({
        type: 'heat_exhaustion',
        level: 'high',
        message_ar: 'درجة حرارة عالية جداً - خطر الإجهاد الحراري',
        message_en: 'Very high temperature - Heat exhaustion risk',
      });
      recommendationsAr.push('اشرب الماء فوراً', 'ابحث عن مكان مظلل', 'استرح فوراً');
      recommendationsEn.push('Drink water immediately', 'Find shade', 'Rest immediately');
    } else if (data.temperature > 42) {
      riskScore += 15;
      detectedRisks.push({
        type: 'high_temperature',
        level: 'medium',
        message_ar: 'درجة حرارة مرتفعة',
        message_en: 'High temperature',
      });
      recommendationsAr.push('اشرب الماء بانتظام');
      recommendationsEn.push('Stay hydrated');
    }

    // Activity risk
    if (data.activity_hours > 6) {
      riskScore += 20;
      detectedRisks.push({
        type: 'overexertion',
        level: 'medium',
        message_ar: 'نشاط مستمر لفترة طويلة',
        message_en: 'Prolonged activity',
      });
      recommendationsAr.push('خذ قسطاً من الراحة');
      recommendationsEn.push('Take a rest break');
    }

    // Movement patterns
    if (data.slow_walking && data.sudden_stops > 5) {
      riskScore += 25;
      detectedRisks.push({
        type: 'fatigue',
        level: 'high',
        message_ar: 'علامات الإرهاق والتعب',
        message_en: 'Signs of fatigue detected',
      });
      recommendationsAr.push('توقف واسترح', 'اتصل بالمرافق');
      recommendationsEn.push('Stop and rest', 'Contact companion');
    }

    const riskLevel = riskScore >= 50 ? 'high' : riskScore >= 25 ? 'medium' : 'low';

    return {
      overall_risk: Math.min(riskScore, 100),
      risk_level: riskLevel,
      detected_risks: detectedRisks,
      recommendations_ar: recommendationsAr,
      recommendations_en: recommendationsEn,
    };
  };

  const getRiskColor = (risk: number) => {
    if (risk >= 70) return '#DC2626'; // Red
    if (risk >= 40) return '#F59E0B'; // Orange
    return '#0C8547'; // Green
  };

  const getRiskLabel = (risk: number) => {
    if (risk >= 70) return t('highRisk');
    if (risk >= 40) return t('mediumRisk');
    return t('safe');
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6" style={{ direction: language === 'ar' ? 'rtl' : 'ltr' }}>
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 rounded-full" style={{ backgroundColor: '#0C8547' }}>
          <Activity size={24} className="text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold" style={{ color: '#0C8547' }}>{t('healthMonitoring')}</h2>
          <p className="text-sm text-gray-500">{t('lastUpdate')}: {new Date().toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US')}</p>
        </div>
      </div>

      {/* Overall Risk Level */}
      {riskAnalysis && (
        <div className="mb-6 p-4 rounded-xl" style={{ backgroundColor: `${getRiskColor(riskAnalysis.overall_risk)}15` }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle size={24} style={{ color: getRiskColor(riskAnalysis.overall_risk) }} />
              <span className="font-bold text-lg" style={{ color: getRiskColor(riskAnalysis.overall_risk) }}>
                {getRiskLabel(riskAnalysis.overall_risk)}
              </span>
            </div>
            <div className="text-3xl font-bold" style={{ color: getRiskColor(riskAnalysis.overall_risk) }}>
              {riskAnalysis.overall_risk}%
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="h-3 rounded-full transition-all duration-500"
              style={{
                width: `${riskAnalysis.overall_risk}%`,
                backgroundColor: getRiskColor(riskAnalysis.overall_risk),
              }}
            />
          </div>
        </div>
      )}

      {/* Environmental Data */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="p-4 border-2 rounded-xl" style={{ borderColor: '#0C8547' }}>
          <ThermometerSun size={24} style={{ color: '#0C8547' }} className="mb-2" />
          <p className="text-sm text-gray-600">{t('temperature')}</p>
          <p className="text-2xl font-bold" style={{ color: '#0C8547' }}>{healthData.temperature.toFixed(1)}°C</p>
        </div>

        <div className="p-4 border-2 rounded-xl" style={{ borderColor: '#0C8547' }}>
          <Droplets size={24} style={{ color: '#0C8547' }} className="mb-2" />
          <p className="text-sm text-gray-600">{t('humidity')}</p>
          <p className="text-2xl font-bold" style={{ color: '#0C8547' }}>{healthData.humidity.toFixed(0)}%</p>
        </div>

        <div className="p-4 border-2 rounded-xl" style={{ borderColor: '#D4AF37' }}>
          <TrendingUp size={24} style={{ color: '#D4AF37' }} className="mb-2" />
          <p className="text-sm text-gray-600">{t('activityHours')}</p>
          <p className="text-2xl font-bold" style={{ color: '#D4AF37' }}>{healthData.activity_hours.toFixed(1)}h</p>
        </div>

        <div className="p-4 border-2 rounded-xl" style={{ borderColor: '#D4AF37' }}>
          <MapPin size={24} style={{ color: '#D4AF37' }} className="mb-2" />
          <p className="text-sm text-gray-600">{t('location')}</p>
          <p className="text-xs font-medium" style={{ color: '#D4AF37' }}>
            {location ? `${location.lat.toFixed(4)}, ${location.lon.toFixed(4)}` : '—'}
          </p>
        </div>
      </div>

      {/* Detected Risks */}
      {riskAnalysis && riskAnalysis.detected_risks.length > 0 && (
        <div className="mb-6">
          <h3 className="font-bold text-lg mb-3" style={{ color: '#0C8547' }}>
            {language === 'ar' ? 'المخاطر المكتشفة' : 'Detected Risks'}
          </h3>
          <div className="space-y-2">
            {riskAnalysis.detected_risks.map((risk, index) => (
              <div
                key={index}
                className="p-3 border-l-4 rounded-lg bg-red-50"
                style={{ borderColor: risk.level === 'high' ? '#DC2626' : '#F59E0B' }}
              >
                <p className="font-medium" style={{ color: risk.level === 'high' ? '#DC2626' : '#F59E0B' }}>
                  {language === 'ar' ? risk.message_ar : risk.message_en}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommendations */}
      {riskAnalysis && (language === 'ar' ? riskAnalysis.recommendations_ar : riskAnalysis.recommendations_en).length > 0 && (
        <div>
          <h3 className="font-bold text-lg mb-3" style={{ color: '#0C8547' }}>
            {language === 'ar' ? 'التوصيات' : 'Recommendations'}
          </h3>
          <ul className="space-y-2">
            {(language === 'ar' ? riskAnalysis.recommendations_ar : riskAnalysis.recommendations_en).map((rec, index) => (
              <li
                key={index}
                className="flex items-start gap-2 p-3 rounded-lg"
                style={{ backgroundColor: '#0C854710' }}
              >
                <span className="text-xl">✓</span>
                <span style={{ color: '#0C8547' }}>{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Monitoring Status */}
      <div className="mt-6 pt-4 border-t-2 border-gray-200">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">
            {language === 'ar' ? 'حالة المتابعة' : 'Monitoring Status'}
          </span>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isMonitoring ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
            <span className="text-sm font-medium" style={{ color: isMonitoring ? '#0C8547' : '#gray' }}>
              {isMonitoring ? (language === 'ar' ? 'نشط' : 'Active') : (language === 'ar' ? 'متوقف' : 'Stopped')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}