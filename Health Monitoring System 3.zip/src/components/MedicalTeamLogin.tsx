import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { ArrowLeft, ArrowRight, Loader2, Phone, Lock, CheckCircle, Stethoscope } from 'lucide-react';
import { toast } from 'sonner';
import { RafeeqLogo } from '../app/components/RafeeqLogo';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '../app/components/ui/input-otp';

export function MedicalTeamLogin() {
  const navigate = useNavigate();
  const { t, language } = useApp();
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [loading, setLoading] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (!phoneNumber || phoneNumber.length < 10) {
      toast.error(isRTL ? 'الرجاء إدخال رقم هاتف صحيح' : 'Please enter a valid phone number');
      setLoading(false);
      return;
    }

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success(isRTL ? 'تم إرسال رمز التحقق' : 'Verification code sent');
      setStep('otp');
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ في إرسال رمز التحقق' : 'Error sending verification code');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (otpCode.length !== 6) {
      toast.error(isRTL ? 'الرجاء إدخال رمز التحقق المكون من 6 أرقام' : 'Please enter the 6-digit verification code');
      setLoading(false);
      return;
    }

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check medical team status
      // "111111" = approved account
      // "222222" = pending approval
      // other = not registered
      if (otpCode === '111111') {
        toast.success(isRTL ? 'تم تسجيل الدخول بنجاح' : 'Login successful');
        navigate('/medical-dashboard');
      } else if (otpCode === '222222') {
        toast.warning(isRTL ? 'طلبك قيد المراجعة - في انتظار موافقة الإدارة' : 'Your request is pending - awaiting admin approval');
        setTimeout(() => navigate('/'), 2000);
      } else {
        toast.info(isRTL ? 'لم يتم العثور على حساب - يرجى تقديم طلب تسجيل' : 'Account not found - Please submit a registration request');
        navigate('/register-medical-team', { state: { phone: phoneNumber } });
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'رمز التحقق غير صحيح' : 'Invalid verification code');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success(isRTL ? 'تم إعادة إرسال رمز التحقق' : 'Verification code resent');
    } catch (error) {
      toast.error(isRTL ? 'حدث خطأ' : 'Error occurred');
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    'w-full px-4 py-3 rounded-xl border border-border bg-input-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent transition-all shadow-sm';

  return (
    <div
      className={`min-h-screen bg-background py-10 px-4 ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent via-accent to-primary z-50 shadow-sm" />

      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => step === 'phone' ? navigate('/') : setStep('phone')}
            className="flex items-center gap-2 text-muted-foreground hover:text-accent transition-colors font-medium"
          >
            {isRTL ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
            {isRTL ? 'رجوع' : 'Back'}
          </button>
          <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
        </div>

        <div className="flex items-center gap-3 mb-8">
          {['phone', 'otp'].map((s, idx) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all border-2 ${
                  s === step
                    ? 'bg-accent border-accent text-white shadow-lg shadow-accent/25'
                    : idx < ['phone', 'otp'].indexOf(step)
                    ? 'bg-accent/15 border-accent/40 text-accent'
                    : 'bg-white border-border text-muted-foreground'
                }`}
              >
                {idx < ['phone', 'otp'].indexOf(step) ? <CheckCircle className="w-4 h-4" /> : idx + 1}
              </div>
              {idx < 1 && (
                <div className={`h-0.5 w-16 rounded-full transition-all ${idx < ['phone', 'otp'].indexOf(step) ? 'bg-accent' : 'bg-border'}`} />
              )}
            </div>
          ))}
          <span className="text-sm text-muted-foreground ms-2">
            {step === 'phone'
              ? (isRTL ? 'رقم الهاتف' : 'Phone Number')
              : (isRTL ? 'رمز التحقق' : 'Verification Code')}
          </span>
        </div>

        {step === 'phone' ? (
          <div className="bg-white border border-border rounded-2xl shadow-lg p-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-11 h-11 bg-accent/10 rounded-xl flex items-center justify-center shadow-inner">
                <Stethoscope className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {isRTL ? 'تسجيل دخول الكادر الطبي' : 'Medical Team Login'}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {isRTL ? 'أدخل رقم هاتفك المسجل في النظام' : 'Enter your registered phone number'}
                </p>
              </div>
            </div>

            <div className="h-px bg-border my-6" />

            <form onSubmit={handleSendOTP} className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-foreground/80 mb-1.5">
                  {isRTL ? 'رقم الهاتف' : 'Phone Number'}
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)}
                    className={inputClass}
                    placeholder="+966 xxx xxx xxx"
                  />
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" style={{ left: isRTL ? 'auto' : '12px', right: isRTL ? '12px' : 'auto' }} />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {isRTL ? 'استخدم نفس الرقم الذي قدمته في نموذج التسجيل' : 'Use the same number from your registration form'}
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-accent text-white py-4 rounded-xl font-bold hover:bg-accent/90 active:scale-[0.99] transition-all shadow-lg shadow-accent/20 disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {isRTL ? 'جاري الإرسال...' : 'Sending...'}
                  </>
                ) : (
                  <>
                    {isRTL ? 'إرسال رمز التحقق' : 'Send Verification Code'}
                    <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                {isRTL ? 'ليس لديك حساب؟' : "Don't have an account?"}{' '}
                <button
                  onClick={() => navigate('/register-medical-team')}
                  className="text-accent font-semibold hover:underline"
                >
                  {isRTL ? 'قدم طلب تسجيل' : 'Submit registration request'}
                </button>
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-white border border-border rounded-2xl shadow-lg p-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-11 h-11 bg-accent/10 rounded-xl flex items-center justify-center shadow-inner">
                <Lock className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {isRTL ? 'رمز التحقق' : 'Verification Code'}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {isRTL ? `تم إرسال الرمز إلى ${phoneNumber}` : `Code sent to ${phoneNumber}`}
                </p>
              </div>
            </div>

            <div className="h-px bg-border my-6" />

            <form onSubmit={handleVerifyOTP} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-foreground/80 mb-3 text-center">
                  {isRTL ? 'أدخل الرمز المكون من 6 أرقام' : 'Enter the 6-digit code'}
                </label>
                <div className="flex justify-center" dir="ltr">
                  <InputOTP
                    maxLength={6}
                    value={otpCode}
                    onChange={(value) => setOtpCode(value)}
                  >
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || otpCode.length !== 6}
                className="w-full bg-accent text-white py-4 rounded-xl font-bold hover:bg-accent/90 active:scale-[0.99] transition-all shadow-lg shadow-accent/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {isRTL ? 'جاري التحقق...' : 'Verifying...'}
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    {isRTL ? 'تحقق وتسجيل الدخول' : 'Verify & Login'}
                  </>
                )}
              </button>

              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-3">
                  {isRTL ? 'لم يصلك الرمز؟' : "Didn't receive the code?"}
                </p>
                <button
                  type="button"
                  onClick={handleResendOTP}
                  disabled={loading}
                  className="text-accent font-semibold hover:underline disabled:opacity-50"
                >
                  {isRTL ? 'إعادة إرسال الرمز' : 'Resend Code'}
                </button>
              </div>
            </form>

            <div className="mt-6 p-4 bg-accent/5 border border-accent/20 rounded-xl">
              <p className="text-xs text-muted-foreground text-center leading-relaxed">
                {isRTL ? (
                  <>
                    💡 <strong>للتجربة:</strong> <code className="bg-white px-1.5 py-0.5 rounded font-mono">111111</code> = حساب موافق عليه | <code className="bg-white px-1.5 py-0.5 rounded font-mono">222222</code> = قيد المراجعة | غير ذلك = غير مسجل
                  </>
                ) : (
                  <>
                    💡 <strong>Demo:</strong> <code className="bg-white px-1.5 py-0.5 rounded font-mono">111111</code> = Approved | <code className="bg-white px-1.5 py-0.5 rounded font-mono">222222</code> = Pending | Other = Not registered
                  </>
                )}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
