import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import {
  Shield,
  Users,
  UserCheck,
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  BarChart3,
  LogOut,
  Phone,
  MapPin,
  Stethoscope,
} from 'lucide-react';
import { RafeeqLogo } from '../app/components/RafeeqLogo';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

export function AdminDashboard() {
  const navigate = useNavigate();
  const { language } = useApp();
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  // Mock data for medical team registration requests
  const [requests, setRequests] = useState([
    {
      id: '1',
      name: isRTL ? 'د. أحمد محمد العلي' : 'Dr. Ahmed Mohammed Al-Ali',
      role: isRTL ? 'طبيب طوارئ' : 'Emergency Doctor',
      phone: '+966501234567',
      location: isRTL ? 'مكة المكرمة' : 'Makkah',
      status: 'pending' as const,
      submittedAt: '2026-05-14',
    },
    {
      id: '2',
      name: isRTL ? 'د. فاطمة السعيد' : 'Dr. Fatima Al-Saeed',
      role: isRTL ? 'ممرضة' : 'Nurse',
      phone: '+966507654321',
      location: isRTL ? 'المدينة المنورة' : 'Madinah',
      status: 'pending' as const,
      submittedAt: '2026-05-13',
    },
    {
      id: '3',
      name: isRTL ? 'د. خالد عبدالله' : 'Dr. Khalid Abdullah',
      role: isRTL ? 'مسعف' : 'Paramedic',
      phone: '+966509876543',
      location: isRTL ? 'مكة المكرمة' : 'Makkah',
      status: 'pending' as const,
      submittedAt: '2026-05-15',
    },
  ]);

  // Statistics data (anonymized)
  const stats = {
    totalPilgrims: 1247,
    medicalTeamApproved: 48,
    medicalTeamPending: 3,
    activeAlerts: 12,
    safeStatus: 1189,
    warningStatus: 46,
    riskStatus: 12,
  };

  // Chart data for risk distribution
  const riskData = [
    { name: isRTL ? 'آمن' : 'Safe', value: stats.safeStatus, color: '#0c7c48' },
    { name: isRTL ? 'تحذير' : 'Warning', value: stats.warningStatus, color: '#d4af37' },
    { name: isRTL ? 'خطر' : 'Risk', value: stats.riskStatus, color: '#dc2626' },
  ];

  // Chart data for daily registrations
  const dailyData = [
    { date: isRTL ? '10 مايو' : 'May 10', pilgrims: 142, medical: 6 },
    { date: isRTL ? '11 مايو' : 'May 11', pilgrims: 198, medical: 8 },
    { date: isRTL ? '12 مايو' : 'May 12', pilgrims: 234, medical: 12 },
    { date: isRTL ? '13 مايو' : 'May 13', pilgrims: 287, medical: 9 },
    { date: isRTL ? '14 مايو' : 'May 14', pilgrims: 225, medical: 7 },
    { date: isRTL ? '15 مايو' : 'May 15', pilgrims: 161, medical: 6 },
  ];

  const handleApprove = (id: string) => {
    setRequests(prev =>
      prev.map(req =>
        req.id === id ? { ...req, status: 'approved' as const } : req
      )
    );
  };

  const handleReject = (id: string) => {
    setRequests(prev =>
      prev.map(req =>
        req.id === id ? { ...req, status: 'rejected' as const } : req
      )
    );
  };

  return (
    <div
      className={`min-h-screen bg-background ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary z-50 shadow-sm" />

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
            <div className="h-8 w-px bg-border" />
            <div>
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                <h1 className="text-lg font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {isRTL ? 'لوحة تحكم الإدارة' : 'Admin Dashboard'}
                </h1>
              </div>
              <p className="text-xs text-muted-foreground">
                {isRTL ? 'إدارة الموافقات والإحصائيات' : 'Manage Approvals & Analytics'}
              </p>
            </div>
          </div>

          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 px-4 py-2 bg-muted hover:bg-secondary text-muted-foreground hover:text-primary rounded-xl transition-all font-medium"
          >
            <LogOut className="w-4 h-4" />
            {isRTL ? 'تسجيل الخروج' : 'Logout'}
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-5 py-8 space-y-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <div className="bg-white border border-border rounded-2xl p-5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <TrendingUp className="w-4 h-4 text-primary" />
            </div>
            <div className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {stats.totalPilgrims.toLocaleString()}
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {isRTL ? 'إجمالي الحجاج' : 'Total Pilgrims'}
            </p>
          </div>

          <div className="bg-white border border-border rounded-2xl p-5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center">
                <Stethoscope className="w-5 h-5 text-accent" />
              </div>
              <CheckCircle className="w-4 h-4 text-accent" />
            </div>
            <div className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {stats.medicalTeamApproved}
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {isRTL ? 'كوادر طبية موافق عليها' : 'Approved Medical Staff'}
            </p>
          </div>

          <div className="bg-white border border-border rounded-2xl p-5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center">
                <Clock className="w-5 h-5 text-amber-600" />
              </div>
              <div className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs font-bold rounded-full">
                {stats.medicalTeamPending}
              </div>
            </div>
            <div className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {stats.medicalTeamPending}
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {isRTL ? 'طلبات قيد المراجعة' : 'Pending Requests'}
            </p>
          </div>

          <div className="bg-white border border-border rounded-2xl p-5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <Activity className="w-4 h-4 text-red-600" />
            </div>
            <div className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {stats.activeAlerts}
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {isRTL ? 'تنبيهات نشطة' : 'Active Alerts'}
            </p>
          </div>
        </div>

        {/* Pending Requests */}
        <div className="bg-white border border-border rounded-2xl shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center">
              <UserCheck className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'طلبات التسجيل قيد المراجعة' : 'Pending Registration Requests'}
              </h2>
              <p className="text-sm text-muted-foreground">
                {isRTL ? 'وافق أو ارفض طلبات انضمام الكوادر الطبية' : 'Approve or reject medical team join requests'}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {requests
              .filter(req => req.status === 'pending')
              .map(request => (
                <div
                  key={request.id}
                  className="border border-border rounded-xl p-5 hover:border-primary/30 transition-all bg-gradient-to-r from-white to-muted/20"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center">
                          <Stethoscope className="w-6 h-6 text-accent" />
                        </div>
                        <div>
                          <h3 className="font-bold text-foreground text-lg" style={{ fontFamily: "'Cairo', sans-serif" }}>
                            {request.name}
                          </h3>
                          <p className="text-sm text-muted-foreground">{request.role}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-4 mt-3 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Phone className="w-4 h-4" />
                          <span dir="ltr">{request.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          <span>{request.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span>{request.submittedAt}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleApprove(request.id)}
                        className="flex items-center gap-2 px-4 py-2.5 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-all shadow-md shadow-primary/20"
                      >
                        <CheckCircle className="w-4 h-4" />
                        {isRTL ? 'موافقة' : 'Approve'}
                      </button>
                      <button
                        onClick={() => handleReject(request.id)}
                        className="flex items-center gap-2 px-4 py-2.5 bg-red-500 text-white rounded-xl font-semibold hover:bg-red-600 transition-all shadow-md shadow-red-500/20"
                      >
                        <XCircle className="w-4 h-4" />
                        {isRTL ? 'رفض' : 'Reject'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}

            {requests.filter(req => req.status === 'pending').length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <CheckCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>{isRTL ? 'لا توجد طلبات قيد المراجعة' : 'No pending requests'}</p>
              </div>
            )}
          </div>
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Risk Distribution */}
          <div className="bg-white border border-border rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="text-lg font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {isRTL ? 'توزيع مستويات الخطر' : 'Risk Level Distribution'}
                </h2>
                <p className="text-xs text-muted-foreground">
                  {isRTL ? 'إحصائيات عامة للحالات الصحية' : 'General health status statistics'}
                </p>
              </div>
            </div>

            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={riskData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={entry => `${entry.value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {riskData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Daily Registrations */}
          <div className="bg-white border border-border rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h2 className="text-lg font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {isRTL ? 'التسجيلات اليومية' : 'Daily Registrations'}
                </h2>
                <p className="text-xs text-muted-foreground">
                  {isRTL ? 'عدد التسجيلات خلال الأيام الماضية' : 'Registrations over the past days'}
                </p>
              </div>
            </div>

            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="pilgrims" fill="#0c7c48" name={isRTL ? 'حجاج' : 'Pilgrims'} />
                <Bar dataKey="medical" fill="#d4af37" name={isRTL ? 'كوادر طبية' : 'Medical'} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Privacy Notice */}
        <div className="bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/20 rounded-2xl p-6">
          <div className="flex items-start gap-3">
            <Shield className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-foreground mb-2" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'حماية الخصوصية والبيانات' : 'Privacy & Data Protection'}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {isRTL
                  ? 'جميع البيانات المعروضة في هذه اللوحة هي إحصائيات عامة ومجهولة المصدر. لا يتم عرض أي معلومات شخصية تفصيلية عن الحجاج أو الكوادر الطبية لضمان حماية الخصوصية وفقاً لأعلى معايير الأمان.'
                  : 'All data displayed in this dashboard consists of general, anonymized statistics. No detailed personal information about pilgrims or medical staff is displayed, ensuring privacy protection according to the highest security standards.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
