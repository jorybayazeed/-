import { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { getAllPilgrims, getHealthAlerts, resolveAlert } from '../lib/api';
import { analyzeCrowdHealth } from '../lib/aiEngine';
import { Users, AlertTriangle, Activity, TrendingUp, CheckCircle2, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { RafeeqLogo } from '../app/components/RafeeqLogo';

export function MedicalDashboard() {
  const { t, language } = useApp();
  const navigate = useNavigate();
  const [pilgrims, setPilgrims] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [pilgrimsData, alertsData] = await Promise.all([
        getAllPilgrims(),
        getHealthAlerts(false),
      ]);

      setPilgrims(pilgrimsData || []);
      setAlerts(alertsData || []);

      if (pilgrimsData && pilgrimsData.length > 0) {
        const analysis = analyzeCrowdHealth(pilgrimsData);
        setAnalytics(analysis);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleResolveAlert = async (alertId: string) => {
    try {
      await resolveAlert(alertId);
      toast.success(isRTL ? 'تم حل التنبيه' : 'Alert resolved');
      loadData();
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ' : 'Error occurred');
    }
  };

  const getRiskBadge = (risk: number) => {
    if (risk < 30) return 'bg-primary/10 text-primary border border-primary/25';
    if (risk < 50) return 'bg-amber-50 text-amber-700 border border-amber-200';
    if (risk < 75) return 'bg-orange-50 text-orange-700 border border-orange-200';
    return 'bg-red-50 text-red-700 border border-red-200';
  };

  const getRiskBar = (level: string) => {
    if (level === 'safe') return 'bg-primary';
    if (level === 'warning') return 'bg-amber-400';
    if (level === 'medium') return 'bg-orange-500';
    return 'bg-destructive';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center" style={{ fontFamily: font }}>
        <div className="flex flex-col items-center gap-5">
          <RafeeqLogo className="h-20 w-auto animate-pulse" />
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 border-[3px] border-primary/25 border-t-primary rounded-full animate-spin" />
            <p className="text-muted-foreground font-medium">{isRTL ? 'جاري التحميل...' : 'Loading...'}</p>
          </div>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      icon: <Users className="w-6 h-6 text-primary" />,
      bg: 'bg-primary/10',
      value: analytics?.totalPilgrims || 0,
      label: t('totalPilgrims'),
      border: 'border-primary/20',
    },
    {
      icon: <AlertTriangle className="w-6 h-6 text-destructive" />,
      bg: 'bg-destructive/10',
      value: analytics?.highRiskCount || 0,
      label: t('highRiskCases'),
      border: 'border-destructive/20',
    },
    {
      icon: <Activity className="w-6 h-6 text-accent" />,
      bg: 'bg-accent/10',
      value: alerts.length,
      label: t('activeCases'),
      border: 'border-accent/20',
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-primary" />,
      bg: 'bg-primary/10',
      value: analytics?.averageRisk ? `${Math.round(analytics.averageRisk)}%` : '0%',
      label: isRTL ? 'متوسط الخطورة' : 'Average Risk',
      border: 'border-primary/20',
    },
  ];

  return (
    <div
      className={`min-h-screen bg-background ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      {/* Top accent stripe */}
      <div className="h-1 bg-gradient-to-r from-primary via-primary to-accent" />

      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/')}
              className="w-9 h-9 flex items-center justify-center rounded-xl bg-muted hover:bg-secondary hover:text-primary text-muted-foreground transition-all"
            >
              {isRTL ? <ArrowLeft className="w-5 h-5 rotate-180" /> : <ArrowLeft className="w-5 h-5" />}
            </button>
            <div className="w-px h-6 bg-border" />
            <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-primary bg-primary/8 px-3 py-1.5 rounded-full font-semibold border border-primary/20">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              {isRTL ? 'نشط' : 'Live'}
            </div>
            <div className="bg-primary/10 border border-primary/20 rounded-xl px-4 py-1.5">
              <span className="text-sm font-bold text-primary">
                {isRTL ? 'لوحة الفريق الطبي' : 'Medical Dashboard'}
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-5 py-8">

        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
            {isRTL ? 'مركز المراقبة الصحية' : 'Health Monitoring Center'}
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {isRTL ? 'متابعة صحة الحجاج في الوقت الفعلي' : 'Real-time pilgrim health monitoring'}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {statCards.map((card, i) => (
            <div
              key={i}
              className={`bg-white border ${card.border} rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow`}
            >
              <div className={`w-11 h-11 ${card.bg} rounded-xl flex items-center justify-center mb-4 shadow-inner`}>
                {card.icon}
              </div>
              <div className="text-3xl font-black text-foreground mb-1" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {card.value}
              </div>
              <p className="text-sm text-muted-foreground font-medium">{card.label}</p>
            </div>
          ))}
        </div>

        {/* Risk Distribution */}
        {analytics?.riskDistribution && (
          <div className="bg-white border border-border rounded-2xl p-6 mb-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'توزيع مستويات الخطر' : 'Risk Level Distribution'}
              </h2>
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-3 py-1 text-xs font-semibold border border-primary/20">
                <Activity className="w-3.5 h-3.5" />
                {isRTL ? 'إحصائيات' : 'Analytics'}
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {analytics.riskDistribution.map((dist: any) => (
                <div key={dist.level} className="text-center">
                  <div className="text-2xl font-black text-foreground mb-1" style={{ fontFamily: "'Cairo', sans-serif" }}>
                    {dist.count}
                  </div>
                  <div className="text-sm text-muted-foreground capitalize mb-2 font-medium">
                    {dist.level === 'safe' ? (isRTL ? 'آمن' : 'Safe')
                      : dist.level === 'warning' ? (isRTL ? 'تحذير' : 'Warning')
                      : dist.level === 'medium' ? (isRTL ? 'متوسط' : 'Medium')
                      : (isRTL ? 'خطر عالٍ' : 'High Risk')}
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${getRiskBar(dist.level)}`}
                      style={{ width: `${(dist.count / (analytics.totalPilgrims || 1)) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Active Alerts */}
          <div className="bg-white border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'التنبيهات النشطة' : 'Active Alerts'}
              </h2>
              {alerts.length > 0 && (
                <span className="bg-destructive/10 text-destructive border border-destructive/20 text-xs font-bold px-2.5 py-1 rounded-full">
                  {alerts.length}
                </span>
              )}
            </div>

            {alerts.length === 0 ? (
              <div className="flex flex-col items-center py-10 text-center">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-7 h-7 text-primary" />
                </div>
                <p className="font-semibold text-foreground mb-1">
                  {isRTL ? 'لا توجد تنبيهات' : 'No Active Alerts'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {isRTL ? 'جميع الحجاج بحالة جيدة' : 'All pilgrims are in good condition'}
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {alerts.map((alert: any) => (
                  <div
                    key={alert.id}
                    className={`border rounded-xl p-4 ${
                      alert.risk_level === 'critical'
                        ? 'border-destructive/30 bg-destructive/5'
                        : 'border-amber-200 bg-amber-50/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                          <AlertTriangle
                            className={`w-4 h-4 flex-shrink-0 ${
                              alert.risk_level === 'critical' ? 'text-destructive' : 'text-amber-600'
                            }`}
                          />
                          <span className="font-bold text-foreground text-sm truncate">
                            {alert.pilgrims?.name}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                              alert.risk_level === 'critical'
                                ? 'bg-destructive/15 text-destructive'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {alert.risk_level === 'critical' ? (isRTL ? 'حرج' : 'Critical') : (isRTL ? 'تحذير' : 'Warning')}
                          </span>
                        </div>
                        <p className="text-sm text-foreground/75 mb-1 leading-relaxed">{alert.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(alert.created_at).toLocaleString(isRTL ? 'ar-SA' : 'en-US')}
                        </p>
                      </div>
                      <button
                        onClick={() => handleResolveAlert(alert.id)}
                        className="flex-shrink-0 px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-semibold hover:bg-primary/90 transition-colors shadow-sm shadow-primary/20"
                      >
                        {isRTL ? 'حُلَّ' : 'Resolve'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* High Risk Cases Table */}
          <div className="bg-white border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                {isRTL ? 'الحالات عالية الخطورة' : 'High Risk Cases'}
              </h2>
              <span className="text-xs text-muted-foreground">
                {pilgrims.filter(p => p.current_risk >= 50).length} {isRTL ? 'حالة' : 'cases'}
              </span>
            </div>

            {pilgrims.filter(p => p.current_risk >= 50).length === 0 ? (
              <div className="flex flex-col items-center py-10 text-center">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
                  <Users className="w-7 h-7 text-primary" />
                </div>
                <p className="font-semibold text-foreground mb-1">
                  {isRTL ? 'لا توجد حالات خطرة' : 'No High Risk Cases'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {isRTL ? 'جميع الحجاج في وضع آمن' : 'All pilgrims are at safe levels'}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className={`py-2.5 px-3 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                        {isRTL ? 'الاسم' : 'Name'}
                      </th>
                      <th className={`py-2.5 px-3 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                        {isRTL ? 'العمر' : 'Age'}
                      </th>
                      <th className={`py-2.5 px-3 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                        {isRTL ? 'الخطورة' : 'Risk'}
                      </th>
                      <th className={`py-2.5 px-3 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                        {isRTL ? 'الحالة' : 'Status'}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {pilgrims
                      .filter(p => p.current_risk >= 50)
                      .slice(0, 8)
                      .map(pilgrim => (
                        <tr key={pilgrim.id} className="border-b border-border/50 hover:bg-muted/40 transition-colors">
                          <td className="py-3 px-3 font-medium text-foreground">{pilgrim.name}</td>
                          <td className="py-3 px-3 text-muted-foreground">{pilgrim.age}</td>
                          <td className="py-3 px-3">
                            <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${getRiskBadge(pilgrim.current_risk)}`}>
                              {Math.round(pilgrim.current_risk)}
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="text-muted-foreground text-xs capitalize">
                              {pilgrim.status?.replace('_', ' ')}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* All Pilgrims */}
        <div className="bg-white border border-border rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
              {isRTL ? 'جميع الحجاج' : 'All Pilgrims'}
            </h2>
            <span className="text-xs text-muted-foreground bg-muted px-2.5 py-1 rounded-full font-medium">
              {pilgrims.length} {isRTL ? 'حاج' : 'total'}
            </span>
          </div>

          {pilgrims.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-muted-foreground">
                {isRTL ? 'لا يوجد حجاج مسجلون بعد' : 'No pilgrims registered yet'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    <th className={`py-3 px-4 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'} rounded-tl-lg`}>
                      {isRTL ? 'الاسم' : 'Name'}
                    </th>
                    <th className={`py-3 px-4 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                      {isRTL ? 'العمر' : 'Age'}
                    </th>
                    <th className={`py-3 px-4 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                      {isRTL ? 'الجنسية' : 'Nationality'}
                    </th>
                    <th className={`py-3 px-4 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'}`}>
                      {isRTL ? 'مستوى الخطر' : 'Risk Level'}
                    </th>
                    <th className={`py-3 px-4 font-semibold text-muted-foreground ${isRTL ? 'text-right' : 'text-left'} rounded-tr-lg`}>
                      {isRTL ? 'الحالة' : 'Status'}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {pilgrims.map(pilgrim => (
                    <tr key={pilgrim.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-3 px-4 font-semibold text-foreground">{pilgrim.name}</td>
                      <td className="py-3 px-4 text-muted-foreground">{pilgrim.age}</td>
                      <td className="py-3 px-4 text-muted-foreground">{pilgrim.nationality || '—'}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${getRiskBadge(pilgrim.current_risk)}`}>
                          {Math.round(pilgrim.current_risk)}%
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`text-xs font-medium capitalize px-2.5 py-1 rounded-full ${
                          pilgrim.status === 'safe' ? 'bg-primary/10 text-primary'
                          : pilgrim.status === 'warning' ? 'bg-amber-100 text-amber-700'
                          : 'bg-red-100 text-red-700'
                        }`}>
                          {pilgrim.status?.replace('_', ' ')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
