import { projectId, publicAnonKey } from '/utils/supabase/info';

const supabaseUrl = `https://${projectId}.supabase.co`;

// API endpoints for backend
export const API_BASE = `${supabaseUrl}/functions/v1/make-server-05688e50`;
export { projectId, publicAnonKey };

// Database Types
export interface Pilgrim {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female';
  nationality: string;
  language: string;
  phone: string;
  chronic_diseases: string[];
  medications: string[];
  companions_count: number;
  baseline_risk: number;
  current_risk: number;
  status: 'safe' | 'warning' | 'medium_risk' | 'high_risk';
  created_at: string;
  updated_at?: string;
}

export interface Companion {
  id: string;
  pilgrim_id: string;
  name: string;
  phone: string;
  type: 'primary' | 'backup_1' | 'backup_2';
  created_at: string;
}

export interface HealthAlert {
  id: string;
  pilgrim_id: string;
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  risk_type: string;
  description: string;
  location: {
    lat: number;
    lng: number;
  };
  created_at: string;
  resolved: boolean;
  resolved_at?: string;
}

export interface MedicalTeamMember {
  id: string;
  name: string;
  role: string;
  phone: string;
  team_id?: string;
  created_at: string;
}
