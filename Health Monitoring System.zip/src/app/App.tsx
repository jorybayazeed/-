import { BrowserRouter, Routes, Route } from 'react-router';
import { AppProvider } from '../contexts/AppContext';
import { Toaster } from 'sonner';
import { LandingPage } from '../components/LandingPage';
import { PilgrimFlow } from '../components/PilgrimFlow';
import { PilgrimMonitoring } from '../components/PilgrimMonitoring';
import { MedicalFlow } from '../components/MedicalFlow';
import { MedicalDashboard } from '../components/MedicalDashboard';

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <div className="min-h-screen">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/register-pilgrim" element={<PilgrimFlow />} />
            <Route path="/monitoring" element={<PilgrimMonitoring />} />
            <Route path="/register-medical-team" element={<MedicalFlow />} />
            <Route path="/medical-dashboard" element={<MedicalDashboard />} />
          </Routes>
          <Toaster position="top-center" richColors />
        </div>
      </BrowserRouter>
    </AppProvider>
  );
}