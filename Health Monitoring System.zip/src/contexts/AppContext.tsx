import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'ar' | 'en';
type UserRole = 'pilgrim' | 'companion' | 'medical_team' | null;

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  currentPilgrimId: string | null;
  setCurrentPilgrimId: (id: string | null) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    appName: 'رفيق',
    appDescription: 'نظام ذكاء صحي وقائي لاكتشاف المخاطر الصحية الصامتة',
    forPilgrims: 'للحجاج وكبار السن',
    registerPilgrim: 'تسجيل حاج',
    registerMedicalTeam: 'تسجيل فريق طبي',
    selectLanguage: 'اختر اللغة',
    pilgrimRegistration: 'تسجيل بيانات الحاج',
    name: 'الاسم',
    age: 'العمر',
    gender: 'الجنس',
    male: 'ذكر',
    female: 'أنثى',
    nationality: 'الجنسية',
    phone: 'رقم التواصل',
    chronicDiseases: 'الأمراض المزمنة',
    medications: 'الأدوية المستخدمة',
    companionsCount: 'عدد المرافقين',
    submit: 'تسجيل',
    next: 'التالي',
    addCompanions: 'إضافة المرافقين',
    companionName: 'اسم المرافق',
    companionPhone: 'رقم المرافق',
    primaryCompanion: 'مرافق رئيسي',
    backupCompanion1: 'مرافق احتياطي 1',
    backupCompanion2: 'مرافق احتياطي 2',
    currentStatus: 'الحالة الحالية',
    activityHours: 'ساعات النشاط',
    waterReminder: 'تذكير شرب الماء',
    medicationReminder: 'تذكير الأدوية',
    riskLevel: 'مستوى الخطورة',
    safe: 'آمن',
    needsRest: 'يحتاج راحة',
    mediumRisk: 'خطر متوسط',
    highRisk: 'خطر مرتفع',
    heatExhaustion: 'احتمال إجهاد حراري',
    dehydration: 'احتمال جفاف شديد',
    physicalFatigue: 'إرهاق جسدي',
    mentalConfusion: 'احتمال فقدان تركيز',
    alertSent: 'تم إرسال تنبيه للمرافقين',
    medicalDashboard: 'لوحة الفريق الطبي',
    activeCases: 'الحالات النشطة',
    highRiskCases: 'حالات عالية الخطورة',
    totalPilgrims: 'إجمالي الحجاج',
    commonDiseases: 'الأمراض الأكثر انتشاراً',
    voiceTranslation: 'الترجمة الصوتية',
    speakNow: 'تحدث الآن',
    translating: 'جاري الترجمة...',
  },
  en: {
    appName: 'Rafeeq',
    appDescription: 'Smart Health System for Silent Health Risk Detection',
    forPilgrims: 'For Pilgrims and Elderly People',
    registerPilgrim: 'Register Pilgrim',
    registerMedicalTeam: 'Register Medical Team',
    selectLanguage: 'Select Language',
    pilgrimRegistration: 'Pilgrim Registration',
    name: 'Name',
    age: 'Age',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    nationality: 'Nationality',
    phone: 'Phone Number',
    chronicDiseases: 'Chronic Diseases',
    medications: 'Current Medications',
    companionsCount: 'Number of Companions',
    submit: 'Submit',
    next: 'Next',
    addCompanions: 'Add Companions',
    companionName: 'Companion Name',
    companionPhone: 'Companion Phone',
    primaryCompanion: 'Primary Companion',
    backupCompanion1: 'Backup Companion 1',
    backupCompanion2: 'Backup Companion 2',
    currentStatus: 'Current Status',
    activityHours: 'Activity Hours',
    waterReminder: 'Water Reminder',
    medicationReminder: 'Medication Reminder',
    riskLevel: 'Risk Level',
    safe: 'Safe',
    needsRest: 'Needs Rest',
    mediumRisk: 'Medium Risk',
    highRisk: 'High Risk',
    heatExhaustion: 'Possible Heat Exhaustion',
    dehydration: 'Severe Dehydration Risk',
    physicalFatigue: 'Physical Fatigue',
    mentalConfusion: 'Mental Confusion Risk',
    alertSent: 'Alert sent to companions',
    medicalDashboard: 'Medical Team Dashboard',
    activeCases: 'Active Cases',
    highRiskCases: 'High Risk Cases',
    totalPilgrims: 'Total Pilgrims',
    commonDiseases: 'Common Diseases',
    voiceTranslation: 'Voice Translation',
    speakNow: 'Speak Now',
    translating: 'Translating...',
  },
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('ar');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [currentPilgrimId, setCurrentPilgrimId] = useState<string | null>(null);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['ar']] || key;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        userRole,
        setUserRole,
        currentPilgrimId,
        setCurrentPilgrimId,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
