import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../contexts/AppContext';
import { createPilgrim, createCompanions } from '../lib/api';
import { calculateBaselineRisk } from '../lib/aiEngine';
import { ArrowLeft, ArrowRight, Loader2, Heart, UserPlus, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { RafeeqLogo } from '../app/components/RafeeqLogo';

export function PilgrimFlow() {
  const navigate = useNavigate();
  const { t, language, setCurrentPilgrimId, currentPilgrimId } = useApp();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const isRTL = language === 'ar';
  const font = isRTL ? "'Cairo', sans-serif" : "'Inter', sans-serif";

  const [pilgrimData, setPilgrimData] = useState({
    name: '',
    age: '',
    gender: 'male' as 'male' | 'female',
    nationality: '',
    phone: '',
    chronicDiseases: '',
    medications: '',
    companionsCount: '1',
  });

  const [companions, setCompanions] = useState({
    primary: { name: '', phone: '' },
    backup1: { name: '', phone: '' },
    backup2: { name: '', phone: '' },
  });

  const handlePilgrimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const chronicDiseases = pilgrimData.chronicDiseases.split(',').map(d => d.trim()).filter(d => d);
      const medications = pilgrimData.medications.split(',').map(m => m.trim()).filter(m => m);

      const baselineRisk = calculateBaselineRisk({
        age: parseInt(pilgrimData.age),
        gender: pilgrimData.gender,
        chronicDiseases,
        medications,
      });

      const pilgrim = await createPilgrim({
        name: pilgrimData.name,
        age: parseInt(pilgrimData.age),
        gender: pilgrimData.gender,
        nationality: pilgrimData.nationality,
        language: language,
        phone: pilgrimData.phone,
        chronic_diseases: chronicDiseases,
        medications: medications,
        companions_count: parseInt(pilgrimData.companionsCount),
        baseline_risk: baselineRisk,
        current_risk: baselineRisk,
        status: baselineRisk < 30 ? 'safe' : baselineRisk < 50 ? 'warning' : 'medium_risk',
      });

      setCurrentPilgrimId(pilgrim.id);
      toast.success(isRTL ? 'تم التسجيل بنجاح' : 'Registration successful');
      setStep(2);
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ في التسجيل' : 'Registration error');
    } finally {
      setLoading(false);
    }
  };

  const handleCompanionsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const companionsList = [];

      if (companions.primary.name && companions.primary.phone) {
        companionsList.push({ ...companions.primary, type: 'primary' as const });
      }
      if (companions.backup1.name && companions.backup1.phone) {
        companionsList.push({ ...companions.backup1, type: 'backup_1' as const });
      }
      if (companions.backup2.name && companions.backup2.phone) {
        companionsList.push({ ...companions.backup2, type: 'backup_2' as const });
      }

      if (companionsList.length > 0) {
        await createCompanions(currentPilgrimId!, companionsList);
      }

      toast.success(isRTL ? 'تم حفظ المرافقين' : 'Companions saved');
      navigate('/monitoring');
    } catch (error) {
      console.error('Error:', error);
      toast.error(isRTL ? 'حدث خطأ' : 'Error occurred');
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    'w-full px-4 py-3 rounded-xl border border-border bg-input-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all shadow-sm';
  const labelClass = 'block text-sm font-semibold text-foreground/80 mb-1.5';

  return (
    <div
      className={`min-h-screen bg-background py-10 px-4 ${isRTL ? 'rtl' : 'ltr'}`}
      style={{ fontFamily: font }}
    >
      {/* Top accent */}
      <div className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-primary to-accent z-50 shadow-sm" />

      <div className="max-w-2xl mx-auto">
        {/* Back + Logo */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => (step === 1 ? navigate('/') : setStep(1))}
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors font-medium"
          >
            {isRTL ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
            {isRTL ? 'رجوع' : 'Back'}
          </button>
          <RafeeqLogo className="h-12 w-auto drop-shadow-md" />
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-3 mb-8">
          {[1, 2].map(s => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all border-2 ${
                  s === step
                    ? 'bg-primary border-primary text-white shadow-lg shadow-primary/25'
                    : s < step
                    ? 'bg-primary/15 border-primary/40 text-primary'
                    : 'bg-white border-border text-muted-foreground'
                }`}
              >
                {s < step ? <CheckCircle className="w-4 h-4" /> : s}
              </div>
              {s < 2 && (
                <div className={`h-0.5 w-16 rounded-full transition-all ${s < step ? 'bg-primary' : 'bg-border'}`} />
              )}
            </div>
          ))}
          <span className="text-sm text-muted-foreground ms-2">
            {step === 1
              ? (isRTL ? 'بيانات الحاج' : 'Pilgrim Info')
              : (isRTL ? 'المرافقون' : 'Companions')}
          </span>
        </div>

        {step === 1 ? (
          <div className="bg-white border border-border rounded-2xl shadow-lg p-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-11 h-11 bg-primary/10 rounded-xl flex items-center justify-center shadow-inner">
                <Heart className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {t('pilgrimRegistration')}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {isRTL ? 'سيقوم الذكاء الاصطناعي بتحليل البيانات وحساب مستوى الخطر' : 'AI will analyze data and calculate risk level'}
                </p>
              </div>
            </div>

            <div className="h-px bg-border my-6" />

            <form onSubmit={handlePilgrimSubmit} className="space-y-5">
              <div>
                <label className={labelClass}>{t('name')}</label>
                <input
                  type="text"
                  required
                  value={pilgrimData.name}
                  onChange={e => setPilgrimData({ ...pilgrimData, name: e.target.value })}
                  className={inputClass}
                  placeholder={isRTL ? 'الاسم الكامل' : 'Full name'}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>{t('age')}</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="120"
                    value={pilgrimData.age}
                    onChange={e => setPilgrimData({ ...pilgrimData, age: e.target.value })}
                    className={inputClass}
                    placeholder={isRTL ? 'العمر' : 'Age'}
                  />
                </div>
                <div>
                  <label className={labelClass}>{t('gender')}</label>
                  <select
                    value={pilgrimData.gender}
                    onChange={e => setPilgrimData({ ...pilgrimData, gender: e.target.value as 'male' | 'female' })}
                    className={inputClass}
                  >
                    <option value="male">{t('male')}</option>
                    <option value="female">{t('female')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className={labelClass}>{t('nationality')}</label>
                <input
                  type="text"
                  required
                  value={pilgrimData.nationality}
                  onChange={e => setPilgrimData({ ...pilgrimData, nationality: e.target.value })}
                  className={inputClass}
                  placeholder={isRTL ? 'الجنسية' : 'Nationality'}
                />
              </div>

              <div>
                <label className={labelClass}>{t('phone')}</label>
                <input
                  type="tel"
                  required
                  value={pilgrimData.phone}
                  onChange={e => setPilgrimData({ ...pilgrimData, phone: e.target.value })}
                  className={inputClass}
                  placeholder="+966 xxx xxx xxx"
                />
              </div>

              <div>
                <label className={labelClass}>{t('chronicDiseases')}</label>
                <textarea
                  value={pilgrimData.chronicDiseases}
                  onChange={e => setPilgrimData({ ...pilgrimData, chronicDiseases: e.target.value })}
                  className={inputClass}
                  rows={2}
                  placeholder={isRTL ? 'افصل بينها بفاصلة — مثال: السكري، ضغط الدم' : 'Separate with commas — e.g. Diabetes, Blood pressure'}
                />
              </div>

              <div>
                <label className={labelClass}>{t('medications')}</label>
                <textarea
                  value={pilgrimData.medications}
                  onChange={e => setPilgrimData({ ...pilgrimData, medications: e.target.value })}
                  className={inputClass}
                  rows={2}
                  placeholder={isRTL ? 'افصل بينها بفاصلة' : 'Separate with commas'}
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-white py-4 rounded-xl font-bold hover:bg-primary/90 active:scale-[0.99] transition-all shadow-lg shadow-primary/20 disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {isRTL ? 'جاري التسجيل...' : 'Registering...'}
                  </>
                ) : (
                  t('next')
                )}
              </button>
            </form>
          </div>
        ) : (
          <div className="bg-white border border-border rounded-2xl shadow-lg p-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-11 h-11 bg-accent/10 rounded-xl flex items-center justify-center shadow-inner">
                <UserPlus className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "'Cairo', sans-serif" }}>
                  {t('addCompanions')}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {isRTL ? 'سيتم إرسال التنبيهات لجميع المرافقين' : 'All companions will receive alerts'}
                </p>
              </div>
            </div>

            <div className="h-px bg-border my-6" />

            <form onSubmit={handleCompanionsSubmit} className="space-y-5">
              <div className="border-2 border-primary/25 rounded-xl p-5 bg-primary/4">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-2 h-5 rounded-full bg-primary" />
                  <h3 className="font-bold text-foreground">{t('primaryCompanion')}</h3>
                </div>
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder={t('companionName')}
                    value={companions.primary.name}
                    onChange={e => setCompanions({ ...companions, primary: { ...companions.primary, name: e.target.value } })}
                    className={inputClass}
                  />
                  <input
                    type="tel"
                    placeholder={t('companionPhone')}
                    value={companions.primary.phone}
                    onChange={e => setCompanions({ ...companions, primary: { ...companions.primary, phone: e.target.value } })}
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="border border-border rounded-xl p-5 bg-white">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-5 rounded-full bg-border" />
                    <h3 className="font-bold text-foreground">{t('backupCompanion1')}</h3>
                  </div>
                  <span className="text-xs bg-muted text-muted-foreground px-2.5 py-1 rounded-full font-medium">
                    {isRTL ? 'اختياري' : 'Optional'}
                  </span>
                </div>
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder={t('companionName')}
                    value={companions.backup1.name}
                    onChange={e => setCompanions({ ...companions, backup1: { ...companions.backup1, name: e.target.value } })}
                    className={inputClass}
                  />
                  <input
                    type="tel"
                    placeholder={t('companionPhone')}
                    value={companions.backup1.phone}
                    onChange={e => setCompanions({ ...companions, backup1: { ...companions.backup1, phone: e.target.value } })}
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-2">
                <button
                  type="button"
                  onClick={() => navigate('/monitoring')}
                  className="flex-1 bg-muted text-muted-foreground py-4 rounded-xl font-semibold hover:bg-secondary hover:text-primary transition-all border border-border"
                >
                  {isRTL ? 'تخطي' : 'Skip'}
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-primary text-white py-4 rounded-xl font-bold hover:bg-primary/90 transition-all shadow-lg shadow-primary/20 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      {isRTL ? 'جاري الحفظ...' : 'Saving...'}
                    </>
                  ) : (
                    isRTL ? 'حفظ والمتابعة' : 'Save & Continue'
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
