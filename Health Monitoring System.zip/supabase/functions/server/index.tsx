import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-05688e50/health", (c) => {
  return c.json({ status: "ok" });
});

// ============== RAFEEQ SYSTEM API ENDPOINTS ==============

// Pilgrim Endpoints
app.post("/make-server-05688e50/pilgrims", async (c) => {
  try {
    const body = await c.req.json();
    const pilgrimId = crypto.randomUUID();
    const pilgrim = {
      id: pilgrimId,
      ...body,
      created_at: new Date().toISOString(),
    };

    await kv.set(`pilgrim:${pilgrimId}`, pilgrim);

    // Add to pilgrims list
    const allPilgrims = await kv.get('pilgrims:all') || [];
    allPilgrims.push(pilgrimId);
    await kv.set('pilgrims:all', allPilgrims);

    return c.json(pilgrim, 201);
  } catch (error) {
    console.error("Error creating pilgrim:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/pilgrims", async (c) => {
  try {
    const pilgrimIds = await kv.get('pilgrims:all') || [];
    const pilgrims = [];

    for (const id of pilgrimIds) {
      const pilgrim = await kv.get(`pilgrim:${id}`);
      if (pilgrim) pilgrims.push(pilgrim);
    }

    // Sort by current_risk descending
    pilgrims.sort((a, b) => (b.current_risk || 0) - (a.current_risk || 0));

    return c.json(pilgrims);
  } catch (error) {
    console.error("Error fetching pilgrims:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/pilgrims/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const pilgrim = await kv.get(`pilgrim:${id}`);

    if (!pilgrim) {
      return c.json({ error: "Pilgrim not found" }, 404);
    }

    // Get companions
    const companions = await kv.get(`companions:${id}`) || [];

    return c.json({ ...pilgrim, companions });
  } catch (error) {
    console.error("Error fetching pilgrim:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.put("/make-server-05688e50/pilgrims/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const updates = await c.req.json();

    const existing = await kv.get(`pilgrim:${id}`);
    if (!existing) {
      return c.json({ error: "Pilgrim not found" }, 404);
    }

    const updated = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString(),
    };

    await kv.set(`pilgrim:${id}`, updated);

    return c.json(updated);
  } catch (error) {
    console.error("Error updating pilgrim:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Companion Endpoints
app.post("/make-server-05688e50/companions", async (c) => {
  try {
    const body = await c.req.json();
    const companions = body.companions || [];
    const pilgrimId = body.pilgrim_id;

    if (!pilgrimId) {
      return c.json({ error: "pilgrim_id is required" }, 400);
    }

    const companionsWithIds = companions.map((comp: any) => ({
      id: crypto.randomUUID(),
      ...comp,
      pilgrim_id: pilgrimId,
      created_at: new Date().toISOString(),
    }));

    await kv.set(`companions:${pilgrimId}`, companionsWithIds);

    return c.json(companionsWithIds, 201);
  } catch (error) {
    console.error("Error creating companions:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Health Alert Endpoints
app.post("/make-server-05688e50/alerts", async (c) => {
  try {
    const body = await c.req.json();
    const alertId = crypto.randomUUID();
    const alert = {
      id: alertId,
      ...body,
      created_at: new Date().toISOString(),
      resolved: false,
    };

    await kv.set(`alert:${alertId}`, alert);

    // Add to alerts list
    const allAlerts = await kv.get('alerts:all') || [];
    allAlerts.push(alertId);
    await kv.set('alerts:all', allAlerts);

    return c.json(alert, 201);
  } catch (error) {
    console.error("Error creating alert:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.get("/make-server-05688e50/alerts", async (c) => {
  try {
    const resolvedParam = c.req.query('resolved');
    const alertIds = await kv.get('alerts:all') || [];
    const alerts = [];

    for (const id of alertIds) {
      const alert = await kv.get(`alert:${id}`);
      if (alert) {
        // Filter by resolved status if specified
        if (resolvedParam === 'false' && alert.resolved) continue;
        if (resolvedParam === 'true' && !alert.resolved) continue;

        // Get pilgrim info
        const pilgrim = await kv.get(`pilgrim:${alert.pilgrim_id}`);
        alerts.push({
          ...alert,
          pilgrims: pilgrim ? { name: pilgrim.name, phone: pilgrim.phone } : null
        });
      }
    }

    // Sort by created_at descending
    alerts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return c.json(alerts);
  } catch (error) {
    console.error("Error fetching alerts:", error);
    return c.json({ error: error.message }, 500);
  }
});

app.put("/make-server-05688e50/alerts/:id/resolve", async (c) => {
  try {
    const id = c.req.param('id');
    const alert = await kv.get(`alert:${id}`);

    if (!alert) {
      return c.json({ error: "Alert not found" }, 404);
    }

    const updated = {
      ...alert,
      resolved: true,
      resolved_at: new Date().toISOString(),
    };

    await kv.set(`alert:${id}`, updated);

    return c.json(updated);
  } catch (error) {
    console.error("Error resolving alert:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Medical Team Endpoints
app.post("/make-server-05688e50/medical-team", async (c) => {
  try {
    const body = await c.req.json();
    const memberId = crypto.randomUUID();
    const member = {
      id: memberId,
      ...body,
      created_at: new Date().toISOString(),
    };

    await kv.set(`medical:${memberId}`, member);

    // Add to medical team list
    const allMembers = await kv.get('medical:all') || [];
    allMembers.push(memberId);
    await kv.set('medical:all', allMembers);

    return c.json(member, 201);
  } catch (error) {
    console.error("Error creating medical team member:", error);
    return c.json({ error: error.message }, 500);
  }
});

Deno.serve(app.fetch);